import os, sys, asyncio, dotenv


HERE = os.path.dirname(os.path.abspath(__file__))  # ecs_demo
os.chdir(HERE)
dotenv.load_dotenv(os.path.join(HERE, ".env"))
sys.path.insert(0, HERE)

from hll_ai.agent.agent import Agent


async def main():
    agent = Agent.load(".")  # 断点1: 看 Agent.load 装配
    resp = await agent.handle_message(  # 断点2: 消息入口
        message="查一下订单",  # 改成你要测的输入
        sender_id="debug_user",
    )
    for m in resp.messages:
        print("BOT:", m)

asyncio.run(main())