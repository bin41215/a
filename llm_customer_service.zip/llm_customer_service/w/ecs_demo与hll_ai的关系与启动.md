# ecs_demo 与 hll_ai：关系、调用链路、启动方式

---

## 一、两者的角色定位

| | hll_ai | ecs_demo |
|---|---|---|
| **角色** | 对话系统**框架**（pip 包） | 使用框架搭建的**电商客服业务项目** |
| **类比** | Django / Flask | 用 Django 写的一个电商网站 |
| **内容** | Agent、图编排、策略、命令系统、Flow 引擎、检索抽象、API 服务器……全套基础设施 | 4 个 YAML（Flow 定义）+ 4 个 YAML（Domain 定义）+ 7 个自定义 Action 类 + 1 个自定义 Retriever 类 + 2 个配置文件 |
| **可运行？** | 不能独立运行，需被项目加载 | 可以运行，通过 `hll run` 指向 ecs_demo 目录启动 |
| **能否替换？** | 换一个项目（如 insurance_demo）仍可复用 | 换一套 Flow/Domain/Action 就是另一个客服机器人 |

简单说：**hll_ai 是引擎，ecs_demo 是跑在引擎上的业务配方。**

---

## 二、ecs_demo 的文件用途逐个说明

```
ecs_demo/
├── config.yml           ← 主配置：声明用哪些 Pipeline 组件和策略、引用哪个 LLM 和 Retriever
├── endpoints.yml        ← 端点配置：LLM 密钥/模型名、向量库地址、Tracker 存储方式
├── domain/              ← Domain 定义：声明槽位、动作名、回复模板
│   ├── domain_order.yml     订单相关槽位 + 回复模板 + Action 声明
│   ├── domain_logistics.yml 物流相关
│   ├── domain_postsale.yml  售后相关
│   └── domain_patterns.yml  通用模式（闲聊、帮助等）
├── data/flows/          ← Flow 定义：声明业务流程的步骤和分支
│   ├── flow_order.yml       查询订单 / 修改收货信息 / 取消订单
│   ├── flow_logistics.yml   查物流 / 投诉物流
│   └── flow_postsale.yml    申请售后
├── actions/             ← 自定义 Action：实现具体的业务逻辑（查数据库、调 API）
│   ├── __init__.py          导出所有 Action 类
│   ├── action_order.py      订单相关 7 个 Action
│   ├── action_logistics.py  物流相关 2 个 Action
│   ├── action_postsale.py   售后相关 4 个 Action
│   ├── db.py                MySQL 数据库连接
│   └── db_table_class.py    ORM 表模型
├── addons/              ← 自定义扩展组件
│   ├── __init__.py          导出 GraphRAG
│   ├── information_retrieval.py  GraphRAG 检索器（继承 hll_ai 的 InformationRetrieval）
│   └── create_indexing.py   知识图谱索引构建脚本
├── gen_data.py          ← 生成模拟业务数据（订单、物流、售后记录写入 MySQL）
└── .env                 ← 环境变量（API KEY、数据库密码等，不提交 Git）
```

---

## 三、调用关系全链路

### 3.1 启动加载阶段（`hll run` → `Agent.load()`）

```
用户在 ecs_demo/ 目录下执行：
    hll run

     │
     ▼
hll_ai/cli/__init__.py → main()
  ├── 自动加载 ecs_demo/.env 到环境变量
  ├── 将 ecs_demo/ 添加到 sys.path（以便 import actions、addons 这些顶层包）
  └── 调用 cli/run.py → run_command()
        │
        ▼
      Agent.load("ecs_demo/")         ← 关键调用点
        │
        ├── 1. 读取 config.yml
        │     ├── pipeline[0].name = "LLMCommandGenerator"
        │     │     └── llm: "default"  ──→ 引用 endpoints.yml 的 models.default
        │     └── policies[1].name = "EnterpriseSearchPolicy"
        │           └── vector_store: "addons.information_retrieval.GraphRAG"
        │
        ├── 2. 读取 endpoints.yml
        │     ├── models.default → LLMConfig(type=qwen, model=qwen-max, api_key=...)
        │     ├── vector_store → {uri, user, password}
        │     ├── tracker_store → {type: memory}
        │     └── nlg → {rephrase_enabled: false}
        │
        ├── 3. 加载 Domain
        │     └── Domain.load("ecs_demo/domain/")
        │           └── 合并 domain_order.yml + domain_logistics.yml + domain_postsale.yml + domain_patterns.yml
        │                 → 得到全部 slots / actions / responses 定义
        │
        ├── 4. 加载 Flows
        │     └── FlowLoader().load("ecs_demo/data/flows/")
        │           └── 合并 flow_order.yml + flow_logistics.yml + flow_postsale.yml
        │                 → 得到全部 Flow 定义
        │
        ├── 5. 自动发现并注册自定义 Actions
        │     └── _load_custom_actions("ecs_demo/actions/")
        │           ├── 扫描 actions/action_order.py → 发现 7 个 Action 子类
        │           ├── 扫描 actions/action_logistics.py → 发现 2 个 Action 子类
        │           ├── 扫描 actions/action_postsale.py → 发现 4 个 Action 子类
        │           └── 对每个类：实例化 → register_action() 注册到全局表
        │
        ├── 6. 创建 LLMCommandGenerator
        │     └── 用 endpoints.yml 的 models.default 配置
        │
        ├── 7. 创建 Retriever（自定义检索器）
        │     └── create_retriever("addons.information_retrieval.GraphRAG", connect_config)
        │           ├── importlib 动态加载 addons.information_retrieval.GraphRAG 类
        │           ├── 实例化 GraphRAG()
        │           └── graphrag.connect({uri, user, password})  ← 连接 Neo4j
        │
        ├── 8. 创建 EnterpriseSearchPolicy
        │     └── 传入 llm_client + retriever(graphrag)
        │
        ├── 9. 创建 FlowPolicy
        │     └── 传入 flows
        │
        └── 10. 组装 Agent
              └── Agent(domain, flows, tracker_store, policy_ensemble, command_generator)
```

### 3.2 请求处理阶段（用户发消息 → 收到回复）

```
用户发送: "帮我查一下订单 ORD20250101001"
  │
  ▼
POST /api/messages  →  Agent.handle_message()
  │
  ├── 1. TrackerStore.get_or_create_tracker("user1")
  │
  ├── 2. 构建 LangGraph 初始状态（注入所有组件引用）
  │
  └── 3. graph.ainvoke(initial_state)
        │
        ├─ understand_node
        │   ├─ PromptBuilder.build_messages()
        │   │   └─ 将 ecs_demo 的 flows/slots 信息填入 Jinja2 模板
        │   ├─ LLMClient.complete()  → 返回 "SetSlot(order_id, ORD20250101001)\nStartFlow(query_order_detail)"
        │   ├─ CommandParser.parse()  → [SetSlotCommand, StartFlowCommand]
        │   └─ CommandProcessor.process()
        │       ├─ SetSlotCommand.run()  → tracker.set_slot("order_id", "ORD20250101001")
        │       └─ StartFlowCommand.run()  → tracker.start_flow("query_order_detail")
        │                              → 对话栈: [FlowStackFrame(query_order_detail@START)]
        │
        ├─ policy_node
        │   └─ PolicyEnsemble.predict()
        │       ├─ FlowPolicy.predict()
        │       │   └─ FlowExecutor.execute_next_step(tracker)
        │       │       └─ 当前步骤: set_slots(goto=action_ask_order_id_before_completed_3_days)
        │       │           → 设置 goto 槽位 → 推进到 collect(order_id) 步骤
        │       │           → 因为 order_id 已被 SetSlot 填充，直接跳过 → 到 next 步骤
        │       │           → 条件分支: order_id != "false" → 执行 action_get_order_detail
        │       │           → 返回 Prediction(action="action_get_order_detail", confidence=1.0)
        │       └─ EnterpriseSearchPolicy 放弃投票（有活动 Flow）
        │
        ├─ action_node
        │   └─ get_action("action_get_order_detail")
        │       └─ 从 ecs_demo/actions/action_order.py 找到 ActionGetOrderDetail 实例
        │       └─ ActionGetOrderDetail.run(tracker, domain)
        │           ├─ tracker.get_slot("order_id")  → "ORD20250101001"
        │           ├─ 查询 MySQL 数据库 → 获取订单详情
        │           └─ result.add_response("订单详情: ...")
        │
        ├─ guard_node → action_count=1 < max_actions=10 → 继续
        │
        ├─ policy_node（第二轮循环）
        │   └─ FlowExecutor.execute_next_step()
        │       └─ 当前步骤的 next = END
        │       └─ 设置 FlowStackFrame.completing = True
        │       └─ 返回 Prediction(action="action_flow_completed", confidence=1.0)
        │
        ├─ action_node
        │   └─ ActionFlowCompleted.run()  → 压入 CompletedStackFrame
        │
        ├─ guard_node → 继续
        │
        ├─ policy_node（第三轮循环）
        │   └─ FlowPolicy: 没有 completing 帧 → 放弃
        │   └─ EnterpriseSearchPolicy: 检测到 CompletedStackFrame
        │       └─ 返回 Prediction(action="action_send_text", text="还有什么我可以帮您的吗？")
        │
        ├─ action_node
        │   └─ ActionSendText.run()  → 返回文本
        │
        ├─ guard_node → 继续
        │
        ├─ policy_node（第四轮循环）
        │   └─ FlowPolicy: 无活动 Flow → 放弃
        │   └─ EnterpriseSearchPolicy: 此帧已处理完 → 放弃
        │   └─ 所有策略放弃 → 返回 action_listen
        │
        └─ should_execute_action → action_listen → is_finished=True → 跳到 response_node
  │
  ├── 4. TrackerStore.save(updated_tracker)
  │
  └── 5. return MessageResponse(messages=[
              {"text": "订单详情: [已完成]订单ID：ORD20250101001 ..."},
              {"text": "还有什么我可以帮您的吗？"}
          ])
```

### 3.3 知识检索阶段（用户问政策性问题，不匹配任何 Flow）

```
用户发送: "你们的退货政策是什么？"
  │
  ▼
understand_node → LLM 生成 KnowledgeAnswerCommand → 压入 SearchStackFrame
  │
  ▼
policy_node → FlowPolicy 放弃 → EnterpriseSearchPolicy 接管
  │
  ├─ _handle_search_frame()
  │   ├─ self._retriever.search("退货政策", top_k=3, tracker_state=...)
  │   │   └─ 调用 ecs_demo/addons/information_retrieval.py 的 GraphRAG.search()
  │   │       ├─ route_label()    → LLM 识别入口节点类型（如 "Category3: 退货政策"）
  │   │       ├─ node_retrieval() → 混合检索 入口候选节点
  │   │       ├─ generate_cypher()→ LLM 生成 Cypher 查询
  │   │       ├─ validate_cypher()→ LLM + explain 验证语法
  │   │       ├─ correct_cypher() → 如有错误则校正
  │   │       └─ driver.execute_query(cypher) → 执行查询返回结果
  │   │
  │   ├─ 如果检索到结果 → _generate_rag_answer()
  │   │   └─ LLM 基于检索结果生成回答 → 返回 Prediction(action="action_send_text", text="...")
  │   │
  │   └─ 如果无结果 → _generate_chitchat_answer() → 降级闲聊 → 再降级默认回复
  │
  └─ action_node → ActionSendText.run() → 返回文本
```

---

## 四、ecs_demo 对 hll_ai 的三类扩展方式

ecs_demo 通过三种途径扩展 hll_ai 框架，**框架代码零修改**：

### 4.1 配置驱动（YAML 文件）

| 配置文件 | 扩展什么 | hll_ai 如何消费 |
|---------|---------|----------------|
| `domain/*.yml` | 定义槽位、动作名、回复模板 | `Domain.load()` 解析 → 填入 Domain 对象 → Action 查找模板、LLM Prompt 获取槽位语境 |
| `data/flows/*.yml` | 定义业务流程步骤和分支 | `FlowLoader.load()` 解析 → 填入 FlowsList → FlowPolicy 按 Flow 步骤推进 → LLM Prompt 获取可用 Flow 列表 |
| `config.yml` | 声明 Pipeline 组件和策略 | `Agent.load()` 读取 → 选择 LLMCommandGenerator 配置哪个 LLM、EnterpriseSearchPolicy 配置哪个 Retriever |
| `endpoints.yml` | 配置 LLM 连接参数和检索后端 | `Agent.load()` 读取 → 创建 LLMClient 实例、创建 Retriever 实例并调 connect() |

### 4.2 自定义 Action（Python 类继承）

ecs_demo 的每个 Action 类都继承 `hll_ai.agent.actions.Action`，实现 `name` 属性和 `run()` 方法：

```python
# ecs_demo/actions/action_order.py
from hll_ai.agent.actions import Action, ActionResult

class ActionAskOrderId(Action):
    @property
    def name(self) -> str:
        return "action_ask_order_id"        # ← 必须和 Flow/domain 中声明的名字一致

    async def run(self, tracker, domain, **kwargs) -> ActionResult:
        # 1. 从 tracker 读取槽位值
        user_id = tracker.get_slot("user_id")
        goto = tracker.get_slot("goto")

        # 2. 查询业务数据库
        order_infos = session.query(OrderInfo).filter(...).all()

        # 3. 构造交互式回复（按钮）
        result = ActionResult()
        result.add_response("请选择订单", buttons=[...])
        return result
```

**注册链条**：
```
ecs_demo/actions/action_order.py 定义 ActionAskOrderId
    ↓ Agent.load() 扫描 actions/ 目录
    ↓ importlib 动态导入模块
    ↓ inspect.getmembers 找到 Action 子类
    ↓ 实例化 → register_action() 注册到全局表 _CUSTOM_ACTIONS
    ↓ 运行时 action_node 通过 get_action("action_ask_order_id") 查找
```

**关键约束**：Action 类的 `name` 属性必须与 `domain/*.yml` 中 `actions:` 列表和 `data/flows/*.yml` 中 `action:` 字段完全一致，否则运行时找不到。

### 4.3 自定义 Retriever（Python 类继承）

ecs_demo 的 GraphRAG 继承 `hll_ai.retrieval.base_retriever.InformationRetrieval`，实现 `connect()` 和 `search()` 两个方法：

```python
# ecs_demo/addons/information_retrieval.py
from hll_ai.retrieval.base_retriever import InformationRetrieval, SearchResult

class GraphRAG(InformationRetrieval):
    def connect(self, config):
        """连接 Neo4j、加载 schema、初始化 LLM 和嵌入模型"""
        self.driver = GraphDatabase.driver(...)
        self.neo4j_schema = Neo4jGraph(...).schema
        self.llm = ChatTongyi(...)
        self._init_embeddings()

    async def search(self, query, top_k=5, tracker_state=None) -> List[SearchResult]:
        """GraphRAG 检索主流程"""
        route_res = await self.route_label(query)      # 1. 标签路由
        entry_nodes = await self.node_retrieval(...)    # 2. 节点检索
        cypher = await self.generate_cypher(...)        # 3. Cypher 生成
        errors = await self.validate_cypher(...)        # 4. Cypher 验证
        if errors:
            cypher = await self.correct_cypher(...)     # 5. Cypher 校正
        records = self.driver.execute_query(cypher)     # 6. 执行查询
        return [SearchResult(text=..., metadata=...) for rec in records]
```

**注册链条**：
```
ecs_demo/addons/information_retrieval.py 定义 GraphRAG
    ↓ config.yml 中声明：vector_store: addons.information_retrieval.GraphRAG
    ↓ Agent.load() 调用 create_retriever("addons.information_retrieval.GraphRAG", connect_config)
    ↓ importlib 动态加载类
    ↓ 验证是 InformationRetrieval 子类
    ↓ 实例化 → 调用 connect(endpoints.yml 的 vector_store 配置)
    ↓ 注入到 EnterpriseSearchPolicy
```

**关键约束**：`config.yml` 中的 `vector_store` 值必须是完整的 Python 类路径（模块.类名），且该模块对 `sys.path` 可达（ecs_demo/ 已被加入 sys.path）。

---

## 五、如何启动

### 5.1 前置条件

| 依赖 | 用途 | 是否必须 |
|------|------|---------|
| Python 3.10+ | 运行环境 | ✅ 必须 |
| MySQL | 订单/物流/售后数据存储 | ✅ 必须（ecs_demo 业务数据库） |
| Neo4j | 知识图谱存储 | 视需求（不用 GraphRAG 则不需要） |
| DashScope API Key | 通义千问 LLM | ✅ 必须（配置在 .env 中） |
| pip install -e . | 安装 hll_ai 框架 | ✅ 必须 |

### 5.2 安装框架

```bash
# 在项目根目录（setup.py 所在目录）
cd /path/to/llm_customer_service
pip install -e . -i https://pypi.tuna.tsinghua.edu.cn/simple
```

安装后会注册 `hll` 命令到系统 PATH。

### 5.3 准备业务数据

```bash
cd ecs_demo

# 1. 配置 .env 文件
# DASHSCOPE_API_KEY=sk-xxxxx
# MYSQL_PASSWORD=xxxxx
# NEO4J_PASSWORD=xxxxx  （如用 GraphRAG）

# 2. 生成模拟数据写入 MySQL
python gen_data.py
```

### 5.4 三种启动方式

#### 方式一：CLI 交互测试（开发调试首选）

```bash
cd ecs_demo
hll shell
```

启动后进入交互模式：
```
==================================================
hll AI - 交互式对话
==================================================

输入消息开始对话，或使用以下命令:
  /help    - 显示帮助信息
  /reset   - 重置对话
  /slots   - 显示当前槽位值
  /quit    - 退出

You: 我想查一下订单
Bot: 请选择订单
  选项:
    [1] [待发货]订单ID：ORD20250101001
    [2] [已发货]订单ID：ORD20250101002
    [3] 返回

You: 1
Bot: [待发货]**订单ID**：ORD20250101001
...
Bot: 还有什么我可以帮您的吗？
```

底层调用链：`InteractiveShell.run()` → `Agent.handle_message()` → LangGraph 图执行。

#### 方式二：API 服务（集成到前端）

```bash
cd ecs_demo
hll run
```

启动 FastAPI 服务（默认 `http://0.0.0.0:5005`）：
```
==================================================
hll AI - 对话服务
==================================================
模型路径: /path/to/ecs_demo
服务地址: http://0.0.0.0:5005
调试页面: 启用
CORS来源: ['*']

加载Agent...
Agent加载完成
启动服务器...

服务已启动: http://0.0.0.0:5005
API文档: http://0.0.0.0:5005/docs
调试页面: http://0.0.0.0:5005/inspect
按 Ctrl+C 停止服务
```

可用接口：
```bash
# 发送消息
curl -X POST http://localhost:5005/api/messages \
  -H "Content-Type: application/json" \
  -d '{"sender": "user1", "message": "查订单"}'

# 查询会话状态
curl http://localhost:5005/api/sessions/user1

# 重置会话
curl -X POST http://localhost:5005/api/sessions/user1/reset
```

底层调用链：`hllServer._register_routes()` → `Agent.handle_message()` → LangGraph 图执行。

#### 方式三：指定模型目录启动

```bash
# 如果已经 train 打包过模型
hll run --model ./ecs_demo/models/model-20250619.tar.gz

# 指定端口
hll run --port 8080

# 仅启用 REST（不启用 WebSocket）
hll run --channel rest
```

### 5.5 完整启动流程图

```
┌──────────────────────────────────────────────────────┐
│                    用户在 ecs_demo/ 目录下执行          │
│                    hll run / hll shell                │
└──────────────────────────┬───────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────┐
│  hll_ai/cli/__init__.py → main()                     │
│    ├── 加载 ecs_demo/.env 到环境变量                    │
│    └── 将 ecs_demo/ 加入 sys.path                      │
└──────────────────────────┬───────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────┐
│  hll_ai/cli/run.py 或 shell.py                        │
│    └── Agent.load("ecs_demo/")                        │
│          ├── 读取 config.yml + endpoints.yml           │
│          ├── Domain.load("ecs_demo/domain/")           │
│          ├── FlowLoader.load("ecs_demo/data/flows/")   │
│          ├── _load_custom_actions("ecs_demo/actions/") │
│          ├── create_retriever(GraphRAG, neo4j_config)  │
│          └── 组装 PolicyEnsemble + CommandGenerator    │
└──────────────────────────┬───────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────┐
│  服务就绪                                             │
│    ├── hll run  → hllServer(app).run(host, port)      │
│    └── hll shell → InteractiveShell(agent).run()      │
└──────────────────────────────────────────────────────┘
                           │
                    用户发消息 │
                           ▼
┌──────────────────────────────────────────────────────┐
│  Agent.handle_message(msg, sender_id)                 │
│    → LangGraph 图执行                                  │
│    → ecs_demo 的 Action/Retriever 被按需调用           │
│    → 返回 MessageResponse                             │
└──────────────────────────────────────────────────────┘
```

---

## 六、总结：一句话记忆

> **hll_ai 提供"引擎"（理解→决策→执行的循环），ecs_demo 提供"配方"（Flow 步骤 + Domain 定义 + Action 实现 + Retriever 实现）。启动时在 ecs_demo 目录下运行 `hll run` 或 `hll shell`，框架自动加载配方注入引擎，即可对外服务。**
