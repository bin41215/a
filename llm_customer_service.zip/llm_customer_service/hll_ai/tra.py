import functools
import inspect
import logging
from pathlib import Path

logger = logging.getLogger(__name__)
PROJECT_ROOT = Path(__file__).resolve().parent


def log_call_chain_on_warning(max_depth=8):
    """装饰器：被装饰的函数调用时自动打印调用链路（warning 级别）"""

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # 获取干净调用链路
            stack = inspect.stack()
            clean_frames = []
            for frame in stack[1:max_depth + 1]:
                frame_path = Path(frame.filename).resolve()
                if PROJECT_ROOT in frame_path.parents:
                    clean_frames.append(f"{frame_path.name}:{frame.lineno}")
            clean_frames.reverse()
            chain = " -> ".join(clean_frames) or "直接调用"

            logger.warning(
                "函数 [%s] 调用链路: %s | 入参: args=%s, kwargs=%s",
                func.__name__,
                chain,
                args,
                kwargs
            )
            # 执行原函数
            result = func(*args, **kwargs)
            # 可选：打印返回值
            # logger.debug("函数 [%s] 返回值: %s", func.__name__, result)
            return result

        return wrapper

    return decorator