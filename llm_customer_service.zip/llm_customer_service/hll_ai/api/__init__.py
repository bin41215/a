# -*- coding: utf-8 -*-
"""
hll_ai API模块

提供基于FastAPI的Web服务接口。
"""

from hll_ai.api.server import hllServer, create_app

__all__ = [
    "hllServer",
    "create_app",
]
