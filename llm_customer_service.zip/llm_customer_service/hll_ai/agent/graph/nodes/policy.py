# -*- coding: utf-8 -*-
"""
策略节点

负责调用 PolicyEnsemble 预测下一个动作。
"""

from __future__ import annotations

import logging
from typing import Any, Dict, TYPE_CHECKING

from hll_ai.policies.base_policy import PolicyPrediction
from hll_ai.shared.constants import ACTION_LISTEN

if TYPE_CHECKING:
    from hll_ai.agent.graph.state import MessageProcessingState

logger = logging.getLogger(__name__)


async def policy_node(state: "MessageProcessingState") -> Dict[str, Any]:
    """策略节点：预测下一个动作。
    
    该节点调用 PolicyEnsemble.predict() 来决定系统应该执行什么动作。
    如果 CommandProcessor 已经确定了 next_action，优先使用该动作（仅第一轮）。
    如果预测的动作是 action_listen，则标记处理完成。
    
    Args:
        state: 当前图状态
        
    Returns:
        状态更新字典
    """
    tracker = state["tracker"]
    domain = state.get("domain")
    flows = state.get("flows")
    policy_ensemble = state.get("_policy_ensemble")
    process_result = state.get("process_result")
    action_count = state.get("action_count", 0)

    # 日志：打印每个变量的关键信息
    logger.warning(
        f"[policy_node] tracker 信息: "
        f"sender_id={getattr(tracker, 'sender_id', None)}, "
        f"active_flow={getattr(tracker, 'active_flow', None)}, "
        f"latest_action={getattr(tracker, 'latest_action_name', None)}, "
        f"slots={tracker.get_all_slots() if hasattr(tracker, 'get_all_slots') else None}, "
        f"latest_message={tracker.latest_message.text if getattr(tracker, 'latest_message', None) else None}"
    )
    if domain:
        logger.warning(
            f"[policy_node] domain 信息: "
            f"type={type(domain).__name__}, "
            f"slots_count={len(domain.slots) if hasattr(domain, 'slots') else None}, "
            f"actions={list(domain.actions) if hasattr(domain, 'actions') else None}, "
            f"responses_count={len(domain.responses) if hasattr(domain, 'responses') else None}, "
            f"flows={domain.flows if hasattr(domain, 'flows') else None}"
        )
    else:
        logger.warning("[policy_node] domain 信息: None")
    if flows:
        logger.warning(
            f"[policy_node] flows 信息: "
            f"type={type(flows).__name__}, "
            f"flows_count={len(flows) if hasattr(flows, '__len__') else None}, "
            f"flow_ids={flows.flow_ids if hasattr(flows, 'flow_ids') else None}"
        )
    else:
        logger.warning("[policy_node] flows 信息: None")
    if policy_ensemble:
        logger.warning(
            f"[policy_node] policy_ensemble 信息: "
            f"type={type(policy_ensemble).__name__}, "
            f"module={type(policy_ensemble).__module__}, "
            f"policies={[type(p).__name__ for p in policy_ensemble.policies] if hasattr(policy_ensemble, 'policies') else None}, "
            f"policy_names={policy_ensemble.policy_names if hasattr(policy_ensemble, 'policy_names') else None}, "
            f"config={getattr(policy_ensemble, 'config', None)}"
        )
    else:
        logger.warning("[policy_node] policy_ensemble 信息: None")
    if process_result:
        logger.warning(
            f"[policy_node] process_result 信息: "
            f"type={type(process_result).__name__}, "
            f"next_action={getattr(process_result, 'next_action', None)}, "
            f"response_type={getattr(process_result, 'response_type', None)}, "
            f"commands_executed={getattr(process_result, 'commands_executed', None)}, "
            f"success={getattr(process_result, 'success', None)}, "
            f"events_count={len(process_result.events) if hasattr(process_result, 'events') else None}, "
            f"metadata={getattr(process_result, 'metadata', None)}"
        )
    else:
        logger.warning("[policy_node] process_result 信息: None")
    logger.warning(f"[policy_node] action_count={action_count}")

    logger.warning("[policy_node] 开始策略预测")
    
    # 默认预测结果
    current_prediction = None
    is_finished = True  # 如果没有策略集成器，默认结束
    
    try:
        # 优先使用 CommandProcessor 确定的 next_action（仅第一轮，action_count == 0）
        if action_count == 0 and process_result and process_result.next_action:
            next_action = process_result.next_action
            # 跳过 action_run_flow_* 类型的动作，这些由 FlowPolicy 处理
            if not next_action.startswith("action_run_flow_"):
                current_prediction = PolicyPrediction(
                    action=next_action,
                    confidence=1.0,
                    policy_name="CommandProcessor",
                    metadata=process_result.metadata,
                )
                is_finished = (next_action == ACTION_LISTEN)
                
                logger.warning(
                    f"[policy_node] 使用 CommandProcessor 动作: {next_action}, "
                    f"是否结束: {is_finished}"
                )
                
                return {
                    "current_prediction": current_prediction,
                    "is_finished": is_finished,
                    "node_history": state.get("node_history", []) + ["policy"],
                }
        
        # 否则使用 PolicyEnsemble 预测
        if policy_ensemble:
            prediction = await policy_ensemble.predict(tracker, domain, flows)
            current_prediction = prediction
            logger.warning(f"current_prediction is {current_prediction}")
            
            # 检查是否应该结束（action_listen 表示等待用户输入）
            is_finished = (prediction.action == ACTION_LISTEN or prediction.action is None)
            
            logger.warning(
                f"[policy_node] 预测动作: {prediction.action}, "
                f"置信度: {prediction.confidence:.2f}, "
                f"是否结束: {is_finished}"
            )
        else:
            logger.warning("[policy_node] 未配置策略集成器，跳过预测")
            
    except Exception as e:
        logger.error(f"[policy_node] 预测失败: {e}")
        return {
            "current_prediction": None,
            "is_finished": True,
            "error": str(e),
            "node_history": state.get("node_history", []) + ["policy"],
        }
    
    return {
        "current_prediction": current_prediction,
        "is_finished": is_finished,
        "node_history": state.get("node_history", []) + ["policy"],
    }


# 导出
__all__ = ["policy_node"]
