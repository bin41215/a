# 新增 Flow 的逻辑与 care 示例

> 本文档说明在 `ecs_demo` 中新增一个 Flow 的底层逻辑、需要改动的文件、Flow YAML 语法要点，并给出一个 `care`（客户关怀）flow 的完整落地示例。所有结论均基于源码实测。

---

## 一、底层逻辑：新增 flow 靠的是 5 个"自动机制"

框架对 flow 是 **配置驱动 + 约定优于注册**，所以新增 flow 本质是"放对文件 + 名字对齐"，不用改框架代码、不用写注册语句：

| 机制 | 发生在哪 | 对新增 flow 的含义 |
|---|---|---|
| ① 目录扫描加载 | `FlowLoader.load()` 用 `glob("*.yml")` 扫 `data/flows/`（`flow_loader.py:83`） | 新 YAML 丢进目录即自动加载，**无需在任何列表登记** |
| ② 自动进 LLM prompt | `PromptBuilder._prepare_flows_data` 把每个 flow 渲染成 `{id, description, slots_to_collect}`（`prompt_builder.py:207-211`） | flow 的 **`id`（YAML 键）+ `description`** 决定 LLM 何时触发 |
| ③ 触发靠 LLM，不靠检索器 | `FlowRetriever` 运行时**根本没被调用**（全仓只在 export 处出现） | 用户意图 → LLM 看 prompt → 输出 `StartFlow(<id>)` → `StartFlowCommand.run` 压栈。**`description` 写不好就不触发** |
| ④ collect 自动找询问动作 | collect 步骤未指定 action → 先 `utter_ask_<slot>`，domain 没有则 fallback 到 `action_ask_<slot>`（`flow_executor.py:238`） | 槽位名 `xxx` 会自动映射到 `action_ask_xxx` / `utter_ask_xxx` |
| ⑤ Action 自动注册 | `_load_custom_actions` 扫 `actions/*.py`，Action 子类实例化进全局表（`agent.py:43`） | `.py` 丢进 `actions/` 即注册，`name` 属性必须与 flow/domain 里写的名字**完全一致** |

**一句话合约**：动 4 处文件（flow YAML / domain YAML / action py / 可选 DB 表），保证 `flow id`、`slot 名`、`action name` 三者对齐，重启即可。

---

## 二、需要改动的文件清单

```
ecs_demo/
├── data/flows/flow_care.yml      ← ① flow 定义（步骤、分支、槽位）
├── domain/domain_care.yml        ← ② 声明 slots + actions（+可选 responses）
├── actions/action_care.py         ← ③ Action 实现（查库/拼按钮/出详情）
└── actions/db_table_class.py     ← ④（可选）新增 CareInfo 表模型
```

> domain 文件也是目录扫描合并（`Domain.load("domain/")`），新文件无需登记。**改完要重启 `hll run`**（无热加载）。

---

## 三、Flow YAML 语法要点（基于解析器真实行为）

- **step 类型**（`flow.py:15-23`）：`collect`（收槽位）/ `set_slot`（写槽位）/ `action`（执行动作）/ `condition`（if 分支）/ `link`（切流程）/ `call`（调子流程）/ `end`。
- **`next` 自动链接**：没写 `next` 的步骤自动指向下一步（`flow.py:228`）。
- **`next` 两种形式**：字符串（步骤 id / `END`），或条件列表 `- if: slots.x != "false" / then: ... / else: END`。
- **collect 的 ask 降级链**：`utter_ask_<slot>` →（无响应则）`action_ask_<slot>`。
- **`ask_before_filling: true`**：每次进入该步骤都清空槽位重新问，避免残留。
- **`next: END`**：触发 `action_flow_completed` 并按 flow 作用域重置其中收集的槽位（`flow_policy.py:321`）。
- **⚠️ 坑**：`set_slots:`（复数 + 列表）**解析器不认**，`goto` 等槽位不会被写入（已实测）。要写槽位必须用单数 dict：`set_slot: {goto: xxx}`。

---

## 四、动手示例：新增 `query_care_record` flow

### ① `ecs_demo/data/flows/flow_care.yml`

```yaml
# -*- coding: utf-8 -*-
# 关怀模块 Flow 定义
version: "3.1"

flows:
  query_care_record:
    name: 查询关怀记录
    description: 查询客户关怀记录、回访记录、关怀任务进度     # ← LLM 靠这句话触发
    steps:
      - collect: care_id            # 自动调用 action_ask_care_id（弹按钮选关怀记录）
        ask_before_filling: true     # 每次重新问，避免槽位残留
        next:
          - if: slots.care_id != "false"
            then:
              - action: action_get_care_detail   # 查详情
                next: END
          - else: END
```

### ② `ecs_demo/domain/domain_care.yml`

```yaml
# -*- coding: utf-8 -*-
# 关怀模块 Domain 定义
version: "3.1"

slots:
  care_id:                          # 关怀记录ID（由按钮设置）
    type: text
    mappings:
      - type: controlled            # controlled = 来自 action/按钮，非 LLM 自由文本

actions:
  - action_ask_care_id              # 名字必须与 collect 的 care_id 对应（action_ask_<slot>）
  - action_get_care_detail          # 名字必须与 flow 里 action: 字段一致

# 可选：若想用纯文本询问而非自定义 action，可加 responses:
# responses:
#   utter_ask_care_id:
#     - text: "请输入关怀记录ID"
```

> 不写 `utter_ask_care_id` 时，collect 会 fallback 到 `action_ask_care_id`——这正是我们要的（要弹按钮，所以走 action）。

### ③ `ecs_demo/actions/action_care.py`

```python
# -*- coding: utf-8 -*-
"""关怀相关 Action"""
import logging
from typing import Any, Optional
from hll_ai.agent.actions import Action, ActionResult

logger = logging.getLogger(__name__)


class ActionAskCareId(Action):
    """查询当前用户的关怀记录，返回按钮供选择。"""

    @property
    def name(self) -> str:                     # ← 必须叫 action_ask_care_id
        return "action_ask_care_id"

    async def run(self, tracker: Any, domain: Optional[Any] = None, **kwargs: Any) -> ActionResult:
        from actions.db import SessionLocal
        from actions.db_table_class import CareInfo   # ← 需先在 db_table_class.py 建模型

        result = ActionResult()
        user_id = tracker.get_slot("user_id") or "1001"

        try:
            with SessionLocal() as session:
                cares = session.query(CareInfo).filter_by(user_id=user_id).all()
                if not cares:
                    result.add_response("暂无关怀记录")
                    tracker.set_slot("care_id", "false")   # 触发 else: END
                    result.reject_action_listen = True      # 打断流程
                    return result

                buttons = [
                    {
                        "title": f"[{c.care_type}] {c.title} ({c.care_time})",
                        "payload": f"/SetSlots(care_id={c.care_id})",
                    }
                    for c in cares
                ]
                buttons.append({"title": "返回", "payload": "/SetSlots(care_id=false)"})
                result.add_response("请选择关怀记录", buttons=buttons)
        except Exception as e:
            logger.error(f"查询关怀记录失败: {e}")
            result.add_response("查询关怀记录时出错，请稍后重试。")
        return result


class ActionGetCareDetail(Action):
    """获取关怀记录详情。"""

    @property
    def name(self) -> str:                     # ← 必须叫 action_get_care_detail
        return "action_get_care_detail"

    async def run(self, tracker: Any, domain: Optional[Any] = None, **kwargs: Any) -> ActionResult:
        from actions.db import SessionLocal
        from actions.db_table_class import CareInfo

        result = ActionResult()
        care_id = tracker.get_slot("care_id")
        if not care_id or care_id == "false":
            result.add_response("未找到该关怀记录。")
            return result

        try:
            with SessionLocal() as session:
                c = session.query(CareInfo).filter_by(care_id=care_id).first()
                if not c:
                    result.add_response("未找到该关怀记录。")
                    return result
                result.add_response(
                    f"- [{c.care_type}] {c.title}\n"
                    f"  时间：{c.care_time}\n  内容：{c.content}"
                )
        except Exception as e:
            logger.error(f"获取关怀详情失败: {e}")
            result.add_response("获取关怀记录详情时出错。")
        return result
```

### ④（可选）DB 表模型 `actions/db_table_class.py`

仿照现有 `OrderInfo` 加一个 `CareInfo`（`care_id` / `user_id` / `care_type` / `title` / `care_time` / `content`），并在 MySQL `ecs` 库建表灌数据。若先不想动 DB，可把上面 action 的查库部分换成返回写死的桩数据先跑通流程。

---

## 五、验证

```bash
cd ecs_demo && hll run --model .        # 重启，自动加载新 flow
```

1. 看 `Agent.load` 日志：`Loaded 8 flows`（原 7 + care）、`Registered custom action: action_ask_care_id` / `action_get_care_detail`。
2. 看 `PromptBuilder.build_messages` 日志：生成的 prompt 里 `flows` JSON 应包含 `query_care_record`。
3. 触发：

```bash
curl -X POST http://localhost:5005/api/messages \
  -H "Content-Type: application/json" \
  -d '{"sender":"u1","message":"查一下我的关怀记录"}'
```

   日志应出现 `[understand_node] 生成了 1 个命令: StartFlow(query_care_record)` → FlowPolicy 推进 → `action_ask_care_id` 弹按钮。
4. 点按钮发 `/SetSlots(care_id=xxx)` → `action_get_care_detail` 出详情 → `action_flow_completed` 结束。

---

## 六、常见坑（实测/源码确认）

| 坑 | 现象 | 规避 |
|---|---|---|
| `set_slots:` 复数列表 | goto 等槽位不写入，查询退化为默认分支 | 用单数 `set_slot: {key: value}` |
| Action `name` 与 flow/domain 不一致 | `get_action` 返回 None，collect 无输出 | `name` 必须逐字等于 `action_ask_care_id` 等 |
| slot 没在 domain 声明 | `force_slot_filling` 过滤掉 `SetSlotCommand`，按钮点击无效 | `care_id` 必须进 `domain_care.yml` 的 `slots:` |
| `description` 太弱/太泛 | LLM 不触发该 flow，误走闲聊/别的 flow | description 写清业务语义，与别的 flow 区分 |
| `description` 与现有 flow 重叠 | LLM 在多个 flow 间犹豫 | 用差异化关键词（关怀/回访/任务进度） |
| 想用按钮结果分流的查询（像订单 goto） | 同样受 set_slots bug 影响 | 用 set_slot 单数，并在 action 里读该槽分流 |

---

## 附：执行链路回顾（flow 被触发后发生了什么）

```
用户"查我的关怀记录"
  │  LLM 看 prompt(含 query_care_record 的 id+description+slots) → 输出 StartFlow(query_care_record)
  ▼
understand_node: CommandProcessor 执行 StartFlowCommand → tracker.start_flow 压栈
  ▼
FlowPolicy.predict (循环执行步骤)
  └─ step_0 (collect care_id, 槽空)
       action = utter_ask_care_id  +  fallback_action = action_ask_care_id
  ▼
action_node: ActionUtter(无响应) → fallback → ActionAskCareId.run() 弹按钮
  ▼
is_finished=True (slot_to_collect=care_id)  等待用户
  │
  ▼  用户点按钮 /SetSlots(care_id=xxx)
FlowPolicy 再跑 collect → care_id 已填 → _get_nested_action
  ├─ care_id != false → action_get_care_detail → END → action_flow_completed (重置 care_id)
  └─ care_id == false → END
```
