# 为什么新增内容要打包到 models/*.tar.gz 后才生效

> 本文解释在 `ecs_demo` 中新增/修改 flow、domain 等源码后，为什么必须重新打包 `models/*.tar.gz` 才会被运行时加载，以及如何让改动生效。

---

## 一、直接原因：`Agent.load` 的加载优先级

`Agent.load`（`hll_ai/agent/agent.py:385-398`）在传入一个项目目录时的行为：

```
传入一个目录(如 ecs_demo)时:
  1. 检查 该目录/models/ 下有没有 *.tar.gz
  2. 有  → 解压最新的 tar.gz 到 temp 目录，从 temp 加载   ← 源码目录被完全忽略
  3. 没有→ 才回退读该源码目录
```

关键代码：
```python
elif project_path.is_dir():
    models_dir = project_path / "models"
    latest_model = get_latest_model(models_dir)   # ← 找到 models/*.tar.gz
    if latest_model:
        # 解压 tar.gz 到 temp 目录，从 temp 加载，而非读源码目录！
        extract_model_archive(latest_model, temp_dir)
        working_path = Path(temp_dir)
```

**只要 `ecs_demo/models/*.tar.gz` 存在，运行时加载的就是 tar.gz 里的内容，不是源码目录。** 新加的 `flow_care.yml`/`domain_care.yml` 在源码目录里，但 tar.gz 是旧快照、不含这些文件 → 解压出的 temp 目录里没有 care → 加载的 flows 还是旧的 → "改了不生效"。

**重新打包**就是把源码目录的最新内容（含 care）重新压进 `models/*.tar.gz`，让那个被优先加载的快照与源码一致，于是生效。

---

## 二、为什么框架要这么设计（不是 bug，是刻意的）

`models/*.tar.gz` 是框架的**"发布制品 / 模型包"**概念（见 `hll_ai/training/model_storage.py`）：

- 它把 `config.yml + endpoints.yml + domain/ + data/flows/ + actions/ + 训练产物` 冻结成**一个可版本化、可移植、可复现**的制品（文件名带时间戳 `model-YYYYMMDD-HHMMSS.tar.gz`）。
- 生产部署应从一个**固定、版本化的制品**跑，而不是从"运行时源码目录里碰巧有什么"跑——这样"测的就是发的、发的就是测的"，避免源码被随手改动导致线上漂移。
- 类比：Rasa 的 trained model 包、Docker image、编译产物——改源码后必须"重新构建"才会被部署。

所以加载优先级是 **制品 > 源码**，源码只是没有制品时的兜底。

---

## 三、两个让改动生效的办法

本质都是"让被加载的东西包含你的改动"：

| 办法 | 做法 | 适用 |
|---|---|---|
| **重新打包**（正式） | `hll train` / `hll export` 重新生成 `models/*.tar.gz`，让快照含 care | 生产/正式 |
| **移走 tar.gz**（开发） | 把 `models/*.tar.gz` 移走/删掉，`Agent.load` 回退读源码目录 | 本地开发调试 |

---

## 四、⚠️ 注意：`--model .` 也绕不过

很多人以为 `hll run --model .` 会读 ecs_demo 源码——其实不行。`--model .` 传给 `Agent.load(".")`，它照样会去 `./models/` 找 tar.gz 并解压。**只要 `ecs_demo/models/*.tar.gz` 在，源码就不被读**。

开发期要读源码，只能：
- 把 `models/*.tar.gz` 移走；或
- 临时改 `models/` 目录名（如 `models_bak/`），让 `get_latest_model` 找不到。

没有 CLI flag 能强制从源码目录加载。

---

## 五、实操验证（实测）

- 加完 `flow_care.yml` + `domain_care.yml` 后，**未动 tar.gz** 时渲染 prompt：`flows=7`、无 `care_id` → care 没生效。
- 把 `models/*.tar.gz` 临时移到 `/tmp` 后再渲染：`flows=13`、`含 care_id=True`、prompt 里出现 `query_care_record` → care 生效。
- 移回 tar.gz 后恢复原状。

---

## 六、顺带发现

源码目录已有 **13 个 flow**，但 6/19 的 tar.gz 旧快照只有 7 个——源码已经比快照新了（含 5 个任务诊断 flow + care）。**建议重新打包一次 tar.gz 让快照与源码一致**，避免后续"改了不生效"的困惑。

---

## 七、一句话

> 因为 `Agent.load` 把 `models/*.tar.gz` 当作权威发布制品优先加载、源码目录只是兜底；源码改动不进 tar.gz 就进不了运行时，所以必须重新打包（或删掉 tar.gz 回退源码）才生效。这是"从版本化制品部署"的刻意设计，开发期要小心它会让"改源码没反应"。

---

## 八、相关文件

| 内容 | 文件 |
|---|---|
| Agent.load 路径解析（tar.gz 优先） | `hll_ai/agent/agent.py:385-398` |
| 模型打包 / 解压 | `hll_ai/training/model_storage.py` |
| 取最新模型 | `model_storage.py:get_latest_model` |
| 打包命令 | `hll train` / `hll export`（`hll_ai/cli/train.py`、`export.py`） |
