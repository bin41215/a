# 添加 flow+domain 后的完整 Prompt

> 本文展示在 `ecs_demo` 中新增 `care`（客户关怀）flow + domain 后，发给 LLM 的**完整 prompt**，并指出新增内容在 prompt 中的位置、以及一个让新增"不生效"的关键坑（`Agent.load` 优先加载 `models/*.tar.gz` 旧快照）。

---

## 一、如何渲染出这份 prompt

不走 LLM，纯模板渲染（`PromptBuilder.build_prompt`），输入：
- 项目：`ecs_demo`（已含新增的 `data/flows/flow_care.yml` + `domain/domain_care.yml`）
- 用户消息：`查一下我的关怀记录`
- 当前不在任何 Flow 中（首轮）

渲染脚本核心：
```python
from hll_ai.agent.agent import Agent
from hll_ai.core.tracker import UserMessage

agent = Agent.load("ecs_demo")
tracker = await agent.tracker_store.get_or_create_tracker("prompt_demo")
tracker.update_with_message(UserMessage(text="查一下我的关怀记录", sender_id="prompt_demo"))
prompt = agent.command_generator.prompt_builder.build_prompt(tracker, agent.domain, agent.flows)
print(prompt)
```

---

## 二、完整 Prompt

````
## 任务说明
分析当前对话上下文，生成相应的命令来启动业务流程（Flow）、提取槽位信息，或处理闲聊和知识检索请求。

---

## 可用 Flows 和槽位
```json
{"flows":[
  {"name":"query_logistics_companys","description":"查询支持的快递公司"},
  {"name":"query_shipping_order_logistics","description":"查询订单的物流信息","slots":[{"name":"order_id","type":"text"}]},
  {"name":"diagnose_task_error","description":"分析任务运行失败原因并给出处理建议、诊断任务错误、查看任务失败原因","slots":[{"name":"task_id"},{"name":"instance_id"}]},
  {"name":"query_task_status","description":"查询任务运行状态、查看任务状态、任务执行情况","slots":[{"name":"task_id"},{"name":"instance_id"}]},
  {"name":"query_task_logs","description":"获取任务日志、查看任务日志、任务运行日志","slots":[{"name":"task_id"},{"name":"instance_id"},{"name":"log_type"}]},
  {"name":"query_task_dependencies","description":"获取任务依赖关系、查看任务依赖、任务上下游依赖","slots":[{"name":"task_id"},{"name":"dependency_type"}]},
  {"name":"batch_query_task_status","description":"批量查询多个任务的运行状态","slots":[{"name":"task_ids"}]},
  {"name":"query_care_record","description":"查询客户关怀记录、回访记录、关怀任务进度","slots":[{"name":"care_id","type":"text"}]},
  {"name":"switch_user_id","description":"切换账号、切换用户、更换用户ID","slots":[{"name":"user_id","description":"用户ID","type":"text"}]},
  {"name":"query_order_detail","description":"查询订单详情","slots":[{"name":"order_id","type":"text"}]},
  {"name":"modify_order_receive_info","description":"修改订单收货信息","slots":[{"name":"order_id","type":"text"},{"name":"receive_id","type":"text"},{"name":"modify_content","type":"text"},{"name":"if_modify_continue","type":"text"},{"name":"set_receive_info","type":"text"}]},
  {"name":"cancel_order","description":"取消订单","slots":[{"name":"order_id","type":"text"},{"name":"if_cancel_order","type":"text"}]},
  {"name":"apply_postsale","description":"当用户想要申请退货或换货时使用","slots":[{"name":"postsale_order_id","description":"售后订单ID","type":"text"},{"name":"postsale_type","description":"售后类型（退货/换货）","type":"text"},{"name":"postsale_reason","description":"售后原因","type":"text"}]}
]}
```

---

## 可用命令

### Flow 控制命令
* `start flow <flow_name>`: 启动一个业务流程。例如：`start flow transfer_money`
* `cancel flow`: 取消当前正在执行的流程（仅当用户明确要求时使用）
* `change flow <flow_name>`: 切换到另一个流程

### 槽位命令
* `set slot <slot_name> <value>`: 设置槽位值。例如：`set slot user_name "张三"`
  - 字符串值用引号包围
  - 数字直接写：`set slot amount 100`
  - 布尔值：`set slot confirmed true`

### 回答命令
* `knowledge_answer`: 从知识库检索答案回复用户问题。当用户咨询知识类问题且没有匹配的 Flow 时使用。
* `chitchat`: 处理闲聊消息。当用户发送问候、感谢等非业务性消息时使用。
* `cannot_handle`: 无法理解或处理用户请求。

### 会话命令
* `clarify`: 当用户意图不明确时，请求用户澄清。
* `human_handoff`: 转接人工客服。当用户明确要求或系统无法解决时使用。

---

## 命令生成规则

### 启动 Flow
* 仅当用户意图与某个 Flow 的描述完全匹配时才启动
* 注意 Flow 描述的精确范围，不要过度推测
* **重要：启动 Flow 时，不要从对话历史中推断槽位值。应该只输出 `start flow` 命令，让系统引导用户提供所需信息**

### 设置槽位
* 只从用户**当前消息**中明确提供的信息提取，不要猜测或填充占位符
* **禁止**从对话历史中推断槽位值 - 每个 Flow 的槽位必须由用户在当前对话中重新提供
* 分类槽位：匹配允许的值列表，无法匹配时填 "other"
* 布尔槽位：肯定回答映射为 `true`，否定映射为 `false`
* 文本槽位：保持用户原话，不做修改

### 知识检索优先级
* 如果不确定是启动 Flow 还是使用 `knowledge_answer`，优先尝试启动 Flow

### 取消 Flow
* 除非用户明确要求取消，否则不要取消任何 Flow
* 用户可以在一个 Flow 进行中启动另一个 Flow

### 通用规则
* 只使用用户提供的信息
* 严格遵守上述命令格式
* 专注于处理用户最新消息
* 只参考历史消息来辅助理解上下文

---

## 决策规则表
| 条件 | 动作 |
|------|------|
| 用户意图精确匹配某个 Flow | `start flow` |
| 用户提供了槽位信息 | `set slot` |
| 用户询问知识性问题，无匹配 Flow | `knowledge_answer` |
| 用户发送问候、感谢等闲聊 | `chitchat` |
| 用户意图不清晰 | `clarify` |
| 用户要求转人工 | `human_handoff` |
| 无法处理 | `cannot_handle` |

---

## 当前状态
当前不在任何 Flow 中。只有先启动一个 Flow，才能设置该 Flow 的槽位。

**重要规则**：启动新 Flow 时，只输出 `start flow <name>` 命令。即使对话历史中提到过相关信息（如订单号、手机号等），也**不要**同时设置槽位。让系统通过流程引导用户重新提供必要信息。

---

## 对话历史
用户: 查一下我的关怀记录

---

## 任务
根据用户最新消息生成命令列表（每行一个命令）：

用户消息："""查一下我的关怀记录"""

你的命令列表：
````

---

## 三、添加的 flow/domain 出现在 prompt 的哪里

1. **flows JSON** 多了一项（LLM 拿它和用户消息做语义匹配来触发）：
   ```json
   {"name":"query_care_record","description":"查询客户关怀记录、回访记录、关怀任务进度","slots":[{"name":"care_id","type":"text"}]}
   ```
   这就是 `flow_care.yml` 里 `id + description + collect(care_id)` 三样被 `_prepare_flows_data`（`prompt_builder.py:207`）渲染进去的结果。

2. **slots**：`care_id` 进了 `slot_info`（domain slots 18→19），所以 care_id 的 type/description 也会被 LLM 看到。

3. **actions 声明**（`action_ask_care_id`/`action_get_care_detail`）**不进 prompt**——prompt 只渲染 flow 的 id/description/slots，action 名只在运行时由 `action_node` 用 `get_action` 查注册表。所以即使还没写 action 的 .py，prompt 也能正常渲染。

---

## 四、⚠️ 关键坑：新增 flow/domain 不生效（实测）

加完 care 文件后，第一次渲染 prompt 里**根本没有 care flow**（仍是 7 个）。根因在 `Agent.load`（`agent.py:385-398`）：

```python
elif project_path.is_dir():
    models_dir = project_path / "models"
    latest_model = get_latest_model(models_dir)   # ← 找到 models/*.tar.gz
    if latest_model:
        # 解压 tar.gz 到 temp 目录，从 temp 加载，而非读源码目录！
        extract_model_archive(latest_model, temp_dir)
        working_path = Path(temp_dir)
```

即：`ecs_demo/models/` 里有 `model-20260619-*.tar.gz`（6/19 打的旧快照，不含 care），`Agent.load("ecs_demo")` 会**优先解压这个旧快照**到 temp 目录加载，新加的 `flow_care.yml`/`domain_care.yml` 在源码目录里**根本不被读**。这就是"改了源码却不生效"的根因。

### 让新增 flow/domain 真正生效的两种办法

1. **临时**：把 `ecs_demo/models/*.tar.gz` 移走/删掉 → `Agent.load` 回退到读源码目录（本文档的 prompt 就是这样渲染出来的）。
2. **正式**：改完源码后用 `hll train` / `hll export` 重新打包 `models/*.tar.gz`，让快照和源码同步。

---

## 五、顺带发现

源码目录其实已有 **13 个 flow**（不是 6/19 旧快照里的 7 个）——除 care 外还有 5 个任务诊断 flow：
`diagnose_task_error`、`query_task_status`、`query_task_logs`、`query_task_dependencies`、`batch_query_task_status`。

它们在源码里但不在 6/19 的 tar.gz 快照里。说明源码已经比快照新了，**建议重新打包一次 tar.gz 让快照与源码一致**，避免后续"改了不生效"的困惑。

---

## 六、相关文件

| 内容 | 文件 |
|---|---|
| 新增的 flow | `ecs_demo/data/flows/flow_care.yml` |
| 新增的 domain | `ecs_demo/domain/domain_care.yml` |
| Prompt 构建器 | `hll_ai/dialogue_understanding/generator/prompt_builder.py` |
| Prompt 模板 | `hll_ai/dialogue_understanding/generator/templates/command_prompt.jinja2` |
| Agent.load 路径解析（tar.gz 优先） | `hll_ai/agent/agent.py:385-398` |
| 模型打包/解压 | `hll_ai/training/model_storage.py` |
