# `dialogue_stack` 模块分析

## 一、作用

`DialogueStack` 是对话系统的**核心状态容器**，用后进先出（LIFO）栈结构管理对话过程中的所有上下文帧。它回答了一个根本问题：**「系统此刻正在做什么？」**

系统中的每一种对话模式（执行 Flow、知识库搜索、闲聊、人工转接、无法处理、已完成）都对应一种栈帧类型，压入栈顶即表示该模式正在执行，弹出则表示结束。

```
┌─────────────────────────────────────┐
│         DialogueStack               │
│  frames: [Frame, Frame, Frame]      │  ← 栈顶 = 当前活跃帧
│                                     │
│  StackFrame (抽象基类)              │
│    ├─ FlowStackFrame       ← Flow对话流程│
│    ├─ SearchStackFrame     ← 知识库搜索  │
│    ├─ ChitChatStackFrame   ← 闲聊      │
│    ├─ CannotHandleStackFrame← 无法处理  │
│    ├─ CompletedStackFrame  ← Flow已完成 │
│    └─ HumanHandoffStackFrame← 人工转接  │
└─────────────────────────────────────┘
```

## 二、创建

### 1）初始创建 — 在 `DialogueStateTracker.__init__` 中

```python
# tracker.py:183
self.dialogue_stack: DialogueStack = DialogueStack()
```

每次新建会话时，栈为空列表，表示系统空闲。

### 2）从持久化恢复 — 在 `Tracker.from_dict` 中

```python
# tracker.py:594-595
if "dialogue_stack" in data:
    tracker.dialogue_stack = DialogueStack.from_dict(data["dialogue_stack"])
```

通过 `as_dict()` / `from_dict()` 实现序列化-反序列化，存储层（MySQL 等）保存的 JSON 在加载时还原为完整对象。帧类型的反序列化通过全局注册表 `_FRAME_TYPE_REGISTRY` + `@register_frame_type` 装饰器实现：每个帧类声明自己的 `type` 字符串（如 `"flow"`、`"search"`），`create_frame_from_dict` 根据 `type` 字段分发到对应类的 `from_dict` 方法。

## 三、调用 — 三大写入方

栈的变动由三类角色驱动：

### ① Command 命令（LLM 理解阶段压栈）

LLM 生成 DSL 命令后，由 `CommandProcessor` 解析执行，命令的 `run()` 方法直接操作栈：

| 命令 | 压入的栈帧 | 代码位置 |
|---|---|---|
| `StartFlowCommand` | `FlowStackFrame` | `tracker.start_flow()` → `dialogue_stack.push_flow()` |
| `SetSlotCommand` + ChitChat | `ChitChatStackFrame` | `answer_commands.py:60` |
| `SetSlotCommand` + CannotHandle | `CannotHandleStackFrame` | `answer_commands.py:126` |
| `SetSlotCommand` + Search | `SearchStackFrame` | `answer_commands.py:195` |
| `HumanHandoffCommand` | `HumanHandoffStackFrame` | `session_commands.py:186` |

**核心流程**：

```
用户消息 → understand_node → LLMCommandGenerator → "start flow order_status"
         → CommandProcessor.run_commands() → StartFlowCommand.run()
         → tracker.start_flow("order_status") → dialogue_stack.push_flow("order_status")
```

### ② FlowPolicy 策略预测阶段（读写栈顶帧）

FlowPolicy 是系统最高优先级策略，每轮预测时：

- **读** — `tracker.dialogue_stack.top_flow_frame()` 获取当前 Flow 帧，读取 `flow_id`、`step_id`、`slot_to_collect`、`completing` 等属性
- **写** — 更新栈顶帧属性：
  - `flow_frame.slot_to_collect = result.slot_to_collect`（标记正在收集的槽位）
  - `flow_frame.completing = True`（标记 Flow 即将完成）
  - `self.executor.advance_flow()` → `flow_frame.advance_to_step(next_step_id)`
- **弹** — `tracker.end_flow()` → `dialogue_stack.pop_to_flow()` + `pop()` 结束 Flow 后压入 `CompletedStackFrame`

```python
# flow_policy.py:108-125 — completing 检测
flow_frame = tracker.dialogue_stack.top_flow_frame()
if flow_frame and flow_frame.completing:
    tracker.end_flow()
    return PolicyPrediction(action="action_flow_completed", ...)
```

### ③ EnterpriseSearchPolicy 策略预测阶段（读栈顶 + 弹栈）

EnterpriseSearchPolicy 根据栈顶帧类型分发处理：

```python
# enterprise_search_policy.py:203
top_frame = tracker.dialogue_stack.top()

if isinstance(top_frame, CompletedStackFrame):    → 生成"还有其他需要吗"
if isinstance(top_frame, HumanHandoffStackFrame): → 生成转接话术
if isinstance(top_frame, ChitChatStackFrame):     → 生成闲聊回复
if isinstance(top_frame, CannotHandleStackFrame): → 生成兜底回复
if isinstance(top_frame, SearchStackFrame):       → 执行RAG检索 → pop()
```

处理完成后弹出对应栈帧：`tracker.dialogue_stack.pop()`

## 四、Action 动作执行阶段

部分 Action 也会操作栈（属于间接调用，通过 tracker 方法）：

| Action | 操作 |
|---|---|
| `ActionCannotHandle` | `tracker.dialogue_stack.push(CannotHandleStackFrame())` |
| `ActionChitChat` | `tracker.dialogue_stack.push(ChitChatStackFrame())` |
| `ActionEndFlow` | `tracker.end_flow()` → pop 栈 |
| `ActionChangeFlow` | `tracker.end_flow()` + `tracker.start_flow(new_flow)` |
| `ActionCancelFlow` | `tracker.cancel_flow()` → `dialogue_stack.clear()` |
| `ActionHumanHandoff` | `tracker.dialogue_stack.push(HumanHandoffStackFrame())` |
| `ActionSearchKnowledge` | `tracker.dialogue_stack.push(SearchStackFrame())` |
| `ActionFlowCompleted` | `tracker.dialogue_stack.push(CompletedStackFrame())` |

## 五、关键查询方法

| 方法 | 用途 |
|---|---|
| `top()` | 获取栈顶帧（不弹出） |
| `top_flow_frame()` | 从栈顶向下找第一个 FlowStackFrame |
| `active_flow_frame()` | 找第一个状态为 ACTIVE 的 FlowStackFrame |
| `find_flow_frame(flow_id)` | 按 flow_id 精确查找 |
| `has_flow(flow_id)` | 判断某 Flow 是否在栈中 |
| `get_all_flow_ids()` | 获取栈中所有 Flow ID |

## 六、整体数据流

```
用户消息
  │
  ▼
understand_node ──→ LLM生成命令 ──→ CommandProcessor执行
  │                                       │
  │                              StartFlowCommand.run()
  │                              → tracker.start_flow()
  │                              → dialogue_stack.push(FlowStackFrame)
  │
  ▼
policy_node
  │
  ├─ FlowPolicy.predict()
  │    读取 dialogue_stack.top_flow_frame()
  │    执行 flow 步骤 → 更新/弹出 FlowStackFrame
  │    Flow完成 → push(CompletedStackFrame)
  │
  ├─ EnterpriseSearchPolicy.predict()
  │    读取 dialogue_stack.top()
  │    根据栈帧类型分发处理 → 弹出非Flow帧
  │
  ▼
action_node ──→ 执行Action ──→ 可能push/pop栈帧
  │
  ▼
response_node ──→ 生成最终响应
  │
  ▼
tracker_store.save() ──→ dialogue_stack.as_dict() 持久化
```

**总结**：`DialogueStack` 是系统对话状态的唯一真实来源（Single Source of Truth），通过栈帧的压入/弹出/属性修改，驱动 Flow 执行、模式切换和上下文恢复，是整个对话引擎的调度核心。
