# 项目中Prompt动态裁剪的实现分析

## 概述

本项目在多个层面实现了prompt的动态裁剪机制，确保发送给LLM的上下文长度在合理范围内，避免超过token限制。

## 核心实现位置

### 1. **DialogueStateTracker 层面的历史管理**

**文件**: `hll_ai/core/tracker.py`

#### 1.1 初始化时的最大轮次限制

```python
def __init__(
    self,
    sender_id: str = DEFAULT_SENDER_ID,
    slots: Optional[Dict[str, Slot]] = None,
    max_turns: int = 100,  # 默认最多保留100轮对话
) -> None:
    self.max_turns = max_turns
    self.dialogue_turns: List[DialogueTurn] = []
```

**作用**：在tracker初始化时设置最大保留的对话轮次数，默认100轮。

#### 1.2 自动裁剪历史对话

```python
def _save_current_turn(self) -> None:
    """保存当前轮次到历史"""
    if self._current_turn:
        self.dialogue_turns.append(self._current_turn)
        
        # 限制历史长度 - 动态裁剪核心逻辑
        if len(self.dialogue_turns) > self.max_turns:
            self.dialogue_turns = self.dialogue_turns[-self.max_turns:]
        
        self._current_turn = None
```

**作用**：每次保存对话轮次时，自动裁剪超出限制的历史，只保留最近的N轮。

**裁剪策略**：FIFO（先进先出），保留最近的对话，丢弃最早的对话。

#### 1.3 获取对话历史时的动态裁剪

```python
def get_dialogue_history(
    self,
    max_turns: Optional[int] = None,
) -> List[Dict[str, Any]]:
    """获取对话历史
    
    参数：
        max_turns: 最大返回轮次数
    """
    turns = self.dialogue_turns[:]
    if self._current_turn:
        turns.append(self._current_turn)
    
    # 动态裁剪：根据需求返回最近N轮
    if max_turns:
        turns = turns[-max_turns:]
    
    return [turn.to_dict() for turn in turns]
```

**作用**：读取历史时可以动态指定返回的轮次数，灵活控制上下文长度。

#### 1.4 为LLM准备消息时的裁剪

```python
def get_messages_for_llm(
    self,
    max_turns: int = 10,  # 默认只给LLM最近10轮对话
) -> List[Dict[str, str]]:
    """获取用于LLM的消息历史
    
    将对话历史转换为LLM消息格式。
    """
    messages = []
    # 核心裁剪：只取最近max_turns轮
    turns = self.dialogue_turns[-max_turns:] if max_turns else self.dialogue_turns
    
    for turn in turns:
        if turn.user_message:
            messages.append({
                "role": "user",
                "content": turn.user_message.text,
            })
        
        for bot_msg in turn.bot_messages:
            if bot_msg.text:
                messages.append({
                    "role": "assistant",
                    "content": bot_msg.text,
                })
    
    return messages
```

**作用**：专门为LLM调用准备消息时，默认只取最近10轮对话，大幅减少prompt长度。

### 2. **PromptBuilder 层面的配置化裁剪**

**文件**: `hll_ai/dialogue_understanding/generator/prompt_builder.py`

#### 2.1 配置化的历史轮次限制

```python
@dataclass
class PromptBuilder:
    """Prompt构建器
    
    Attributes:
        max_history_turns: 包含的最大历史轮数
    """
    template_name: str = "command_prompt.jinja2"
    max_history_turns: int = 5  # 默认只包含最近5轮历史
    include_slots: bool = True
    include_flows: bool = True
```

**作用**：在PromptBuilder初始化时配置最大历史轮数，默认5轮。

#### 2.2 构建prompt时调用裁剪

```python
def _get_conversation_history(
    self,
    tracker: "DialogueStateTracker",
) -> List[Dict[str, str]]:
    """获取对话历史"""
    # 调用tracker的get_messages_for_llm，传入配置的max_turns
    history = tracker.get_messages_for_llm(max_turns=self.max_history_turns)
    
    formatted_history = []
    for msg in history:
        role = msg.get("role", "user")
        content = msg.get("content", "")
        if role == "user":
            formatted_history.append({"role": "用户", "content": content})
        elif role == "assistant":
            formatted_history.append({"role": "助手", "content": content})
    
    return formatted_history
```

**作用**：构建prompt时，将配置的max_history_turns传递给tracker，实现层级化的裁剪控制。

### 3. **LLMGenerator 层面的配置和日志裁剪**

**文件**: `hll_ai/dialogue_understanding/generator/llm_generator.py`

#### 3.1 生成器配置中的历史控制

```python
@dataclass
class LLMGeneratorConfig(GeneratorConfig):
    """LLM生成器配置
    
    继承自GeneratorConfig，包含max_history_turns配置
    """
    type: str = "openai"
    model: str = "gpt-4o-mini"
    temperature: float = 0.0
    max_tokens: int = 256
    # 从基类继承max_history_turns配置
```

#### 3.2 初始化时传递配置

```python
def __init__(
    self,
    config: Optional[LLMGeneratorConfig] = None,
    llm_client: Optional[LLMClient] = None,
    prompt_builder: Optional[PromptBuilder] = None,
    command_parser: Optional[CommandParser] = None,
):
    self.config = config or LLMGeneratorConfig()
    
    # 将max_history_turns传递给PromptBuilder
    self.prompt_builder = prompt_builder or PromptBuilder(
        max_history_turns=self.config.max_history_turns,
        include_slots=self.config.include_slots,
        include_flows=self.config.include_flows,
    )
```

#### 3.3 日志输出时的内容裁剪

```python
def _format_messages_for_log(self, messages: List[Dict[str, str]]) -> str:
    """格式化消息用于日志"""
    parts = []
    for msg in messages:
        role = msg.get("role", "unknown")
        content = msg.get("content", "")
        # 截断长内容 - 避免日志过长
        if len(content) > 500:
            content = content[:500] + "..."
        parts.append(f"[{role}]: {content}")
    return "\n".join(parts)
```

**作用**：在记录日志时，如果单条消息内容超过500字符，自动截断并添加省略号。

## 裁剪策略总结

### 多层级裁剪机制

```
┌─────────────────────────────────────────────────────────┐
│ Level 1: Tracker 长期存储                                │
│ max_turns = 100 (默认)                                   │
│ 保存对话时自动裁剪，只保留最近100轮                        │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│ Level 2: Tracker LLM接口                                 │
│ max_turns = 10 (默认)                                    │
│ get_messages_for_llm() 默认只返回最近10轮                 │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│ Level 3: PromptBuilder                                   │
│ max_history_turns = 5 (默认)                             │
│ 构建prompt时进一步裁剪到最近5轮                            │
└─────────────────────────────────────────────────────────┘
                        ↓
┌─────────────────────────────────────────────────────────┐
│ Level 4: 日志输出                                         │
│ max_content_length = 500 字符                            │
│ 单条消息超过500字符时截断                                  │
└─────────────────────────────────────────────────────────┘
```

### 裁剪参数默认值

| 层级 | 参数名 | 默认值 | 说明 |
|------|--------|--------|------|
| Tracker存储 | `max_turns` | 100 | 内存中最多保留100轮完整对话 |
| Tracker LLM接口 | `max_turns` | 10 | 给LLM默认传递最近10轮 |
| PromptBuilder | `max_history_turns` | 5 | 构建prompt时默认最近5轮 |
| 日志输出 | `max_content_length` | 500 | 单条消息最多显示500字符 |

## 配置化使用示例

### 1. 自定义Tracker的历史长度

```python
# 创建tracker时指定最大保留轮次
tracker = DialogueStateTracker(
    sender_id="user123",
    max_turns=50  # 只保留最近50轮
)
```

### 2. 自定义PromptBuilder的历史长度

```python
# 创建PromptBuilder时指定
prompt_builder = PromptBuilder(
    max_history_turns=3  # 只包含最近3轮历史
)
```

### 3. 自定义LLMGenerator配置

```python
config = LLMGeneratorConfig(
    model="gpt-4",
    max_history_turns=8,  # 传递给PromptBuilder
    temperature=0.1,
)
generator = LLMCommandGenerator(config=config)
```

### 4. 运行时动态指定

```python
# 获取历史时动态指定轮次数
history = tracker.get_messages_for_llm(max_turns=15)

# 或
history = tracker.get_dialogue_history(max_turns=20)
```

## 裁剪的优势

### 1. **控制Token消耗**
- 减少发送给LLM的token数量
- 降低API调用成本
- 提高响应速度

### 2. **提升相关性**
- 只保留最近的上下文
- 避免过早的对话干扰当前理解
- 提高意图识别准确度

### 3. **内存优化**
- 限制内存中的对话历史长度
- 支持长时间运行的会话
- 避免内存溢出

### 4. **灵活性**
- 多层级配置
- 不同场景可使用不同策略
- 支持运行时动态调整

## 改进建议

### 1. **基于Token的裁剪**

当前实现基于"轮次数"裁剪，更精确的方式是基于token数量：

```python
def get_messages_for_llm_by_tokens(
    self,
    max_tokens: int = 2000,
) -> List[Dict[str, str]]:
    """根据token数量裁剪对话历史"""
    messages = []
    total_tokens = 0
    
    # 从最新往前遍历
    for turn in reversed(self.dialogue_turns):
        turn_tokens = estimate_tokens(turn)  # 估算token数
        if total_tokens + turn_tokens > max_tokens:
            break
        messages.insert(0, turn)
        total_tokens += turn_tokens
    
    return messages
```

### 2. **智能摘要**

对于超长对话，可以对早期历史进行摘要：

```python
def get_messages_with_summary(
    self,
    recent_turns: int = 5,
    summary_threshold: int = 10,
) -> List[Dict[str, str]]:
    """获取包含摘要的消息历史"""
    messages = []
    
    # 如果历史超过阈值，对早期对话生成摘要
    if len(self.dialogue_turns) > summary_threshold:
        early_turns = self.dialogue_turns[:-recent_turns]
        summary = self._generate_summary(early_turns)
        messages.append({"role": "system", "content": f"对话摘要: {summary}"})
    
    # 添加最近的详细对话
    recent = self.dialogue_turns[-recent_turns:]
    messages.extend(self._format_turns(recent))
    
    return messages
```

### 3. **重要信息保留**

裁剪时保留关键信息（如槽位填充、flow切换）：

```python
def get_messages_with_key_info(
    self,
    max_turns: int = 5,
) -> List[Dict[str, str]]:
    """获取包含关键信息的消息历史"""
    messages = []
    
    # 始终包含当前flow的关键槽位信息
    key_slots = self._get_key_slots_summary()
    if key_slots:
        messages.append({"role": "system", "content": key_slots})
    
    # 添加最近对话
    messages.extend(self.get_messages_for_llm(max_turns))
    
    return messages
```

## 总结

本项目实现了**三层级的prompt动态裁剪机制**：

1. **存储层（100轮）**：限制内存中保留的完整对话历史
2. **接口层（10轮）**：为LLM准备消息时的默认裁剪
3. **业务层（5轮）**：PromptBuilder根据业务需求的进一步裁剪

这种设计既保证了系统的稳定性和成本控制，又提供了足够的灵活性来适应不同场景的需求。
