# 任务平台智能客服 LoRA 微调数据集

## 数据集概述

本数据集用于微调大模型，使其更好地理解货拉拉任务平台场景中的专业术语和用户意图。

**文件**: `task_platform_lora_dataset.jsonl`  
**格式**: JSONL (每行一个JSON对象)  
**样本数量**: 52条  
**覆盖场景**: 11个核心歧义场景

## 数据格式

每条训练样本包含以下字段：

```json
{
  "instruction": "理解用户意图并提取关键信息",
  "input": "用户的原始输入文本",
  "output": "结构化的意图和实体提取结果（JSON字符串）",
  "category": "场景分类标签"
}
```

### Output字段结构

```json
{
  "intent": "标准化的意图名称",
  "entities": {
    "key": "value"  // 提取的实体信息
  },
  "explanation": "解释说明",
  "need_context": true/false,  // 是否需要上下文
  "clarification": "需要澄清的信息"  // 可选
}
```

## 场景分类统计

| 场景分类 | 样本数 | 说明 |
|---------|--------|------|
| 任务vs实例概念区分 | 3 | 区分任务定义和实例运行 |
| 依赖vs血缘vs上下游 | 3 | 区分调度依赖和数据血缘 |
| 状态识别 | 5 | 将口语化状态映射到标准状态码 |
| 失败原因专业术语 | 7 | 将用户描述映射到技术诊断类型 |
| 时间概念多义性 | 4 | 区分调度时间、业务日期、执行时间 |
| 业务术语干扰 | 3 | 区分任务平台术语和货拉拉业务术语 |
| 大数据技术栈术语 | 5 | 理解Spark/Flink/YARN等技术组件 |
| 操作动词多样性 | 6 | 统一不同表达的操作意图 |
| 隐含上下文理解 | 4 | 处理省略主语的多轮对话 |
| 时间表达规范化 | 4 | 将相对时间转换为绝对时间 |
| 数值规范化 | 4 | 标准化时长、数量、百分比等数值 |

## 核心意图列表

微调后模型应能识别以下意图：

1. **query_task_status** - 查询任务运行状态
2. **diagnose_task_error** - 诊断任务错误
3. **query_task_logs** - 查询任务日志
4. **query_task_dependencies** - 查询任务依赖
5. **query_instance_detail** - 查询实例详情
6. **query_data_lineage** - 查询数据血缘
7. **query_task_list** - 查询任务列表
8. **query_task_info** - 查询任务配置信息
9. **query_resource_status** - 查询资源状态
10. **rerun_task** - 重新运行任务
11. **stop_task** - 停止任务
12. **suggest_config_change** - 配置调整建议
13. **query_task_metrics** - 查询任务指标
14. **query_config_advice** - 配置建议咨询

## 关键实体类型

### 基础实体
- **task_id**: 任务ID
- **instance_id**: 实例ID
- **status**: 任务状态 (FAILED, RUNNING, WAITING, SKIPPED, etc.)
- **error_type**: 错误类型 (OOM, DATA_SKEW, TIMEOUT, etc.)

### 时间相关
- **time_type**: 时间类型 (schedule_time, business_date, execution_time, data_date)
- **date**: 日期 (YYYY-MM-DD)
- **datetime**: 日期时间 (YYYY-MM-DD HH:MM:SS)
- **time_range**: 时间范围 {start, end}

### 依赖相关
- **dependency_type**: 依赖类型 (upstream, downstream)
- **query_type**: 查询类型 (dependency, lineage)

### 技术栈相关
- **engine_type**: 引擎类型 (spark, flink, hive)
- **component**: 组件名称 (shuffle, checkpoint, executor, driver)
- **resource_type**: 资源类型 (cpu, memory, queue)

### 范围限定
- **scope**: 查询范围 (latest_instance, recent_instances, all)
- **limit**: 数量限制
- **status_filter**: 状态过滤

## 错误类型标准化映射

| 口语化描述 | 标准错误类型 | 说明 |
|-----------|-------------|------|
| 内存不够、内存爆了 | OOM | Out of Memory |
| 数据倾斜 | DATA_SKEW | 数据分布不均 |
| 超时、没跑完 | TIMEOUT | 执行超时 |
| 上游没好、依赖失败 | DEPENDENCY_FAILED | 依赖任务失败 |
| 连不上 | CONNECTION_ERROR | 连接失败 |
| 权限不够 | PERMISSION_DENIED | 权限不足 |
| 数据找不到 | DATA_NOT_FOUND | 数据缺失 |
| checkpoint失败 | CHECKPOINT_FAILED | 检查点失败 |

## 状态标准化映射

| 口语化描述 | 标准状态码 |
|-----------|-----------|
| 跑失败了、挂了 | FAILED |
| 还在跑、运行中 | RUNNING |
| 等着呢、待运行 | WAITING/PENDING |
| 被跳过了 | SKIPPED |
| 卡住了 | STUCK |
| 被杀了、终止了 | KILLED |
| 重跑中 | RETRYING |
| 跑完了、成功 | SUCCESS |

## 使用方法

### 1. 数据预处理

```python
import json

def load_dataset(file_path):
    """加载JSONL数据集"""
    data = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            data.append(json.loads(line))
    return data

# 加载数据
dataset = load_dataset('task_platform_lora_dataset.jsonl')
```

### 2. 转换为LoRA训练格式

根据不同的微调框架，需要转换数据格式：

#### LLaMA Factory 格式

```python
def convert_to_llama_factory(dataset):
    """转换为LLaMA Factory的alpaca格式"""
    converted = []
    for item in dataset:
        converted.append({
            "instruction": item["instruction"],
            "input": item["input"],
            "output": item["output"]
        })
    return converted
```

#### OpenAI Fine-tuning 格式

```python
def convert_to_openai_format(dataset):
    """转换为OpenAI微调格式"""
    converted = []
    for item in dataset:
        converted.append({
            "messages": [
                {"role": "system", "content": item["instruction"]},
                {"role": "user", "content": item["input"]},
                {"role": "assistant", "content": item["output"]}
            ]
        })
    return converted
```

### 3. 数据增强建议

为了提升微调效果，建议进行以下数据增强：

1. **同义替换**: 为每个样本生成同义表达
   - "查询" → "查看/看看/获取/拉取"
   - "失败" → "挂了/报错/出问题"

2. **添加噪声**: 模拟真实用户输入
   - 添加口语化表达
   - 添加错别字（适度）
   - 添加冗余词汇

3. **多轮对话扩展**: 将单轮样本扩展为多轮对话
   ```
   用户: "查一下task_12345"
   助手: "好的，正在查询task_12345的运行情况..."
   用户: "它为什么失败了？"
   助手: (需要理解"它"指代task_12345)
   ```

4. **反例样本**: 添加边界情况和错误处理
   - 任务ID格式错误
   - 时间格式不规范
   - 意图模糊的查询

## 微调参数建议

### LoRA参数
```yaml
lora_r: 8              # LoRA秩
lora_alpha: 16         # LoRA缩放系数
lora_dropout: 0.05     # Dropout率
target_modules:        # 目标模块
  - q_proj
  - v_proj
  - k_proj
  - o_proj
```

### 训练参数
```yaml
learning_rate: 2e-4    # 学习率
num_epochs: 3-5        # 训练轮数
batch_size: 4-8        # 批次大小
warmup_steps: 100      # 预热步数
```

## 评估指标

微调后应评估以下指标：

1. **意图识别准确率**: 正确识别用户意图的比例
2. **实体提取F1值**: 实体识别的精确率和召回率
3. **状态映射准确率**: 口语化状态到标准状态的映射准确性
4. **错误类型识别准确率**: 失败原因的准确识别
5. **上下文理解能力**: 多轮对话中指代消解的准确性

## 数据扩展计划

当前数据集为基础版本，后续可扩展：

1. **增加样本数量**: 每个场景扩展到100+样本
2. **添加复杂场景**: 
   - 多意图混合查询
   - 条件性查询（"如果...那么..."）
   - 批量操作场景
3. **添加负样本**: 不符合任务平台场景的查询
4. **实际用户数据**: 收集真实用户对话数据进行标注

## 注意事项

1. **隐私保护**: 确保训练数据中不包含真实的敏感信息
2. **数据平衡**: 注意各类意图的样本分布平衡
3. **质量优先**: 少量高质量样本优于大量低质量样本
4. **持续迭代**: 根据实际使用反馈持续优化数据集
5. **版本管理**: 记录每次数据集的变更和版本

## 版本历史

- **v1.0** (2026-06-22): 初始版本，52条样本，覆盖11个核心场景

## 联系方式

如有问题或建议，请联系数据团队。
