# policy_node 第一轮捷径代码详解

## 代码含义

这段代码实现了 **"第一轮捷径"**：如果 CommandProcessor 已经明确知道下一步该做什么，就直接采用，跳过策略投票。

---

## 进入条件（三个缺一不可）

| 条件 | 含义 |
|------|------|
| `action_count == 0` | 当前轮次还没执行过任何动作（第一轮） |
| `process_result` 存在 | understand 节点成功处理了命令 |
| `process_result.next_action` 有值 | CommandProcessor 根据命令类型确定了下一步动作 |

---

## 实现功能

1. 拿到 `next_action`，检查是否以 `action_run_flow_` 开头
   - **是** → 跳过，让 FlowPolicy 接管（因为 FlowPolicy 会根据栈帧推进 Flow 步骤）
   - **否** → 直接构造一个置信度 1.0 的 Prediction 返回

2. 判断 `is_finished`：如果 next_action 是 `action_listen`，说明本轮处理结束

3. 提前返回，**不再调用 `PolicyEnsemble.predict()`**，省去多策略遍历的开销

---

## 模拟数据示例

### 场景 A：进入该代码块（CommandProcessor 直接决策）

**输入（state 中的数据）：**

```python
action_count = 0                          # ← 第一轮
process_result = ProcessResult(
    next_action = "action_trigger_search", # ← CommandProcessor 确定了动作
    response_type = "knowledge",           # 用户触发了知识检索
    commands_executed = 2,
    events = [...],
    metadata = {},
)
```

用户说了"你们的退货政策是什么？"，LLM 生成了 `KnowledgeAnswerCommand`，CommandProcessor 处理后确定 next_action 是 `action_trigger_search`（压入 SearchStackFrame）。

**执行过程：**

```
next_action = "action_trigger_search"
↓
不以 "action_run_flow_" 开头 → 直接采用
↓
current_prediction = PolicyPrediction(
    action = "action_trigger_search",
    confidence = 1.0,
    policy_name = "CommandProcessor",
)
is_finished = False  （action_trigger_search ≠ action_listen）
```

**输出：**

```python
{
    "current_prediction": PolicyPrediction(
        action="action_trigger_search", confidence=1.0, policy_name="CommandProcessor"
    ),
    "is_finished": False,
    "node_history": [..., "policy"],
}
```

然后 action_node 执行 `ActionTriggerSearch`，压入 SearchStackFrame，下一轮回到 policy_node 时 `action_count=1`，就不会再走这个分支了。

---

### 场景 B：进入该代码块（命中 action_listen，直接结束）

**输入：**

```python
action_count = 0
process_result = ProcessResult(
    next_action = "action_listen",          # ← 命中 action_listen
    response_type = "none",
    commands_executed = 0,
    events = [],
    metadata = {},
)
```

用户说了"你好"，LLM 生成了 `ChitChatAnswerCommand`，但 CommandProcessor 对 chitchat 类型**不设置 next_action**（让 Policy 通过栈帧处理），但实际上如果某种情况下设为了 `action_listen`……

**输出：**

```python
{
    "current_prediction": PolicyPrediction(
        action="action_listen", confidence=1.0, policy_name="CommandProcessor"
    ),
    "is_finished": True,  # ← 直接标记结束
    "node_history": [..., "policy"],
}
```

循环终止，进入 response_node。

---

### 场景 C：不进入该代码块（action_run_flow_ 前缀被跳过）

**输入：**

```python
action_count = 0
process_result = ProcessResult(
    next_action = "action_run_flow_return_order",  # ← 以 action_run_flow_ 开头
    response_type = "flow",
    commands_executed = 1,
    events = [...],
    metadata = {},
)
```

`StartFlowCommand("return_order")` 被执行后，CommandProcessor 设置 next_action 为 `action_run_flow_return_order`。

**执行过程：**

```
next_action = "action_run_flow_return_order"
↓
startswith("action_run_flow_") 为 True → 跳过这个分支
↓
往下走，交给 PolicyEnsemble.predict()
↓
FlowPolicy 检测到 FlowStackFrame(return_order@START) → 推进到第一个 collect 步骤
```

**为什么跳过？** 因为 `action_run_flow_return_order` 是一个"伪动作"，FlowPolicy 会直接推进 Flow 到第一个真实步骤（如 collect order_id），如果直接执行这个伪动作什么也不会发生，必须让 FlowPolicy 来接管。

---

### 场景 D：不进入该代码块（action_count > 0）

**输入：**

```python
action_count = 1                          # ← 已经执行过1个动作了
process_result = ProcessResult(
    next_action = "action_get_order_detail",
    ...
)
```

第一轮已经执行了一个动作（比如 `action_ask_order_id`），用户回复了订单号，第二轮回到 policy_node 时 `action_count=1`，不满足 `action_count == 0`，直接走 `PolicyEnsemble.predict()`。

**为什么不第二轮也给捷径？** 因为第一轮执行动作后 tracker 状态已经改变（槽位填充、栈帧推进），第二轮应该重新让所有策略基于最新状态投票，保证决策准确性。

---

## 总结

| 场景 | action_count | next_action | 是否进入 | 原因 |
|------|:-----------:|-------------|:-------:|------|
| A | 0 | action_trigger_search | ✅ | 非_flow前缀，直接采用 |
| B | 0 | action_listen | ✅ | 直接结束本轮 |
| C | 0 | action_run_flow_return_order | ❌ | flow前缀，交给FlowPolicy |
| D | 1 | action_get_order_detail | ❌ | 非第一轮，走完整投票 |
