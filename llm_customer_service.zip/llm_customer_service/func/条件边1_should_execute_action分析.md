# 条件边1：`should_execute_action` 分析

## 一、调用位置

`should_execute_action` 不是被任何 Python 函数直接调用的，而是通过 LangGraph 的**条件边注册**机制被框架自动调用：

```python
# builder.py:72-79
graph.add_conditional_edges(
    "policy",                    # ← 源节点：policy_node 执行完毕后
    should_execute_action,       # ← 框架自动调用此函数，传入当前 state
    {
        "action": "action",      #   返回 "action" → 走 action_node
        "response": "response",  #   返回 "response" → 走 response_node
    }
)
```

每当 `policy_node` 输出状态后，LangGraph 自动把最新 state 传给 `should_execute_action(state)`，由返回值决定下一个节点。

## 二、函数逻辑

```python
# edges.py:18-51
def should_execute_action(state: Dict[str, Any]) -> Literal["action", "response"]:
    is_finished = state.get("is_finished", False)
    current_prediction = state.get("current_prediction")

    # 检查是否已完成
    if is_finished:
        return "response"

    # 检查动作是否为 action_listen
    if current_prediction:
        action = current_prediction.action
        if action == ACTION_LISTEN or action is None:
            return "response"
    else:
        # 没有预测结果，跳转到响应
        return "response"

    return "action"
```

路由规则：

| 条件 | 路由目标 | 含义 |
|---|---|---|
| `is_finished == True` | `response` | 本轮处理结束，生成响应 |
| `current_prediction` 为空 | `response` | 无预测结果，无法执行动作 |
| `action == "action_listen"` | `response` | 等待用户输入，生成响应 |
| `action is None` | `response` | 策略放弃，生成响应 |
| 其他 | `action` | 有动作要执行，进入 action_node |

## 三、is_finished 的赋值场景

`is_finished` 在四个地方被写入状态：

### ① `create_initial_state` — 初始值

```python
# state.py:112
is_finished=False,
```

### ② `policy_node` — 第一轮预测完成时

三种情况全部写在 `policy_node` 的返回字典中：

| 分支 | is_finished | 条件 |
|---|---|---|
| **CommandProcessor 捷径命中** | `True` / `False` | `next_action == "action_listen"` → `True`，否则 `False` |
| **PolicyEnsemble 预测成功** | `True` / `False` | `prediction.action == "action_listen"` 或 `None` → `True`，否则 `False` |
| **异常兜底** | `True` | 出错了，强制结束 |

```python
# policy.py:109-115（捷径）
current_prediction = PolicyPrediction(action=next_action, confidence=1.0, ...)
is_finished = (next_action == ACTION_LISTEN)

# policy.py:131-135（PolicyEnsemble）
current_prediction = prediction
is_finished = (prediction.action == ACTION_LISTEN or prediction.action is None)

# policy.py:148-149（异常）
current_prediction = None
is_finished = True
```

### ③ `action_node` — 动作执行完成后

```python
# action.py:175-191
prediction_metadata = current_prediction.metadata or {}
flow_completed = prediction_metadata.get("flow_completed", False)
wait_for_input = "slot_to_collect" in prediction_metadata and not flow_completed

return {
    "is_finished": wait_for_input,   # True → 等用户回答；False → 继续循环
    ...
}
```

| 场景 | is_finished | 原因 |
|---|---|---|
| collect 步骤（metadata 有 `slot_to_collect`） | **True** | 执行完追问话术后等用户回答 |
| 普通 action（metadata 无 `slot_to_collect`） | **False** | 还需继续循环 |
| Flow 最后一个 action（`flow_completed=True`） | **False** | 还需继续循环以触发 `action_flow_completed` |

### ④ `guard_node` — 触达上限时

```python
# guard.py:34-42
if action_count >= max_actions:
    return {"is_finished": True, "error": "达到最大动作数限制"}
```

## 四、current_prediction 的赋值场景

### ① `create_initial_state` — 初始值

```python
# state.py:117
current_prediction=None,
```

### ② `policy_node` — 预测完成时（唯一赋值来源）

| 分支 | current_prediction |
|---|---|
| CommandProcessor 捷径命中 | `PolicyPrediction(action=next_action, confidence=1.0, policy_name="CommandProcessor")` |
| PolicyEnsemble 预测成功 | 来自 FlowPolicy 或 EnterpriseSearchPolicy 的预测结果 |
| 异常兜底 | `None` |

### ③ `action_node` — 不修改 current_prediction

`action_node` 只**读取** `current_prediction`（取 action 名和 metadata），不会覆盖它。下一轮循环回到 `policy_node` 时，才会产生新的 `current_prediction`。

## 五、两个值在全流程中的变迁

```
create_initial_state
  is_finished = False
  current_prediction = None
        │
        ▼
  understand_node（不修改这两个值）
        │
        ▼
  policy_node（第1轮）
  ┌──────────────────────────────────────────────────────┐
  │ 捷径: next_action = "action_cancel_flow"             │
  │   is_finished = False (≠ action_listen)              │
  │   current_prediction = PolicyPrediction(             │
  │     action="action_cancel_flow", confidence=1.0)     │
  │                                                      │
  │ 或 PolicyEnsemble: FlowPolicy 返回 utter_ask_xxx     │
  │   is_finished = False (≠ action_listen)              │
  │   current_prediction = PolicyPrediction(             │
  │     action="utter_ask_order_id", confidence=1.0,     │
  │     metadata={slot_to_collect: "order_id"})          │
  └──────────────────────────────────────────────────────┘
        │
        ▼
  should_execute_action ← LangGraph 框架自动调用
  ┌──────────────────────────────────────────────────────┐
  │ is_finished = False → 不走 response                  │
  │ current_prediction.action = "utter_ask_order_id"     │
  │   ≠ action_listen → 不走 response                    │
  │ → 返回 "action"                                      │
  └──────────────────────────────────────────────────────┘
        │
        ▼
  action_node
  ┌──────────────────────────────────────────────────────┐
  │ 读取 current_prediction.action → 执行 utter_ask_xxx │
  │ 检测 metadata 有 slot_to_collect → is_finished=True  │
  │ current_prediction 不变                              │
  └──────────────────────────────────────────────────────┘
        │
        ▼
  guard_node（is_finished=True 时）
        │
        ▼
  should_continue（条件边2）
  ┌──────────────────────────────────────────────────────┐
  │ is_finished = True → 返回 "response"                 │
  └──────────────────────────────────────────────────────┘
        │
        ▼
  response_node → END
```

## 六、总结

`should_execute_action` 只在 `policy_node` 之后被 LangGraph 框架调用。它的两个关键输入的赋值来源：

| 变量 | 写入者 | 含义 |
|---|---|---|
| `current_prediction` | **仅 policy_node** | 决定"做什么动作" |
| `is_finished` | **policy_node**（初步判断）+ **action_node**（执行后修正）+ **guard_node**（安全阀） | 决定"是否停下来" |

三个节点对 `is_finished` 的分工：**policy_node 决定"要不要做"，action_node 决定"做完后停不停"，guard_node 是兜底安全阀**。
