# `policy_node` 模块分析

## 一、功能概述

`policy_node` 是 LangGraph 消息处理图中的**策略决策节点**，负责决定系统下一步应该执行什么动作（Action）。它是整个对话流程的"大脑"，回答的核心问题是：**「系统接下来该做什么？」**

1**PolicyEnsemble 的预测**：遍历所有已注册策略（FlowPolicy → EnterpriseSearchPolicy），取优先级最高且置信度最优的预测结果

```
understand_node                     policy_node                        action_node
┌──────────────────┐               ┌──────────────────────┐          ┌─────────────────┐
│ 解析命令 →       │               │ 决定下一步动作       │          │ 执行具体动作    │
│ process_result    │  ─────────►  │                      │  ──────► │                 │
│   .next_action   │               │ → PolicyPrediction   │          │ ActionResult    │
│   .response_type │               │   .action            │          │                 │
└──────────────────┘               └──────────────────────┘          └─────────────────┘
```

## 二、决策流程

`policy_node` 内部的完整决策逻辑：

```
输入: state（含 tracker, domain, flows, process_result, action_count, _policy_ensemble）
  │
  ▼
1. 策略集成预测：PolicyEnsemble.predict()
  │
  ├─ 遍历所有策略（按优先级从高到低：FlowPriority > EnterpriseSearchPriority）
  │   ├─ FlowPolicy.predict()
  │   │   ├─ 无活跃 Flow → 放弃(abstain)
  │   │   ├─ completing 状态 → action_flow_completed
  │   │   ├─ collect 步骤 → utter_ask_xxx（含 slot_to_collect metadata）
  │   │   ├─ action 步骤 → 对应业务动作
  │   │   └─ Flow 完成 → action_flow_completed
  │   │
  │   └─ EnterpriseSearchPolicy.predict()
  │       ├─ 栈顶无法匹配的帧类型 → 放弃(abstain)
  │       ├─ CompletedStackFrame → action_send_text（追问是否还有其他需求）
  │       ├─ HumanHandoffStackFrame → action_send_text（转接话术）
  │       ├─ ChitChatStackFrame → action_send_text（闲聊回复）
  │       ├─ CannotHandleStackFrame → action_send_text（兜底回复）
  │       └─ SearchStackFrame → action_send_text（RAG 回复）
  │
  ├─ 选择逻辑：
  │   ├─ 第一个非放弃且置信度 >= min_confidence 的预测即为候选
  │   ├─ 取所有候选中置信度最高者
  │   └─ 置信度 = 1.0 时直接返回（短路优化）
  │
  └─ 所有策略都放弃 → fallback 动作 (action_listen)
  │
  ▼
2. 确定 is_finished
  │
  ├─ action == "action_listen" → True（等待用户输入，结束本轮处理）
  ├─ action == None → True（无动作可执行）
  └─ 其他 → False（还有动作要执行，继续循环）
  │
  ▼
输出: 状态更新字典
  ├─ current_prediction: PolicyPrediction
  └─ is_finished: bool
```

## 三、CommandProcessor 第一轮捷径详解

`policy_node` 最独特的设计是**第一轮捷径**：当 `understand_node` 的 `CommandProcessor` 已经确定了 `next_action` 时，`policy_node` 在第一轮（`action_count == 0`）直接使用该结果，无需再调用 `PolicyEnsemble.predict()`。

### 为什么需要捷径？

| 场景 | 无捷径（每次都走 PolicyEnsemble） | 有捷径 |
|---|---|---|
| 用户闲聊 | FlowPolicy 发现无活跃 Flow → 放弃；EnterpriseSearchPolicy 检测 ChitChatStackFrame → 返回 action_send_text | CommandProcessor 已标记 `response_type="chitchat"`，直接使用 |
| 用户触发新流程 | FlowPolicy 需要检测栈帧状态计算下一步 | CommandProcessor 已计算出 `next_action="action_run_flow_xxx"` |
| 收集槽位中按钮点击 | /SetSlots 直接设值，需要立即进入 Flow 下一步 | 不设 next_action，让 FlowPolicy 正常接管 |

### 为什么 `action_run_flow_*` 被排除？

```python
if not next_action.startswith("action_run_flow_"):
```

以 `action_run_flow_` 开头的动作是"伪动作"——它不是一个真正可执行的 Action 子类，而是 FlowPolicy 内部的约定标记。FlowPolicy 在 `predict()` 中会根据对话栈状态自行决定执行哪一步，不需要外部指定。如果通过捷径传入这个动作名，`action_node` 会找不到对应的 Action 类而报错。

### 捷径只在第一轮生效

`action_count == 0` 限制了捷径只在第一轮使用。后续轮次（Flow 多步骤执行场景）必须走 `PolicyEnsemble.predict()`，因为：

- `CommandProcessor` 只基于当前用户输入计算 `next_action`，无法感知动作执行后的状态变化
- Flow 的步骤推进依赖上一轮 `action_node` 对 tracker 的修改（如槽位设置、步骤前进）
- 后续轮次由 `FlowPolicy` 根据实时栈帧状态动态决策

## 四、在图中的位置与调用

### 图结构

```
                    ┌──────────────────────────────────────────────┐
                    │                                            ┌─► END
START → understand → policy ─[should_execute_action]─► action → guard ─[should_continue]─► policy (循环)
                                   │                                    │
                                   └─► response ─► END                  └─► response ─► END
```

### 入边

`understand_node` → `policy_node`（固定边，无条件）

### 出边（条件边 `should_execute_action`）

```python
# edges.py: should_execute_action
if is_finished or action == "action_listen" or action is None:
    return "response"    # 无动作可执行 → 生成响应并结束
else:
    return "action"      # 有动作要执行 → 进入 action_node
```

### 循环路径

`policy_node` → `action_node` → `guard_node` → `should_continue`:

- `is_finished == True` 或 `action_count >= max_actions` → `response_node` → END
- 否则 → 回到 `policy_node` 继续预测

### 多轮循环场景示例

```
用户: "我要退货"
  │
  ├─ understand_node: StartFlowCommand("refund") → next_action="action_run_flow_refund"
  ├─ policy_node (第1轮, 捷径): 跳过（action_run_flow_* 被排除），走 PolicyEnsemble
  │   └─ FlowPolicy: 返回 utter_ask_order_id（含 slot_to_collect）
  ├─ should_execute_action → action_node → 执行 utter_ask_order_id
  ├─ guard_node → should_continue → policy_node (第2轮)
  │
  │  ← 此时已是下一轮用户输入，或自动填充后的循环
  └─ ...继续直到 is_finished=True
```

## 五、输出内容

`policy_node` 返回状态更新字典：

```python
{
    "current_prediction": PolicyPrediction,  # 策略预测结果
    "is_finished": bool,                     # 是否结束本轮处理
    "node_history": [..., "policy"],         # 节点执行历史
}
```

### PolicyPrediction 结构

```python
@dataclass
class PolicyPrediction:
    action: str                    # 预测的动作名
    confidence: float              # 置信度 (0.0 ~ 1.0)
    events: List[Dict]             # 附带的事件列表
    policy_name: str               # 作出预测的策略名
    metadata: Dict[str, Any]       # 元数据（如 slot_to_collect, flow_completed 等）
    is_abstain: bool               # 是否放弃预测
```

### 典型输出场景

**场景1：用户闲聊（第一轮流捷径）**
```python
{
    "current_prediction": PolicyPrediction(
        action="action_send_text",
        confidence=1.0,
        policy_name="CommandProcessor",    # 来自捷径
        metadata={},
    ),
    "is_finished": False,                  # 还需执行 action_send_text
}
```

**场景2：Flow 收集槽位（走 PolicyEnsemble）**
```python
{
    "current_prediction": PolicyPrediction(
        action="utter_ask_order_id",
        confidence=1.0,
        policy_name="FlowPolicy",
        metadata={
            "slot_to_collect": "order_id",
            "next_step_id": "collect_reason",
        },
    ),
    "is_finished": False,                  # 还需执行 utter_ask_order_id
}
```

**场景3：所有策略放弃，等待用户输入**
```python
{
    "current_prediction": PolicyPrediction(
        action="action_listen",
        confidence=0.0,
        policy_name="PolicyEnsemble",
        metadata={},
    ),
    "is_finished": True,                   # 结束本轮，等待用户
}
```

**场景4：Flow 最后一步完成**
```python
{
    "current_prediction": PolicyPrediction(
        action="action_flow_completed",
        confidence=1.0,
        policy_name="FlowPolicy",
        metadata={
            "flow_completed": True,
            "completed_flow": "refund",
        },
    ),
    "is_finished": False,                  # 还需执行 action_flow_completed
                                          # 执行后由 guard → policy 循环
                                          # 下一轮 EnterpriseSearchPolicy 处理 CompletedStackFrame
}
```

## 六、policy_node 在完整流程中的角色

```
用户: "帮我查订单ORD123的物流"
  │
  ▼ understand_node
┌──────────────────────────────────────────────────┐
│ LLM 生成命令:                                     │
│   StartFlowCommand("logistics_inquiry")           │
│   SetSlotCommand("order_id", "ORD123")            │
│                                                   │
│ CommandProcessor 执行:                             │
│   dialogue_stack.push_flow("logistics_inquiry")   │
│   tracker.set_slot("order_id", "ORD123")          │
│   next_action = "action_run_flow_logistics_inquiry"│
│   response_type = "flow"                          │
└──────────────────────────────────────────────────┘
  │
  ▼ policy_node
┌──────────────────────────────────────────────────┐
│ 捷径检查:                                         │
│   action_count == 0 ✓                             │
│   process_result.next_action = "action_run_flow_..." │
│   但以 "action_run_flow_" 开头 → 排除捷径          │
│                                                   │
│ 走 PolicyEnsemble:                                │
│   FlowPolicy: 活跃 flow 物流查询, order_id已填充    │
│   → 跳过 collect，执行 action 步骤                 │
│   → 返回 utter_logistics_info                     │
│   → is_finished = False                           │
└──────────────────────────────────────────────────┘
  │
  ▼ action_node ── 执行 utter_logistics_info
  │
  ▼ guard_node ── 未达上限，继续
  │
  ▼ policy_node (第2轮)
┌──────────────────────────────────────────────────┐
│ 捷径检查: action_count == 1 ✗ → 跳过               │
│                                                   │
│ FlowPolicy: 物流查询 flow 的下一步 → END            │
│   → marking completing = True                     │
│   → 返回 action_flow_completed                    │
│   → is_finished = False                           │
└──────────────────────────────────────────────────┘
  │
  ▼ action_node ── 执行 action_flow_completed
  │
  ▼ guard_node ── 继续循环
  │
  ▼ policy_node (第3轮)
┌──────────────────────────────────────────────────┐
│ FlowPolicy: 无活跃 flow (已 end_flow) → 放弃        │
│ EnterpriseSearchPolicy: 栈顶 CompletedStackFrame   │
│   → 返回 action_send_text("还有其他需要吗")         │
│   → is_finished = False                           │
└──────────────────────────────────────────────────┘
  │
  ▼ action_node ── 执行 action_send_text
  │
  ▼ guard_node → policy_node (第4轮)
┌──────────────────────────────────────────────────┐
│ FlowPolicy: 无活跃 flow → 放弃                      │
│ EnterpriseSearchPolicy: 栈顶已清空 → 放弃            │
│ → fallback → action_listen                        │
│ → is_finished = True                              │
└──────────────────────────────────────────────────┘
  │
  ▼ response_node ── 汇总响应 → END
```
