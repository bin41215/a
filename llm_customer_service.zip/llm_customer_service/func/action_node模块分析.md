# `action_node` 模块分析

## 一、功能概述

`action_node` 是 LangGraph 消息处理图中的**动作执行节点**，它的职责是把 `policy_node` 输出的动作名（字符串）变为实际的副作用——找到对应的 Action 实例，调用 `run()` 方法，收集回复文本写入 `final_responses`，更新 tracker 状态，并决定本轮处理是否结束。

它是系统中**唯一调用 Action.run() 的入口**，也是**回复文本进入 final_responses 的唯一通道**。

```
policy_node 输出                     action_node 处理                      对外影响
┌─────────────────────┐            ┌──────────────────────────┐         ┌─────────────────┐
│ PolicyPrediction    │            │ get_action(action_name)  │         │ final_responses │
│   .action = "utter_ │  ───────►  │ action.run(tracker,...)  │  ─────► │ 累积回复文本    │
│           ask_xxx"  │            │ → ActionResult           │         │ tracker 更新    │
│   .metadata = {...} │            │ → 赋值 is_finished       │         │ is_finished     │
└─────────────────────┘            └──────────────────────────┘         └─────────────────┘
```

## 二、执行流程

```
输入: state（含 tracker, current_prediction, final_responses, metadata, action_count, _command_generator）
  │
  ▼
1. 空预测检查
  │  条件: current_prediction 为空 或 current_prediction.action 为空
  │  → 返回 {current_action_result: None, action_count: 不变}
  │
  ▼
2. 查找动作实例
  │  action = get_action(action_name)
  │  三级查找链：
  │  ├── _CUSTOM_ACTIONS（用户自定义，优先级最高）
  │  ├── _BUILTIN_ACTIONS（14 个内置动作）
  │  └── "utter_" 前缀 → 自动创建 ActionUtter
  │
  │  找不到 → 返回 {current_action_result: ActionResult(success=False), action_count+1}
  │
  ▼
3. 合并参数 kwargs
  │  kwargs = dict(metadata)                      ← 图状态中的 metadata
  │  kwargs.update(current_prediction.metadata)   ← Policy 预测的 metadata
  │
  │  特殊注入：闲聊动作注入 LLM 配置
  │  if action_name == "action_chitchat_response":
  │      kwargs["llm_config"] = command_generator.config
  │
  ▼
4. 执行动作
  │  result = await action.run(tracker, domain, **kwargs)
  │  → ActionResult(responses=[...], events=[...], success=True/False)
  │
  ▼
5. fallback 降级（仅在特定条件下）
  │  条件：result.responses 为空
  │       AND action_name 以 "utter_" 开头
  │       AND prediction.metadata 中有 fallback_action
  │  操作：用 fallback_action 重新执行一次
  │  场景：collect 步骤中 action_ask_xxx 优先，失败降级到 utter_ask_xxx
  │
  ▼
6. 累积响应 + 更新 tracker
  │  for resp in result.responses:
  │      final_responses.append(resp)              ← 回复文本进入累积列表
  │      tracker.add_bot_message(BotMessage(...))   ← 记录到对话历史
  │  tracker.latest_action_name = action_name       ← 更新最新动作标记
  │
  ▼
7. 判断 is_finished
  │  prediction_metadata = current_prediction.metadata or {}
  │  flow_completed = prediction_metadata.get("flow_completed", False)
  │  wait_for_input = "slot_to_collect" in prediction_metadata and not flow_completed
  │
  │  ├─ wait_for_input = True  → is_finished = True  （收完槽位等用户回答）
  │  └─ wait_for_input = False → is_finished = False （继续循环）
  │
  ▼
输出: 状态更新字典
```

## 三、关键逻辑详解

### 1. 参数合并 — 两个 metadata 的来源

```python
kwargs = dict(metadata)                      # 来源1: 图状态 metadata（用户消息元数据）
kwargs.update(current_prediction.metadata)   # 来源2: Policy 预测 metadata（动作参数）
```

| 来源 | 内容示例 | 典型用途 |
|---|---|---|
| 图状态 metadata | `{"user_id": "u123", "channel": "web"}` | 用户信息、通道标识 |
| Policy metadata | `{"text": "退货需7天内...", "slot_to_collect": "order_id"}` | 动作执行参数、循环控制信号 |

**后者覆盖前者**——当键冲突时以 Policy 的为准，确保 Policy 对动作行为有最终决定权。

### 2. fallback 降级机制

```python
prediction_metadata = current_prediction.metadata or {}
fallback_action_name = prediction_metadata.get("fallback_action")

if (not result.responses 
    and action_name.startswith("utter_") 
    and fallback_action_name):
    fallback_action = get_action(fallback_action_name)
    if fallback_action:
        result = await fallback_action.run(tracker, domain, **kwargs)
        action_name = fallback_action_name
```

**触发条件三个同时满足**：
- `result.responses` 为空（ActionUtter 在 domain 中找不到模板）
- `action_name` 以 `utter_` 开头
- prediction.metadata 中有 `fallback_action`

**典型场景**：Flow 的 collect 步骤
```
FlowPolicy 返回:
  action = "utter_ask_order_id"
  metadata.fallback_action = "action_ask_order_id"

ActionUtter.run() → domain 中没有 utter_ask_order_id 模板 → responses=[]
→ 触发 fallback → get_action("action_ask_order_id") → 执行自定义 Action
```

### 3. is_finished 判断 — 循环控制的核心

```python
flow_completed = prediction_metadata.get("flow_completed", False)
wait_for_input = "slot_to_collect" in prediction_metadata and not flow_completed
```

| 场景 | metadata | flow_completed | wait_for_input | is_finished | 后续路径 |
|---|---|---|---|---|---|
| collect 追问 | `{slot_to_collect: "order_id", ...}` | False | **True** | **True** | guard → response → END |
| 普通 action | `{next_step_id: "..."}` | — | False | **False** | guard → policy（继续） |
| Flow 最后一步 | `{flow_completed: True}` | True | False | **False** | guard → policy（继续） |
| 无 metadata | `{}` | False | False | **False** | guard → policy（继续） |

**为什么 `flow_completed` 时 `is_finished=False`？**

Flow 最后一个 action 执行完后，还需要继续循环：
```
最后一个 action → action_node(is_finished=False) → guard → policy
  → FlowPolicy 检测 completing → action_flow_completed → action_node
  → ActionFlowCompleted 压入 CompletedStackFrame → action_node(is_finished=False)
  → guard → policy → EnterpriseSearchPolicy 处理 CompletedStackFrame
  → action_send_text → action_node(is_finished=False)
  → guard → policy → 所有策略放弃 → action_listen
  → should_execute_action(is_finished=True) → response → END
```

如果在最后一个 action 就设 `is_finished=True`，整个收尾链路就断了。

## 四、如何被调用

### 在图中的位置

```
START → understand → policy ─[should_execute_action]─→ action → guard ─[should_continue]─→ ...
                                   │                                          │
                                   └─► response ─► END                         └─► response ─► END
                                                                                │
                                                                                └─► policy（循环）
```

### 入边

`policy_node` → `action_node`（经由 `should_execute_action` 条件边，action ≠ action_listen 且 is_finished=False 时走此分支）

### 出边

`action_node` → `guard_node`（**固定边，无条件**）

guard_node 之后的路由由 `should_continue` 决定：
- `is_finished=True` 或 `action_count >= max_actions` → `response_node` → END
- 否则 → 回到 `policy_node` 继续循环

## 五、输出内容

`action_node` 返回状态更新字典：

```python
{
    "tracker": tracker,                    # 更新后的 tracker（含 bot 消息、最新动作名）
    "current_action_result": ActionResult,  # 本次动作执行结果
    "final_responses": [...],              # 累积的全部响应列表
    "action_count": action_count + 1,      # 动作计数 +1
    "is_finished": bool,                   # 是否结束本轮处理
    "node_history": [..., "action"],       # 节点历史
}
```

### 各场景的输出差异

**正常执行（有回复）**
```python
{
    "tracker": tracker,                           # 新增 bot_message + latest_action_name
    "current_action_result": ActionResult(
        responses=[{"text": "请提供订单号", "buttons": [...]}],
        events=[],
        success=True,
    ),
    "final_responses": [{"text": "请提供订单号", "buttons": [...]}],
    "action_count": 1,
    "is_finished": True,                          # slot_to_collect 存在
    "node_history": ["understand", "policy", "action"],
}
```

**栈帧操控类（无回复）**
```python
{
    "tracker": tracker,                           # 新增栈帧 + latest_action_name
    "current_action_result": ActionResult(
        responses=[],                             # ← 空列表
        events=[{"event": "cannot_handle_triggered", "reason": "..."}],
        success=True,
    ),
    "final_responses": [],                        # ← 无新增
    "action_count": 1,
    "is_finished": False,                         # 无 slot_to_collect
    "node_history": ["understand", "policy", "action"],
}
```

**动作未找到**
```python
{
    "current_action_result": ActionResult(success=False),
    "action_count": action_count + 1,
    "node_history": [..., "action"],
    # 注意：没有 tracker、final_responses、is_finished 键
}
```

**执行异常**
```python
{
    "current_action_result": ActionResult(success=False),
    "action_count": action_count + 1,
    "error": "division by zero",
    "node_history": [..., "action"],
}
```

## 六、交互模块全景

```
                         action_node
                    ┌────────────────────────┐
                    │                        │
    读取 ─────────► │  state 字段            │
    │               │  ├─ current_prediction │ ◄── policy_node 写入
    │               │  ├─ metadata           │ ◄── create_initial_state 写入
    │               │  ├─ final_responses    │ ◄── 前几轮 action_node 累积
    │               │  ├─ action_count       │ ◄── 前几轮 action_node 递增
    │               │  └─ _command_generator │ ◄── agent.py 注入
    │               │                        │
    │               │  调用                  │
    │        ┌──────┼──────────────────┐     │
    │        │      │                  │     │
    │        ▼      ▼                  ▼     │
    │  ┌─────────┐ ┌──────┐    ┌──────────┐ │
    │  │ actions │ │domain│    │ tracker  │ │
    │  │ .py     │ │      │    │          │ │
    │  │         │ │      │    │          │ │
    │  │get_     │ │get_  │    │add_bot_  │ │
    │  │action() │ │resp()│    │message() │ │
    │  │         │ │      │    │set_slot()│ │
    │  └─────────┘ └──────┘    │end_flow()│ │
    │        │                 │start_    │ │
    │        │ action.run()    │flow()    │ │
    │        │                 └──────────┘ │
    │        ▼                      ▲       │
    │   ┌───────────┐               │       │
    │   │ActionResult│              │       │
    │   │           │  写回 state   │       │
    │   │ responses │───────────────┤       │
    │   │ events    │               │       │
    │   └───────────┘               │       │
    │                               │       │
    └───────────────────────────────┘       │
                                            │
  写入 ─────────────────────────────────────┘
    │
    ▼
  state 更新:
  ├─ tracker (更新后)
  ├─ current_action_result
  ├─ final_responses (累积后)
  ├─ action_count (+1)
  ├─ is_finished
  └─ node_history (+["action"])
```

### 交互矩阵

| 交互模块 | 读取 | 写入 | 说明 |
|---|---|---|---|
| **actions.py** | `get_action(action_name)` | — | 三级查找：自定义→内置→utter_自动 |
| **Action 实例** | `action.run(tracker, domain, **kwargs)` | — | 执行具体动作，返回 ActionResult |
| **domain** | `domain.get_response()`（ActionUtter 内部） | — | ActionUtter 取模板时读取 |
| **tracker** | `tracker.get_slot()`（Action 内部） | `tracker.add_bot_message()`、`tracker.latest_action_name`、`tracker.set_slot()`、`tracker.dialogue_stack` | 写入对话历史、更新最新动作名、槽位、栈帧 |
| **state** | `current_prediction`、`metadata`、`final_responses`、`action_count`、`_command_generator` | `tracker`、`current_action_result`、`final_responses`、`action_count`、`is_finished`、`node_history` | 从图状态读取输入，写回更新 |
| **guard_node** | — | — | action_node 固定连接其后 |

### 与 LLMClient 的间接交互

action_node 本身不直接调用 LLM，但以下 Action 内部会调用：

| Action | LLM 调用 | 通过模块 |
|---|---|---|
| `ActionExtractSlots` | 提取槽位 | `shared.llm.create_llm_client()` |
| `ActionChitChatResponse` | 生成闲聊 | 通过 EnterpriseSearchPolicy 间接调用 |

## 七、全流程中的一次完整 action_node 追踪

```
用户: "我要查订单ORD123"
  │
  ▼ understand_node
  │ StartFlowCommand("order_status") + SetSlotCommand("order_id", "ORD123")
  │ dialogue_stack: [FlowStackFrame(flow_id="order_status", step_id="START")]
  │
  ▼ policy_node（第1轮）
  │ FlowPolicy: order_id 已填充 → 跳过 collect → action_query_order
  │ 返回 PolicyPrediction(action="action_query_order", metadata={next_step_id: "notify"})
  │
  ▼ should_execute_action → "action"
  │
  ▼ action_node  ← 本次追踪焦点
  ┌─────────────────────────────────────────────────────────────────────┐
  │ 1. current_prediction.action = "action_query_order"                │
  │ 2. get_action("action_query_order") → 用户自定义 Action 实例        │
  │ 3. kwargs = {} + {next_step_id: "notify", ...}                     │
  │ 4. result = await action.run(tracker, domain, **kwargs)            │
  │    → ActionResult(responses=[{text: "订单ORD123状态：已发货"}])       │
  │ 5. final_responses.append({text: "订单ORD123状态：已发货"})          │
  │ 6. tracker.add_bot_message({text: "订单ORD123状态：已发货"})         │
  │ 7. tracker.latest_action_name = "action_query_order"               │
  │ 8. is_finished = False（无 slot_to_collect）                        │
  └─────────────────────────────────────────────────────────────────────┘
  │
  ▼ guard_node → should_continue → policy_node（第2轮）
  │ ...继续循环直到 action_listen → response → END
```
