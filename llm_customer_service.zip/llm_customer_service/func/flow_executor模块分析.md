# `flow_executor` 模块分析

## 一、功能概述

`FlowExecutor` 是 Flow 引擎的**步骤执行器**，负责根据当前对话栈状态找到正在执行的 Flow 和步骤，按步骤类型执行相应操作，并返回执行结果。它是 `FlowPolicy.predict()` 循环内部的核心驱动组件。

```
FlowPolicy.predict() 的循环
  │
  │  for _ in range(max_iterations):
  │      result = self.executor.execute_next_step(tracker)   ← FlowExecutor 在此被调用
  │      │
  │      ├─ result.slot_to_collect → 返回追问动作
  │      ├─ result.action → 返回业务动作
  │      ├─ result.flow_completed → 返回完成动作
  │      ├─ result.next_step_id → 推进步骤，continue 循环
  │      └─ 都没有 → break
```

核心能力：
1. **定位当前步骤**：从 dialogue_stack 的 FlowStackFrame 中读取 step_id，找到对应的 FlowStep
2. **按类型分发执行**：7 种步骤类型各有独立的执行方法
3. **条件分支解析**：支持 `if/then/else` 条件列表，基于槽位值路由到不同后续步骤
4. **步骤推进**：通过 `advance_flow()` 更新栈帧的 step_id

## 二、执行流程

`execute_next_step(tracker)` 的完整处理流程：

```
输入: tracker
  │
  ▼
1. 获取当前 Flow
  │  ├─ tracker.active_flow → flow_id
  │  ├─ self.flows.get_flow(flow_id) → flow
  │  └─ 找不到 → flow_completed = True，返回
  │
  ▼
2. 获取当前步骤
  │  ├─ _get_current_step_id(tracker, flow)
  │  │   ├─ 从 dialogue_stack.find_flow_frame(flow.id) 取 step_id
  │  │   ├─ step_id == "START" → 返回 flow 的第一个步骤 ID
  │  │   └─ 其他 → 直接返回 step_id
  │  ├─ flow.get_step(current_step_id) → current_step
  │  └─ 找不到 → flow_completed = True，返回
  │
  ▼
3. 按步骤类型分发执行
  │
  │  StepType.ACTION    → _execute_action_step()
  │  StepType.COLLECT   → _execute_collect_step()
  │  StepType.SET_SLOT  → _execute_set_slot_step()
  │  StepType.CONDITION → _execute_condition_step()
  │  StepType.LINK      → _execute_link_step()
  │  StepType.CALL      → _execute_call_step()
  │  StepType.END       → flow_completed = True
  │
  ▼
输出: ExecutionResult
```

## 三、七种步骤类型详解

### 1. ACTION 步骤 — 执行业务动作

```python
def _execute_action_step(self, step, tracker, flow) -> ExecutionResult:
    result.action = step.action           # 要执行的动作名
    result.next_step_id = step.next       # 下一步 ID
    if step.next is None or step.next == "end":
        result.flow_completed = True      # 无下一步则标记完成
    return result
```

| 字段 | 值 | 说明 |
|---|---|---|
| `action` | `step.action` | 如 `action_query_logistics` |
| `next_step_id` | `step.next` | 下一步 ID |
| `flow_completed` | 取决于 next | next 为空/end → True |

**纯声明型步骤**，不做任何状态修改，只是告知 FlowPolicy "下一步要执行这个动作"。

### 2. COLLECT 步骤 — 收集槽位（最复杂的步骤）

```python
def _execute_collect_step(self, step, tracker, flow) -> ExecutionResult:
```

核心逻辑是判断**是否需要询问用户**：

```
                    槽位值为 None？
                   /              \
                 Yes               No
                  │                │
                  │         ask_before_filling？
                  │         /              \
                  │       True            False
                  │        │                │
                  │   正在收集此槽位？      已填充，跳过
                  │   /          \         → next_step_id
                  │ Yes          No
                  │  │            │
                  │ 用户已填值，  清空槽位，
                  │ 继续执行      需要询问
                  │ → next_step_id → need_ask=True
                  │
                 Yes
                  │
              需要询问
           → need_ask=True
```

**需要询问时（need_ask = True）**：

| 字段 | 值 | 说明 |
|---|---|---|
| `slot_to_collect` | `step.collect` | 如 `"order_id"` |
| `action` | `step.action` 或 `utter_ask_{slot}` | 显式指定则用指定的，否则用默认追问 |
| `metadata.fallback_action` | `action_ask_{slot}` | 供 action_node 降级使用 |

**已填充无需询问时**：

| 字段 | 值 | 说明 |
|---|---|---|
| `next_step_id` | 解析后的下一步 | 跳过追问，直接进入下一步 |

**ask_before_filling 设计要点**：
- 语义：即使 LLM 已经预填充了槽位值，也要先清空并让用户确认
- 用途场景：如"确认收货信息"——先清空 `set_receive_info` 让用户重新确认
- 避免死循环：通过 `flow_frame.slot_to_collect` 判断是否已经询问过

### 3. SET_SLOT 步骤 — 直接设置槽位

```python
def _execute_set_slot_step(self, step, tracker, flow) -> ExecutionResult:
    tracker.set_slot(step.slot_name, step.slot_value)   # 直接修改 tracker
    result.events.append({event: "slot_set", ...})       # 记录事件
    result.next_step_id = step.next
```

**这是唯一一个在 FlowExecutor 内部直接修改 tracker 状态的步骤类型**。其他步骤只是返回"告诉 FlowPolicy 该做什么"，而 SET_SLOT 直接产生副作用。

### 4. CONDITION 步骤 — 条件分支

```python
def _execute_condition_step(self, step, tracker, flow) -> ExecutionResult:
    condition_met = self._evaluate_condition(step.condition, tracker)
    if condition_met:
        result.next_step_id = step.then
    else:
        result.next_step_id = step.else_
```

条件表达式支持三种格式：

| 格式 | 示例 | 判断逻辑 |
|---|---|---|
| 相等 | `slots.order_type == "refund"` | `str(value) == expected` |
| 不等 | `slots.order_type != "refund"` | `str(value) != expected` |
| 真值 | `slots.set_receive_info` | `bool(value)` |

### 5. LINK 步骤 — 链接到另一个 Flow（不返回）

```python
def _execute_link_step(self, step, tracker, flow) -> ExecutionResult:
    tracker.end_flow()                  # 结束当前 Flow
    tracker.start_flow(step.flow_id)    # 启动新 Flow
    result.flow_completed = True        # 标记当前 Flow 完成
```

**结束当前 Flow，启动新 Flow，不返回**。相当于页面跳转。

### 6. CALL 步骤 — 调用子 Flow（完成后返回）

```python
def _execute_call_step(self, step, tracker, flow) -> ExecutionResult:
    tracker.start_flow(step.flow_id)    # 压入新 Flow（当前 Flow 不弹出）
    result.metadata["return_step"] = step.next   # 记录返回点
```

**当前 Flow 保留在栈中，子 Flow 压入栈顶。子 Flow 完成后弹出，回到当前 Flow 的 `step.next` 位置**。相当于函数调用。

### 7. END 步骤 — 直接结束

```python
result.flow_completed = True
```

## 四、条件分支解析 — `_resolve_next_step`

`step.next` 字段不仅支持简单的字符串 ID，还支持条件列表：

```yaml
# 简单字符串
next: check_status

# 条件列表
next:
  - if: "slots.order_type == refund"
    then: do_refund
  - if: "slots.order_type == exchange"
    then: do_exchange
  - else: confirm_choice
```

解析逻辑：

```
next 是字符串？ → 直接返回
next 是列表？   → 遍历每个分支：
                  ├─ "if" 条件满足 → 返回 then 值
                  │                 如果 then 是列表 → 提取第一个步骤的 action（嵌套动作）
                  └─ "else" → 返回 else 值
```

## 五、如何被调用

`FlowExecutor` 仅有一个调用方：`FlowPolicy`。

### 初始化

```python
# flow_policy.py:68
self.executor = FlowExecutor(flows=self.flows)
```

### 调用点1：`execute_next_step` — 在循环中执行下一步

```python
# flow_policy.py:132-134
for _ in range(max_iterations):
    result = self.executor.execute_next_step(tracker)
```

这是主调用点，在 FlowPolicy.predict() 的循环中反复调用。

### 调用点2：`advance_flow` — 推进步骤位置

```python
# flow_policy.py:190 / 234
self.executor.advance_flow(tracker, result.next_step_id)
```

当确定了下一步 ID 后，更新栈帧的 step_id，为下一轮 `execute_next_step` 做准备：

```python
def advance_flow(self, tracker, next_step_id):
    flow_frame = tracker.dialogue_stack.top_flow_frame()
    if flow_frame:
        flow_frame.step_id = next_step_id
```

### 完整调用链

```
policy_node
  │
  ▼
FlowPolicy.predict()
  │
  ├── 首轮：检查 completing 标志 → action_flow_completed
  │
  └── 核心循环 for _ in range(50):
        │
        ├─ result = self.executor.execute_next_step(tracker)
        │     │
        │     └─ 根据步骤类型返回 ExecutionResult
        │
        ├─ slot_to_collect 有值 → 返回追问动作（退出循环）
        ├─ action 有值 → 可能设 completing 或 advance_flow → 返回动作（退出循环）
        ├─ flow_completed → end_flow → 返回完成动作（退出循环）
        ├─ next_step_id 有值 → advance_flow → continue 继续
        └─ 都没有 → break
```

## 六、输出内容 — ExecutionResult

```python
@dataclass
class ExecutionResult:
    action: Optional[str] = None           # 要执行的动作名
    slot_to_collect: Optional[str] = None   # 要收集的槽位名
    events: List[Dict[str, Any]]            # 产生的事件列表
    flow_completed: bool = False            # Flow 是否已完成
    next_step_id: Optional[str] = None      # 下一个步骤 ID
    metadata: Dict[str, Any]                # 元数据
```

### 各步骤类型的典型输出

| 步骤类型 | action | slot_to_collect | next_step_id | flow_completed | events |
|---|---|---|---|---|---|
| **ACTION** | `step.action` | — | `step.next` | next为空/end时True | [] |
| **COLLECT**(需询问) | `utter_ask_xxx` | `slot_name` | — | — | [] |
| **COLLECT**(已填充) | — | — | 解析后的next | — | [] |
| **SET_SLOT** | — | — | `step.next` | next为空/end时True | [slot_set] |
| **CONDITION** | — | — | then 或 else_ | 结果为空/end时True | [] |
| **LINK** | — | — | — | **True** | [flow_switched] |
| **CALL** | — | — | — | — | [subflow_called] |
| **END** | — | — | — | **True** | [] |

### COLLECT 步骤的特殊 metadata

当 collect 步骤未显式指定 action 时，metadata 中携带 `fallback_action`：

```python
result.action = "utter_ask_order_id"
result.metadata = {
    "fallback_action": "action_ask_order_id"   # utter 版本无响应时降级到此
}
```

这个 fallback 机制在 `action_node` 中生效：如果 `utter_ask_order_id` 从 domain 中找不到模板导致无响应，action_node 会自动尝试 `action_ask_order_id`。

## 七、FlowExecutor 与 FlowPolicy 的职责边界

| 职责 | FlowExecutor | FlowPolicy |
|---|---|---|
| 定位当前步骤 | ✅ `_get_current_step_id` | ❌ |
| 按类型执行步骤 | ✅ 7种 `_execute_xxx_step` | ❌ |
| 修改 tracker 状态 | 仅 SET_SLOT/LINK/CALL | completing 标志、slot_to_collect |
| 循环推进逻辑 | ❌ 只执行一步 | ✅ `for` 循环 + 判断退出条件 |
| 推进步骤位置 | ✅ `advance_flow` | ✅ 决定何时调用 advance_flow |
| 结束 Flow | 仅标记 `flow_completed` | ✅ `tracker.end_flow()` + 重置槽位 |
| 构造 PolicyPrediction | ❌ | ✅ |

**核心原则**：FlowExecutor 是"单步执行器"，每次调用只处理当前步骤并返回结果；FlowPolicy 是"循环调度器"，负责反复调用 FlowExecutor 并根据返回结果决定循环走向。
