# `action` 模块分析

## 一、功能概述

`actions.py` 是对话系统的**动作定义与注册中心**，包含三部分能力：

1. **基类定义** — `Action` 抽象基类和 `ActionResult` 结果结构，约束所有动作的统一接口
2. **内置动作** — 14 个预定义动作，覆盖对话控制、降级、栈帧操控等核心逻辑
3. **注册工厂** — `get_action()` / `register_action()` 提供动作名到实例的映射，支持自定义扩展

Action 是系统中**唯一产生可见输出**（回复文本、按钮、图片）的组件，其他模块（Policy、Command、FlowExecutor）只负责决策和状态变更，最终都必须通过某个 Action 的 `run()` 方法才能真正给用户发出消息。

```
Command → 修改状态（压栈、设槽）     → 无输出
Policy  → 决策（选动作名）            → 无输出
FlowExecutor → 推进步骤（返回动作名） → 无输出
Action.run() → 产出回复文本           → ✅ 唯一输出源
```

## 二、14 个内置动作分类

### A. 对话控制类

| 动作 | 功能 | 输出 |
|---|---|---|
| `ActionListen` | 空操作，等待用户输入 | 无 |
| `ActionRestart` | 重置 tracker 全部状态 | 事件：conversation_restarted |
| `ActionSessionStart` | 初始化新会话（等同 Restart） | 事件：session_started |

### B. 栈帧操控类（压入帧，交由 Policy 生成回复）

| 动作 | 压入的栈帧 | 后续由谁处理 |
|---|---|---|
| `ActionDefaultFallback` | `CannotHandleStackFrame` | EnterpriseSearchPolicy |
| `ActionChitChatResponse` | `ChitChatStackFrame` | EnterpriseSearchPolicy |
| `ActionHumanHandoff` | `HumanHandoffStackFrame` | EnterpriseSearchPolicy |
| `ActionTriggerSearch` | `SearchStackFrame` | EnterpriseSearchPolicy |
| `ActionFlowCompleted` | `CompletedStackFrame` | EnterpriseSearchPolicy |

这类动作遵循**"Action 只压帧，Policy 来回复"**的解耦设计：Action 的 `run()` 仅压入对应栈帧，不直接生成回复文本。下一轮循环中 EnterpriseSearchPolicy 检测到该栈帧，才调用 LLM/RAG 生成实际回复。

### C. Flow 管理类（直接操作 dialogue_stack）

| 动作 | 功能 | 交互模块 |
|---|---|---|
| `ActionCancelFlow` | 弹出栈顶 FlowStackFrame | tracker.end_flow() |
| `ActionChangeFlow` | 弹出旧 Flow + 压入新 Flow | tracker.end_flow() + tracker.start_flow() |
| `ActionCleanStack` | 清空整个 dialogue_stack | tracker.cancel_flow() |

### D. 文本输出类（直接产生回复）

| 动作 | 功能 | 文本来源 |
|---|---|---|
| `ActionSendText` | 发送任意文本 | kwargs["text"]（由 Policy metadata 传入） |
| `ActionUtter` | 模板化回复 | domain.get_response() + 槽位变量替换 |
| `ActionHandleHelp` | 帮助信息 | 硬编码帮助文本 |
| `ActionClarify` | 澄清追问 | kwargs["question"] + 选项列表 |

### E. 槽位提取类

| 动作 | 功能 | 交互模块 |
|---|---|---|
| `ActionExtractSlots` | LLM 从用户消息提取槽位值 | LLMClient + tracker.set_slot() |

## 三、关键动作详解

### ActionSendText — RAG / 闲聊的"出口"

```python
async def run(self, tracker, domain, **kwargs):
    text = kwargs.get("text", "")    # ← EnterpriseSearchPolicy 通过 metadata 传入
    if text:
        result.add_response(text)
    return result
```

这是 EnterpriseSearchPolicy 产出回复的通道。Policy 生成文本后放入 metadata，action_node 取出 metadata 调用 `ActionSendText.run()`，文本才正式进入 `final_responses`。

### ActionUtter — 模板化回复

```python
async def run(self, tracker, domain, **kwargs):
    responses = domain.get_response(self._utter_name)  # ← 从 domain.yml 取模板
    if responses:
        response = random.choice(responses)             # 随机选一个变体
        text = response.text
        # 替换 {slot_name} 为实际槽位值
        for slot_name, slot_value in tracker.get_all_slots().items():
            text = text.replace(f"{{{slot_name}}}", str(slot_value or ""))
        result.add_response(text, buttons=response.buttons, ...)
```

任何 `utter_` 前缀的动作名自动匹配此 Action，无需注册。

### ActionExtractSlots — LLM 槽位提取

```python
async def run(self, tracker, domain, **kwargs):
    # 1. 构建 LLM 提示词
    prompt = f"从用户消息中提取: {slots_to_extract}\n用户消息: {user_message}"
    
    # 2. 调用 LLM
    response = await client.complete([{"role": "user", "content": prompt}])
    
    # 3. 解析 JSON 结果
    extracted = json.loads(response.content)
    
    # 4. 写入 tracker
    for slot_name, slot_value in extracted.items():
        if slot_value is not None:
            tracker.set_slot(slot_name, slot_value)
```

### 栈帧操控动作 — 解耦设计

```python
# ActionDefaultFallback.run() — 典型例子
tracker.dialogue_stack.push(CannotHandleStackFrame(reason=reason))
result.add_event("cannot_handle_triggered", reason=reason)
return result    # ← 没有 add_response，不产生回复文本
```

后续链路：
```
Action压帧 → action_node(无回复) → guard → policy_node
  → FlowPolicy放弃 → EnterpriseSearchPolicy检测到CannotHandleStackFrame
  → 生成兜底回复文本 → 返回action_send_text → action_node执行 → 产出回复
```

## 四、注册与查找机制

### 三级查找链

```python
def get_action(name: str) -> Optional[Action]:
    # 1. 自定义动作注册表（优先级最高，用户通过 register_action 注入）
    if name in _CUSTOM_ACTIONS:
        return _CUSTOM_ACTIONS[name]

    # 2. 内置动作注册表（14 个内置动作）
    if name in _BUILTIN_ACTIONS:
        return _BUILTIN_ACTIONS[name]()    # ← 每次调用创建新实例

    # 3. utter_ 前缀自动创建模板动作
    if name.startswith("utter_"):
        return ActionUtter(name)

    return None
```

### 自定义动作的注册流程

```
Agent 初始化
  │
  ▼ load_custom_actions()
  │  扫描 actions/ 目录下的 .py 文件
  │  动态 import 模块
  │  找到 Action 子类
  │  实例化 + register_action(action_instance)
  │
  ▼ _CUSTOM_ACTIONS["action_query_order"] = QueryOrderAction实例
```

## 五、如何被调用

Action 模块的调用方只有一个：`action_node`。

```python
# action.py:107-136
action_name = current_prediction.action           # ← 从 PolicyPrediction 取动作名
action = get_action(action_name)                  # ← 查找动作实例

# 合并参数
kwargs = dict(metadata)
kwargs.update(current_prediction.metadata or {})  # ← Policy metadata 进入 kwargs

# 执行
result = await action.run(tracker, domain, **kwargs)
```

完整调用链：
```
policy_node
  → PolicyPrediction(action="action_send_text", metadata={text: "..."})
  → should_execute_action → 返回 "action"
  → action_node
      → get_action("action_send_text") → ActionSendText
      → action.run(tracker, domain, text="...") → ActionResult
      → final_responses.append({text: "..."})
      → tracker.add_bot_message(...)
      → tracker.latest_action_name = "action_send_text"
```

## 六、输出内容 — ActionResult

```python
@dataclass
class ActionResult:
    responses: List[Dict[str, Any]]   # 回复列表，每项含 text + 可选 buttons/image/custom
    events: List[Dict[str, Any]]      # 事件列表，如 slot_set / flow_cancelled
    success: bool                     # 是否成功
    metadata: Dict[str, Any]         # 额外元数据
```

典型回复结构：
```python
# 纯文本
{"text": "退货需在签收后7天内申请", "buttons": [], "image": None, "custom": None}

# 带按钮
{"text": "请选择操作类型", "buttons": [{"title": "退货", "payload": "/SetSlots(type=refund)"}]}

# 无回复（栈帧操控类 Action）
responses = []   # ← 空列表
```

## 七、交互模块全景

```
                    ┌──────────────────────────┐
                    │      actions.py          │
                    └──────────┬───────────────┘
                               │
         ┌─────────────────────┼─────────────────────┐
         │                     │                     │
    读取模板              读写槽位             读写对话栈
         │                     │                     │
         ▼                     ▼                     ▼
   ┌──────────┐         ┌──────────┐         ┌──────────────┐
   │  domain  │         │ tracker  │         │dialogue_stack│
   │          │         │          │         │              │
   │ responses│         │ set_slot │         │ push/pop     │
   │ get_resp │         │ get_slot │         │ clear        │
   └──────────┘         └──────────┘         └──────────────┘
         │                     │
         │                     │
         │              ┌──────┴──────┐
         │              │             │
         │              ▼             ▼
         │        ┌──────────┐  ┌──────────────┐
         │        │   LLM    │  │   retriever  │
         │        │ Client   │  │              │
         │        └──────────┘  └──────────────┘
         │         ActionExtractSlots   (暂未在此模块直接调用，
         │         ActionChitChat       由 EnterpriseSearchPolicy 间接使用)
         │
         ▼
   ┌──────────────────────────────────────────┐
   │              action_node                  │
   │  get_action() → action.run() → ActionResult
   │  → final_responses → tracker.add_bot_msg │
   └──────────────────────────────────────────┘
```

### 各动作的具体交互

| 动作 | 读 domain | 写 tracker 槽位 | 写 dialogue_stack | 读 LLM | 读 retriever |
|---|---|---|---|---|---|
| `ActionUtter` | ✅ get_response | ❌ | ❌ | ❌ | ❌ |
| `ActionSendText` | ❌ | ❌ | ❌ | ❌ | ❌ |
| `ActionExtractSlots` | ❌ | ✅ set_slot | ❌ | ✅ | ❌ |
| `ActionDefaultFallback` | ❌ | ❌ | ✅ push | ❌ | ❌ |
| `ActionChitChatResponse` | ❌ | ❌ | ✅ push | ❌ | ❌ |
| `ActionHumanHandoff` | ❌ | ❌ | ✅ push | ❌ | ❌ |
| `ActionTriggerSearch` | ❌ | ❌ | ✅ push | ❌ | ❌ |
| `ActionFlowCompleted` | ❌ | ❌ | ✅ push | ❌ | ❌ |
| `ActionCancelFlow` | ❌ | ❌ | ✅ end_flow | ❌ | ❌ |
| `ActionChangeFlow` | ❌ | ❌ | ✅ end+start | ❌ | ❌ |
| `ActionCleanStack` | ❌ | ❌ | ✅ clear | ❌ | ❌ |
| `ActionRestart` | ❌ | ✅ restart | ✅ restart | ❌ | ❌ |
| `ActionClarify` | ❌ | ❌ | ❌ | ❌ | ❌ |
| `ActionListen` | ❌ | ❌ | ❌ | ❌ | ❌ |

## 八、设计模式总结

### 1. 命令-执行分离

```
Command（理解阶段）→ 压栈帧 / 设槽位 → 修改状态
Policy（决策阶段）→ 选动作名               → 纯决策
Action（执行阶段）→ run() 产出回复          → 真正做事
```

一个完整回复可能需要多轮才能到达用户：
```
用户闲聊 → understand: ChitChatCommand → push(ChitChatStackFrame)
         → policy: FlowPolicy放弃 → EnterpriseSearchPolicy命中 → action_send_text
         → action: ActionSendText.run(text="你好呀") → final_responses → 用户收到
```

### 2. 栈帧代理模式

`ActionDefaultFallback`、`ActionChitChatResponse`、`ActionHumanHandoff`、`ActionTriggerSearch`、`ActionFlowCompleted` 这 5 个 Action 自身不生成回复，只压入对应的栈帧，将回复生成的职责代理给 EnterpriseSearchPolicy。这种设计的优势：

- Action 保持轻量，无需关心 LLM 调用逻辑
- Policy 层可以统一管理所有降级逻辑和 LLM 交互
- 栈帧作为中间状态，可以被中断、取消、替换
