# `enterprise_search_policy` 模块分析

## 一、功能概述

`EnterpriseSearchPolicy` 是策略集成中的**低优先级兜底策略**（priority=50，低于 FlowPolicy 的 100），负责处理 FlowPolicy 不关心的所有场景——知识库检索（RAG）、闲聊、无法处理、Flow 完成追问、人工转接。

它的工作方式不是主动分析用户意图，而是**检测对话栈顶帧的类型**，根据帧类型分发到不同的处理逻辑：

```
对话栈顶帧类型                  EnterpriseSearchPolicy 行为
┌──────────────────────┐      ┌────────────────────────────────┐
│ SearchStackFrame     │  →   │ 执行知识库检索 → 生成 RAG 回答 │
│ ChitChatStackFrame   │  →   │ LLM 生成闲聊回复              │
│ CannotHandleStackFrame│ →   │ 返回兜底默认回复              │
│ CompletedStackFrame  │  →   │ 追问"还有其他需求吗"          │
│ HumanHandoffStackFrame│ →   │ 返回转接人工话术              │
│ 其他 / 空栈          │  →   │ 放弃(abstain)                 │
└──────────────────────┘      └────────────────────────────────┘
```

核心设计原则：**栈帧驱动，被动响应**。Command 在 `understand_node` 阶段已经压入了对应的栈帧，EnterpriseSearchPolicy 只需检测栈顶帧类型并执行相应操作。

## 二、降级链

EnterpriseSearchPolicy 内部实现了 SearchStackFrame 的降级链：

```
SearchStackFrame 处理流程：

用户消息
  │
  ▼
知识库检索（retriever.search）
  │
  ├─ 检索到结果 → 生成 RAG 回答
  │   │
  │   ├─ LLM 回答有效（不含 [NO_RAG_ANSWER]）→ ✅ 返回 RAG 回答 (confidence=0.9)
  │   └─ LLM 回答无效（含 [NO_RAG_ANSWER]）→ 降级 ↓
  │
  ├─ 检索无结果 或 RAG 回答无效 → 降级到闲聊
  │   │
  │   ├─ chitchat_enabled=True → LLM 生成闲聊回复 → 🔶 返回闲聊回答 (confidence=0.7)
  │   └─ chitchat_enabled=False → 继续降级 ↓
  │
  └─ 最终兜底 → 🔴 返回 action_default_fallback (confidence=0.5)
```

| 级别 | 结果 | action | confidence | degradation_reason |
|---|---|---|---|---|
| 1 — RAG 成功 | 基于知识库的回答 | `action_send_text` | 0.9 | DEFAULT |
| 2 — 闲聊降级 | LLM 通用回复 | `action_send_text` | 0.7 | CHITCHAT |
| 3 — 无法处理 | 默认兜底话术 | `action_default_fallback` | 0.5 | CANNOT_HANDLE |
| 异常 — 内部错误 | 默认兜底话术 | `action_default_fallback` | 0.3 | INTERNAL_ERROR |

## 三、predict 核心流程

```
predict(tracker, domain, flows)
  │
  ▼
1. 获取栈顶帧
  │  top_frame = tracker.dialogue_stack.top()
  │
  ▼
2. 最近动作检查（防重入）
  │
  │  条件：最新动作非 action_listen
  │       AND 当前帧不是 CompletedStackFrame / HumanHandoffStackFrame
  │
  │  满足 → 放弃(abstain)，让 FlowPolicy 先处理
  │  不满足 → 继续
  │
  │  原因：action 执行后 tracker 状态尚未更新完毕，
  │        避免在同一轮重复触发 EnterpriseSearchPolicy
  │
  │  特例：CompletedStackFrame 和 HumanHandoffStackFrame
  │        需要立即处理，不受此限制
  │
  ▼
3. 按栈帧类型分发
  │
  ├─ CompletedStackFrame    → _handle_completed_frame()
  ├─ HumanHandoffStackFrame → _handle_human_handoff_frame()
  ├─ ChitChatStackFrame     → _handle_chitchat_frame()
  ├─ CannotHandleStackFrame → _handle_cannot_handle_frame()
  ├─ SearchStackFrame       → _handle_search_frame()
  └─ 其他 / None            → 放弃(abstain)
```

## 四、五种栈帧处理详解

### 1. SearchStackFrame — 知识库检索（最复杂）

```python
async def _handle_search_frame(self, tracker, user_message):
```

处理步骤：

```
1. 调用 retriever.search(query, top_k, tracker_state) → List[SearchResult]
2. 按 similarity_threshold 过滤低分结果
3. 有结果 → 拼接上下文 → LLM 生成 RAG 回答
   ├─ 回答有效 → 弹栈 → 返回 action_send_text + 回答文本
   └─ 回答含 [NO_RAG_ANSWER] → 降级
4. 无结果 或 降级 → 尝试闲聊（chitchat_enabled）
   ├── 成功 → 弹栈 → 返回 action_send_text + 闲聊文本
   └── 失败 → 弹栈 → 返回 action_default_fallback
5. 异常 → 弹栈 → 返回 action_default_fallback + error 信息
```

弹栈操作：**所有分支都会弹出 SearchStackFrame**，确保即便降级也不会残留栈帧。

metadata 结构：
```python
# RAG 成功
metadata = {
    "text": "根据知识库...",
    "degradation_reason": "default",
    "search_results": ["文档1内容", "文档2内容"],  # 原始检索结果
}

# 闲聊降级
metadata = {
    "text": "你好呀！...",
    "degradation_reason": "chitchat",
}
```

### 2. ChitChatStackFrame — 闲聊回复

```python
async def _handle_chitchat_frame(self, tracker, user_message):
```

```
1. 弹出 ChitChatStackFrame
2. 用户消息为空 → 返回固定话术 "你好！有什么可以帮您的吗？"
3. 调用 LLM 生成闲聊回复 → 返回 action_send_text
4. LLM 失败 → 返回默认闲聊 "你好！很高兴和你聊天。"
```

### 3. CannotHandleStackFrame — 无法处理

```python
async def _handle_cannot_handle_frame(self, tracker, frame, domain):
```

```
1. 弹出 CannotHandleStackFrame
2. 尝试从 domain 获取 utter_default 模板
3. 找不到模板 → 使用默认话术 "抱歉，我没有理解您的意思。请换一种方式表达。"
4. 返回 action_send_text
```

### 4. CompletedStackFrame — Flow 完成追问

```python
async def _handle_completed_frame(self, tracker, frame, domain):
```

```
1. 弹出 CompletedStackFrame
2. 尝试从 domain 获取 utter_can_do_something_else 模板
3. 找不到模板 → 使用默认话术 "还有什么我可以帮您的吗？"
4. 返回 action_send_text
```

这个处理是 Flow 收尾链路中的一环：
```
Flow最后一个action → policy(completing=True) → action_flow_completed
→ 压入CompletedStackFrame → policy(CompletedStackFrame) → "还有什么可以帮您的？"
→ policy(栈空) → action_listen → 等待用户
```

### 5. HumanHandoffStackFrame — 人工转接

```python
async def _handle_human_handoff_frame(self, tracker, frame, domain):
```

```
1. 弹出 HumanHandoffStackFrame
2. 尝试从 domain 获取 utter_human_handoff 模板
3. 找不到模板 → 使用默认话术 "好的，正在为您转接人工客服，请稍候..."
4. 返回 action_send_text，metadata 中标记 human_handoff=True
```

metadata 中 `human_handoff=True` 是关键信号，前端据此展示转接 UI。

## 五、RAG 实现细节

### 检索流程

```python
async def _search(self, query, tracker=None):
    # 1. 构建 tracker_state（传入用户信息和对话历史）
    tracker_state = tracker.to_dict() if tracker else None
    
    # 2. 调用检索器
    results = await self._retriever.search(
        query,
        top_k=self.config.retrieval.top_k,          # 默认 3
        tracker_state=tracker_state,
    )
    
    # 3. 过滤低相似度
    filtered = [r for r in results if r.score is None or r.score >= threshold]
```

### RAG 提示词模板

```
你是一个专业的客服助手，正在根据知识库文档回答用户问题。

### 参考文档
{context}           ← 检索结果拼接：编号. 来源\n内容

### 用户问题
{question}          ← 用户原始消息

### 回答要求
1. 直接回答问题，不要添加问候语或寒暄
2. 禁止使用 emoji 表情符号
3. 使用专业、简洁的语气
4. 只陈述文档中明确提到的信息
5. 如果文档信息不足以回答问题，仅回复"[NO_RAG_ANSWER]"

回答：
```

`[NO_RAG_ANSWER]` 是降级信号——LLM 认为检索到的文档不足以回答用户问题时输出此标记，触发降级到闲聊或兜底。

## 六、如何被调用

### 初始化

```python
# agent.py:186-189
self.policy_ensemble = PolicyEnsemble(policies=[
    FlowPolicy(flows=self.flows),       # priority=100
    EnterpriseSearchPolicy(),           # priority=50
])
```

### 调用链

```
policy_node
  │
  ▼
PolicyEnsemble.predict(tracker, domain, flows)
  │
  ▼  遍历排好序的策略列表
for policy in self.policies:
  │
  ├── FlowPolicy（priority=100）
  │   ├─ 有活跃 Flow → 返回预测（confidence=1.0 → break 短路）
  │   └─ 无活跃 Flow → 放弃(abstain)
  │
  └── EnterpriseSearchPolicy（priority=50）  ← 只在 FlowPolicy 放弃时走到
      ├─ 栈顶帧匹配支持的类型 → 返回预测
      └─ 栈顶帧不匹配 / 栈为空 → 放弃(abstain)
```

### 什么时候会走到 EnterpriseSearchPolicy？

| 场景 | FlowPolicy | EnterpriseSearchPolicy |
|---|---|---|
| 用户触发新流程 | ✅ 命中（有活跃 Flow） | 不走到 |
| Flow 正在收集槽位 | ✅ 命中 | 不走到 |
| Flow 执行业务动作 | ✅ 命中 | 不走到 |
| Flow completing 收尾 | ✅ 命中（返回 action_flow_completed） | 不走到 |
| Flow 结束后（CompletedStackFrame） | ❌ 放弃（无活跃 Flow） | ✅ 命中 |
| 用户闲聊 | ❌ 放弃 | ✅ 命中（ChitChatStackFrame） |
| 知识库搜索 | ❌ 放弃 | ✅ 命中（SearchStackFrame） |
| 无法处理 | ❌ 放弃 | ✅ 命中（CannotHandleStackFrame） |
| 人工转接 | ❌ 放弃 | ✅ 命中（HumanHandoffStackFrame） |
| 栈为空，无事可做 | ❌ 放弃 | ❌ 放弃 → fallback action_listen |

**核心规律：FlowPolicy 管所有"有 Flow 在执行"的场景，EnterpriseSearchPolicy 管所有"没有 Flow 但栈上还有其他帧"的场景。**

## 七、输出内容

每次 predict 返回 `PolicyPrediction`：

```python
PolicyPrediction(
    action=str,               # 动作名（通常为 "action_send_text"）
    confidence=float,         # 置信度
    events=[],                # 附带事件
    policy_name="enterprise_search_policy",
    metadata={                # 核心数据
        "text": "...",        # ← 最终回复文本（action_node 据此发送给用户）
        ...                   # 其他元数据
    },
)
```

### 各帧类型的典型输出

**SearchStackFrame — RAG 成功**
```python
PolicyPrediction(
    action="action_send_text",
    confidence=0.9,
    policy_name="enterprise_search_policy",
    metadata={
        "text": "退货需在签收后7天内申请，商品需保持原包装完好。",
        "degradation_reason": "default",
        "search_results": ["退货政策文档内容..."],
    },
)
```

**SearchStackFrame — 闲聊降级**
```python
PolicyPrediction(
    action="action_send_text",
    confidence=0.7,
    policy_name="enterprise_search_policy",
    metadata={
        "text": "今天天气不错呢，有什么可以帮您的吗？",
        "degradation_reason": "chitchat",
    },
)
```

**ChitChatStackFrame — 闲聊回复**
```python
PolicyPrediction(
    action="action_send_text",
    confidence=0.9,
    policy_name="enterprise_search_policy",
    metadata={
        "text": "哈哈，是的呢！还有什么可以帮您的吗？",
        "degradation_reason": "chitchat",
    },
)
```

**CompletedStackFrame — Flow 完成追问**
```python
PolicyPrediction(
    action="action_send_text",
    confidence=0.9,
    policy_name="enterprise_search_policy",
    metadata={
        "text": "还有什么我可以帮您的吗？",
        "previous_flow": "refund",
    },
)
```

**CannotHandleStackFrame — 无法处理**
```python
PolicyPrediction(
    action="action_send_text",
    confidence=0.5,
    policy_name="enterprise_search_policy",
    metadata={
        "text": "抱歉，我没有理解您的意思。请换一种方式表达。",
        "degradation_reason": "cannot_handle",
        "reason": "no_relevant_flow",
    },
)
```

**HumanHandoffStackFrame — 人工转接**
```python
PolicyPrediction(
    action="action_send_text",
    confidence=0.95,
    policy_name="enterprise_search_policy",
    metadata={
        "text": "好的，正在为您转接人工客服，请稍候...",
        "human_handoff": True,
        "reason": "user_request",
    },
)
```

## 八、策略间的协作全景

```
用户消息
  │
  ▼ understand_node
  │  CommandProcessor 执行命令 → 压入栈帧
  │
  ▼ policy_node（循环）
  │
  │  FlowPolicy（priority=100）
  │  ├── 有活跃 Flow → 接管，返回 Flow 步骤动作
  │  └── 无活跃 Flow → 放弃
  │
  │  EnterpriseSearchPolicy（priority=50）── 只在 FlowPolicy 放弃时介入
  │  ├── CompletedStackFrame → 追问话术
  │  ├── HumanHandoffStackFrame → 转接话术
  │  ├── ChitChatStackFrame → 闲聊回复
  │  ├── CannotHandleStackFrame → 兜底回复
  │  ├── SearchStackFrame → RAG / 闲聊降级 / 兜底
  │  └── 其他 → 放弃
  │
  │  都放弃 → action_listen → 等待用户
  │
  ▼ action_node
  │  从 metadata["text"] 取文本 → 发送给用户
```
