# hll_ai.agent.agent.Agent.load 功能详解

---

## 一句话概括

**从项目目录或模型压缩包加载出一个完整可运行的 Agent 实例。**

它是整个系统最复杂的初始化方法，承担了"把散落的配置文件、用户代码、LLM 密钥拼装成一个有机体"的全部工作。

---

## 输入支持三种格式

| 输入 | 示例 | 处理方式 |
|------|------|---------|
| `.tar.gz` 模型包 | `model-20250619.tar.gz` | 解压到临时目录，从解压目录加载 |
| 含 `models/` 的项目目录 | `ecs_demo/`（内有 `models/model-xxx.tar.gz`） | 自动选最新的 `.tar.gz` 解压加载 |
| 裸项目目录 | `ecs_demo/`（无 `models/` 子目录） | 直接从目录读取配置文件（开发模式） |

---

## 按顺序做了 13 件事

```python
@classmethod
def load(cls, project_path, config=None):
```

### ① 确定工作目录

根据输入类型（压缩包/项目目录），决定实际读文件的路径，并将项目和临时目录都加入 `sys.path`，以便 `import actions`、`import addons`。

### ② 加载 Domain

`Domain.load("domain/")`，支持单文件或目录（自动合并多个 YAML）。遇到 `domain/` 目录优先，否则找 `domain.yml`。

### ③ 加载 Flows

`FlowLoader.load("data/flows/")`，从 YAML 解析出全部 Flow 定义及其步骤。

### ④ 自动发现并注册自定义 Action

`_load_custom_actions("actions/")`：
- 扫描目录下所有 `.py` 文件
- `importlib` 动态导入模块
- `inspect.getmembers` 找到 `Action` 子类
- 实例化 → `register_action()` 注册到全局表
- 同步到 `domain.actions`，确保 Domain 也知道这些 Action 存在

### ⑤ 加载 endpoints 配置

`EndpointsConfig.load("endpoints.yml")`，解析出 models（LLM 配置字典）、embeddings、tracker_store、vector_store、nlg 等外部服务配置。

### ⑥ 从 config.yml 提取 LLM 配置

遍历 `pipeline`，找到 `LLMCommandGenerator` 组件，读取其 `llm: "default"` 引用，再到 endpoints 的 `models.default` 取出真实的 API Key、模型名、api_base 等参数。

### ⑦ 从 policies 提取 EnterpriseSearchPolicy 参数

遍历 `policies`，找到 `EnterpriseSearchPolicy`，读取三个配置：
- `vector_store: "addons.information_retrieval.GraphRAG"` — Retriever 的类路径
- `llm: "default"` — 策略使用的 LLM 引用
- `embeddings: "default"` — 嵌入模型引用

### ⑧ 构建 LLMCommandGenerator

用第⑥步拿到的 LLMConfig 创建 `LLMCommandGenerator`，这是 understand 节点用来翻译用户消息的核心组件。

### ⑨ 创建 TrackerStore

从 `endpoints.tracker_store` 读取类型（memory/json/mysql）和路径，调用 `create_tracker_store()` 创建实例。

### ⑩ 创建 Retriever

这是自定义检索器的动态加载过程：
```python
retriever_class_path = "addons.information_retrieval.GraphRAG"  # 来自 config.yml
connect_config = {"uri": "bolt://...", "user": "neo4j", ...}   # 来自 endpoints.yml
retriever = create_retriever(retriever_class_path, connect_config)
```
底层通过 `importlib.import_module` 动态加载用户写的类，验证它继承自 `InformationRetrieval`，然后实例化并调 `connect()`。

### ⑪ 创建 EnterpriseSearchPolicy

注入 LLM 客户端 + Retriever，形成完整的 RAG 决策能力。

### ⑫ 创建 FlowPolicy

注入 Flows，形成流程编排能力。

### ⑬ 组装返回 Agent

把上述所有组件传入 `cls()` 构造函数：
```python
return cls(
    domain=domain,
    flows=flows,
    tracker_store=tracker_store,
    policy_ensemble=PolicyEnsemble([flow_policy, enterprise_policy]),
    command_generator=command_generator,
    nlg_generator=nlg_generator,  # 如果配置了重述
    config=config,
)
```

---

## 配置引用链路（最容易混淆的部分）

整个方法最核心的设计是**配置分层引用**——config.yml 通过名称引用 endpoints.yml 中定义的资源，避免重复配置：

```
config.yml                          endpoints.yml
──────────                          ──────────
pipeline:                           models:
  - name: LLMCommandGenerator        default:           ← 被引用
    llm: default  ──────────────────→  type: qwen
                                      model: qwen-max
policies:                             api_key: ${DASHSCOPE_API_KEY}
  - name: EnterpriseSearchPolicy    
    llm: default  ──────────────────→ 同上
    embeddings: default  ──────────→  embeddings:       ← 被引用
    vector_store: addons...GraphRAG     default:
                                         type: openai
                                         model: text-embedding-3-small

              同一个 default 模型被 pipeline 和 policies 共享
```

这样改一次 endpoints.yml 就能同时影响所有组件，不会出现 pipeline 用 qwen-max 但 policy 用 gpt-3.5 的不一致问题。

---

## 整体流程图

```
project_path 输入
  │
  ├── 是 .tar.gz？ ─→ 解压到临时目录 → working_path
  ├── 是目录且有 models/？ ─→ 找最新 .tar.gz → 解压 → working_path
  └── 是裸项目目录？ ─→ 直接 working_path
  │
  ▼
working_path
  │
  ├─ Domain.load("domain/")        → domain 对象
  ├─ FlowLoader.load("data/flows/") → flows 列表
  ├─ _load_custom_actions("actions/") → 注册 13 个 Action
  ├─ EndpointsConfig.load()        → models/embeddings/vector_store 配置
  ├─ 读 config.yml                 → 提取 pipeline + policies 引用
  │
  ├─ 用 models.default 创建 LLMCommandGenerator
  ├─ 用 tracker_store 配置创建 TrackerStore
  ├─ 用 vector_store 配置动态加载 GraphRAG → retriever
  ├─ 用 policies.llm 创建 LLMClient
  ├─ 用 LLMClient + retriever 创建 EnterpriseSearchPolicy
  ├─ 创建 FlowPolicy(flows)
  ├─ 可选：用 nlg 配置创建 ResponseRephraser
  │
  └─ Agent(domain, flows, tracker_store, PolicyEnsemble, ...)
```
