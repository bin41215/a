# `command_processor` 模块分析

## 一、功能概述

`CommandProcessor` 的职责是**执行 Command 对象并更新对话状态**。它在整个对话流程中处于「理解阶段」的末端，是 Command 从"数据"变为"副作用"的关键一步：

```
CommandParser                   CommandProcessor                 Policy / Action
┌───────────────────┐          ┌──────────────────┐           ┌───────────────────┐
│ LLM文本 → Command │  ─────►  │ Command.run()    │  ─────►   │ 根据 tracker 状态  │
│ (解析，无副作用)   │          │ 执行，修改tracker │           │ 选择下一个动作     │
└───────────────────┘          └──────────────────┘           └───────────────────┘
```

核心能力：
1. **执行命令**：逐个调用 `Command.run()`，产生事件列表
2. **更新状态**：每次执行后更新 tracker 的对话栈、槽位等
3. **过滤无效命令**：基于 `force_slot_filling` 机制，在 collect 步骤中过滤干扰命令
4. **确定下一步动作**：根据命令类型计算 `next_action`，供 `policy_node` 使用
5. **标记响应类型**：记录 `response_type`（flow / chitchat / knowledge 等）

## 二、处理流程

`CommandProcessor.process(commands, tracker)` 的完整处理流程：

```
输入: commands (List[Command]), tracker (DialogueStateTracker)
  │
  ▼
1. 空命令检查
  │  └─ commands 为空 → 直接返回空 ProcessResult
  │
  ▼
2. _filter_commands_during_collect()   命令过滤（force_slot_filling）
  │  ├─ 获取当前栈顶 FlowStackFrame 的 slot_to_collect
  │  ├─ 不在 collect 步骤 → 不过滤，返回原始列表
  │  └─ 在 collect 步骤：
  │      ├─ 保留：设置当前槽位的 SetSlotCommand
  │      ├─ 保留：CancelFlowCommand 等其他非 StartFlow 命令
  │      ├─ 丢弃：设置其他槽位的 SetSlotCommand
  │      └─ 丢弃：StartFlowCommand（防止 LLM 误触发新流程）
  │
  ▼
3. 逐个执行命令
  │  for command in commands:
  │  ├─ _execute_command(command, tracker)
  │  │   ├─ command.run(tracker, self.flows)   ← 核心：调用命令自身的 run 方法
  │  │   │   ├─ StartFlowCommand.run()   → tracker.start_flow() → dialogue_stack.push_flow()
  │  │   │   ├─ SetSlotCommand.run()     → tracker.set_slot()
  │  │   │   ├─ ChitChatAnswerCommand.run()       → dialogue_stack.push(ChitChatStackFrame)
  │  │   │   ├─ KnowledgeAnswerCommand.run()      → dialogue_stack.push(SearchStackFrame)
  │  │   │   ├─ CannotHandleCommand.run()         → dialogue_stack.push(CannotHandleStackFrame)
  │  │   │   ├─ HumanHandoffCommand.run()         → dialogue_stack.push(HumanHandoffStackFrame)
  │  │   │   └─ 其他...
  │  │   └─ tracker.add_commands([command.as_dict()])   ← 记录命令到 tracker
  │  ├─ _update_response_type(command, result)   ← 标记响应类型
  │  └─ 异常时记录错误，继续执行下一条命令
  │
  ▼
4. _determine_next_action(tracker, result)   确定下一步动作
  │
  ▼
输出: ProcessResult
  ├─ events: List[Dict]          所有命令产生的事件
  ├─ commands_executed: int      成功执行的命令数
  ├─ errors: List[str]           错误列表
  ├─ next_action: Optional[str]  下一步应该执行的动作
  ├─ response_type: str          响应类型
  └─ metadata: Dict              元数据
```

## 三、force_slot_filling 过滤机制

当处于 Flow 的 collect 步骤时（栈顶 FlowStackFrame 有 `slot_to_collect`），LLM 可能输出不一致的命令（如同时设置多个槽位或错误启动新流程）。过滤规则：

| 命令类型 | 处理方式 | 原因 |
|---|---|---|
| `SetSlotCommand(name=当前槽位)` | ✅ 保留 | 正确填充当前收集的槽位 |
| `SetSlotCommand(name=其他槽位)` | ❌ 丢弃 | 防止 LLM 跳过当前槽位提前设置其他值 |
| `StartFlowCommand` | ❌ 丢弃 | 防止 LLM 在 collect 中误判意图启动新流程 |
| `CancelFlowCommand` | ✅ 保留 | 用户有权随时取消当前流程 |
| `ChitChatAnswerCommand` 等 | ✅ 保留 | 用户可能偏离话题或需要转人工 |

示例：
```
当前状态：正在收集 order_id
LLM 输出：
  set slot order_id "ORD123"   ← 保留（当前槽位）
  set slot product_name "手机" ← 丢弃（非当前槽位）
  start flow refund            ← 丢弃（误触发）

最终执行：
  set slot order_id "ORD123"   仅此一条
```

## 四、next_action 确定逻辑

`_determine_next_action` 是 CommandProcessor 对下游 `policy_node` 的"建议"，决定了第一轮策略预测的结果：

| response_type | next_action 设定 | 说明 |
|---|---|---|
| `flow` | `action_run_flow_{flow_id}` | Flow已启动，需要执行Flow步骤 |
| `cancel_flow` | `action_cancel_flow` | 取消当前Flow |
| `change_flow` | `action_change_flow` | 切换到新Flow |
| `session_start` | `action_session_start` | 重新开始会话 |
| `restart` | `action_restart` | 重启对话 |
| `clarify` | `action_clarify` | 需要向用户澄清 |
| `chitchat` | **不设置** | 已压入 ChitChatStackFrame，让 Policy 检测栈帧决定 |
| `knowledge` | **不设置** | 已压入 SearchStackFrame，让 Policy 检测栈帧决定 |
| `cannot_handle` | **不设置** | 已压入 CannotHandleStackFrame，让 Policy 检测栈帧决定 |
| `human_handoff` | **不设置** | 已压入 HumanHandoffStackFrame，让 Policy 检测栈帧决定 |
| 其他（有活跃flow） | **不设置** | 让 FlowPolicy 处理 flow 的下一步 |
| 其他（无活跃flow） | `action_listen` | 等待用户输入 |

**设计要点**：`chitchat`、`knowledge`、`cannot_handle`、`human_handoff` 四类命令已在 `run()` 中压入了对应的栈帧，因此不设置 `next_action`，而是让下游 Policy 通过检测栈顶帧来自行决定动作（`action_send_text`）。这遵循了"Command 只声明意图，Policy 执行实际操作"的解耦原则。

## 五、输出内容 — ProcessResult

```python
@dataclass
class ProcessResult:
    events: List[Dict[str, Any]]       # 所有命令产生的事件列表
    commands_executed: int             # 成功执行的命令数
    errors: List[str]                  # 错误列表
    next_action: Optional[str]         # 下一步应该执行的动作
    response_type: str                 # 响应类型
    metadata: Dict[str, Any]           # 元数据（如 target_flow 等）

    @property
    def success(self) -> bool:         # 是否成功（执行数>0 且无错误）
        return self.commands_executed > 0 and len(self.errors) == 0
```

典型的 ProcessResult 示例：

**场景1：用户发起查询订单**
```python
ProcessResult(
    events=[
        {"event": "flow_started", "flow_id": "order_status", "timestamp": None},
        {"event": "slot_set", "name": "order_id", "value": "ORD12345", "extractor": "llm", "timestamp": None},
    ],
    commands_executed=2,
    errors=[],
    next_action="action_run_flow_order_status",
    response_type="flow",
    metadata={},
)
```

**场景2：用户闲聊**
```python
ProcessResult(
    events=[
        {"event": "chitchat_triggered", "degradation_reason": "chitchat", "timestamp": None},
    ],
    commands_executed=1,
    errors=[],
    next_action=None,                      # 不设置，让 Policy 检测栈帧
    response_type="chitchat",
    metadata={},
)
```

**场景3：collect 步骤中 LLM 输出干扰命令**
```python
# 输入命令：[SetSlot(order_id, "123"), SetSlot(product, "手机"), StartFlow(refund)]
# 过滤后：[SetSlot(order_id, "123")]

ProcessResult(
    events=[
        {"event": "slot_set", "name": "order_id", "value": "123", "extractor": "llm", "timestamp": None},
    ],
    commands_executed=1,
    errors=[],
    next_action=None,                      # 有活跃 flow，让 FlowPolicy 决定
    response_type="flow",
    metadata={},
)
```

## 六、如何被调用

### 调用方1：`understand_node`（LangGraph 图节点，主路径）

这是最主要的调用路径。`understand_node` 在图中是第一个执行的核心节点：

```python
# understand.py:174-176
process_result = command_processor.process(
    generation_result.commands, tracker
)
```

完整调用链：
```
用户消息
  │
  ▼
Agent.handle_message()
  │  构建 initial_state（含 _command_processor 引用）
  ▼
Graph.ainvoke(initial_state)
  │
  ▼
understand_node(state)
  │
  ├─ 路径A: 检测 /SetSlots payload → parse_set_slots_payload() → 直接解析
  │         └─ command_processor.process(commands, tracker)
  │
  ├─ 路径B: 正常 LLM 路径 → command_generator.generate() → 得到 commands
  │         └─ command_processor.process(commands, tracker)
  │
  └─ 输出 process_result 到图状态
       │
       ▼
     policy_node 读取 process_result.next_action 作为第一轮预测依据
```

两条路径的区别：
- **路径A**：按钮点击 `/SetSlots(order_id=123)`，完全绕过 LLM，直接解析为 SetSlotCommand
- **路径B**：用户自然语言输入，经 LLM 生成 Command

### 调用方2：`MessageProcessor`（遗留路径，向后兼容）

```python
# message_processor.py:147
process_result = self.command_processor.process(
    generation_result.commands, tracker
)
```

这是原始的消息处理器入口，目前作为 LangGraph 图的备用方案保留。

### 初始化

`CommandProcessor` 在 `Agent.__init__()` 中创建并传入图状态：

```python
# agent.py:198-200
self.command_processor = CommandProcessor(
    domain=self.domain,
    flows=self.flows.flows if self.flows else [],
)

# agent.py:245
command_processor=self.command_processor,  # 传入 initial_state
```

图状态 `_command_processor` 字段由 `understand_node` 读取使用。

## 七、完整数据流示意

```
用户: "我要查订单 ORD12345"
  │
  ▼ understand_node
┌─────────────────────────────────────────────────────────────┐
│ 1. LLM 生成:                                                │
│    [StartFlowCommand(flow="order_status"),                  │
│     SetSlotCommand(name="order_id", value="ORD12345")]      │
│                                                             │
│ 2. CommandProcessor.process():                              │
│    ├─ 过滤: 不在 collect 步骤，不过滤                        │
│    ├─ 执行 StartFlowCommand.run()                           │
│    │   └─ tracker.start_flow("order_status")                │
│    │       └─ dialogue_stack.push_flow("order_status")       │
│    │           → FlowStackFrame(flow_id="order_status")     │
│    ├─ 执行 SetSlotCommand.run()                             │
│    │   └─ tracker.set_slot("order_id", "ORD12345")          │
│    ├─ response_type = "flow"                                │
│    └─ next_action = "action_run_flow_order_status"          │
│                                                             │
│ 输出 ProcessResult:                                         │
│   events: [flow_started, slot_set]                          │
│   next_action: "action_run_flow_order_status"               │
│   response_type: "flow"                                     │
└─────────────────────────────────────────────────────────────┘
  │
  ▼ policy_node
┌─────────────────────────────────────────────────────────────┐
│ 检测到 process_result.next_action 存在且 action_count == 0   │
│ → 直接使用: PolicyPrediction(action="action_run_flow_...")  │
└─────────────────────────────────────────────────────────────┘
  │
  ▼ action_node → 执行 FlowPolicy 选出的动作 → 生成响应
```
