# `command_parser` 模块分析

## 一、功能概述

`CommandParser` 的职责是**将 LLM 输出的原始文本解析为结构化的 Command 对象列表**。它在整个对话流程中处于「理解阶段」的末端，是连接 LLM 自由文本输出与系统结构化命令之间的桥梁。

```
LLM 原始输出                          CommandParser                    结构化命令
┌──────────────────────┐           ┌──────────────┐           ┌─────────────────────┐
│ start flow order     │  ──────►  │ CommandParser │  ──────►  │ StartFlowCommand    │
│ set slot order_id 123│           │   .parse()   │           │ SetSlotCommand      │
└──────────────────────┘           └──────────────┘           └─────────────────────┘
```

核心能力：
- 支持**两种 DSL 格式**解析：自然语言风格（`set slot name "John"`）和函数调用风格（`SetSlot(name, "John")`）
- 容错处理：自动清理 markdown 代码块标记、列表编号、注释行等无关字符
- 错误收集：无法解析的行不会中断整体流程，而是记入 `errors` 列表

## 二、解析流程

`CommandParser.parse(text)` 的完整处理流程如下：

```
输入: LLM 原始输出文本
  │
  ▼
1. _clean_text()         清理文本
  │  ├─ 移除 markdown 代码块标记 ```...```
  │  ├─ 移除内联代码反引号 `xxx`
  │  ├─ 移除列表标记 (-, *, •)
  │  └─ 移除编号 (1. , 2. )
  │
  ▼
2. _split_lines()        分割行
  │  ├─ 按换行符 \n 分割
  │  └─ 按分号 ; 二次分割
  │
  ▼
3. 逐行处理             遍历每一行
  │  ├─ 跳过空行
  │  ├─ 跳过注释行 (# 或 // 开头)
  │  └─ 调用 _parse_line() 解析
  │
  ▼
4. _parse_line()         单行解析（核心，见下文）
  │
  ▼
输出: ParseResult
  ├─ commands: List[Command]   成功解析的命令列表
  ├─ errors: List[Tuple]       解析失败的行及其错误信息
  └─ raw_lines: List[str]      原始行列表
```

## 三、确定产出哪个 Command — 两轮匹配机制

`_parse_line(line)` 是确定产出哪个 Command 的核心方法，采用**两轮匹配**策略：

### 第一轮：全局遍历匹配（`parse_command_from_text`）

```python
command = parse_command_from_text(line)
```

遍历全局命令注册表 `_COMMAND_REGISTRY` 中的**所有命令类**，依次调用每个类的 `from_dsl(text)` 方法：

```python
# base.py:282-291
def parse_command_from_text(text: str) -> Optional[Command]:
    for command_cls in _COMMAND_REGISTRY.values():
        command = command_cls.from_dsl(text)  # 内部调用 regex_pattern + _from_regex_match
        if command is not None:
            return command
    return None
```

每个 Command 子类实现的匹配逻辑：
1. 调用自身的 `regex_pattern()` 获取正则表达式
2. 用 `re.match(pattern, text)` 尝试匹配
3. 匹配成功则调用 `_from_regex_match(match)` 构造 Command 实例
4. 匹配失败返回 `None`，继续尝试下一个命令类

### 第二轮：二次正则匹配（兜底）

如果第一轮返回 `None`，再遍历一次命令注册表，直接使用各命令类的 `regex_pattern()` 逐个匹配：

```python
for command_name, command_cls in self._command_classes.items():
    pattern = command_cls.regex_pattern()
    if pattern:
        match = re.match(pattern, line, re.IGNORECASE)
        if match:
            return command_cls._from_regex_match(match)
```

第二轮与第一轮的区别：第一轮走 `from_dsl()` 标准入口，第二轮直接调用 `regex_pattern()` + `_from_regex_match()`，作为兜底机制覆盖第一轮可能因异常被跳过的情况。

如果两轮都无法匹配，该行记入 `errors`（`"Unrecognized command format"`）。

### 各 Command 的正则匹配模式

| Command | DSL 示例 | regex_pattern 匹配的格式 |
|---|---|---|
| `StartFlowCommand` | `start flow order` / `StartFlow(order)` | `start flow <id>` 或 `StartFlow(<id>)` |
| `CancelFlowCommand` | `cancel flow` / `CancelFlow()` | `cancel flow [id]` 或 `CancelFlow([id])` |
| `ChangeFlowCommand` | `change flow order` | `change flow <id>` |
| `SetSlotCommand` | `set slot name "John"` / `SetSlot(name, "John")` | `set slot <name> <value>` 或 `SetSlot(<name>, <value>)` |
| `ResetSlotCommand` | `reset slot name` | `reset slot <name>` |
| `ChitChatAnswerCommand` | `chitchat` / `ChitChat()` | 固定词 `chitchat` 或 `ChitChat()` |
| `CannotHandleCommand` | `cannot_handle` / `CannotHandle()` | `cannot_handle[(reason)]` 或 `CannotHandle([reason])` |
| `KnowledgeAnswerCommand` | `knowledge_answer` / `SearchAndReply()` | `knowledge_answer[(query)]` 或 `SearchAndReply([query])` |
| `FreeFormAnswerCommand` | `free_form_answer` | 固定词 `free_form_answer` |
| `HumanHandoffCommand` | `human_handoff` / `human_handoff(reason)` | `human_handoff[(reason)]` |
| `ClarifyCommand` | `clarify` / `clarify("question")` | `clarify[(question)]` |
| `RestartCommand` | `restart` | 固定词 `restart` |
| `SessionStartCommand` | `session_start` | 固定词 `session_start` |
| `NoopCommand` | `noop` | 固定词 `noop` |
| `ErrorCommand` | `error("type", "msg")` | `error(type[, msg])` |

### 注册机制

所有 Command 子类通过 `@register_command` 装饰器自动注册到全局字典 `_COMMAND_REGISTRY`：

```python
# base.py:65-77
_COMMAND_REGISTRY: Dict[str, Type["Command"]] = {}

def register_command(cls: Type["Command"]) -> Type["Command"]:
    _COMMAND_REGISTRY[cls.command_name()] = cls
    return cls
```

`CommandParser.__init__()` 时调用 `get_all_command_classes()` 获取注册表副本：

```python
# command_parser.py:61
self._command_classes = get_all_command_classes()
```

## 四、如何被调用

`CommandParser` 只有一个调用方：`LLMCommandGenerator.generate_commands()`。

### 调用链

```
用户消息
  │
  ▼
understand_node (图节点)
  │
  ▼
LLMCommandGenerator.generate_commands(tracker, domain, flows)
  │
  ├─ 1. prompt_builder.build_messages()    构建 Prompt
  ├─ 2. llm_client.complete()              调用 LLM 获取原始文本
  ├─ 3. command_parser.parse(content)       ← CommandParser 在此被调用
  │     └─ 返回 ParseResult → 提取 commands
  └─ 4. 若无命令 → CannotHandleCommand(reason="parse_failed")
```

具体代码（`llm_generator.py:173-183`）：

```python
# 3. 解析命令
parse_result = self.command_parser.parse(llm_response.content)
result.commands = parse_result.commands

if parse_result.errors:
    result.metadata["parse_errors"] = parse_result.errors
    logger.warning(f"Parse errors: {parse_result.errors}")

# 4. 如果没有解析出命令，返回 cannot_handle
if not result.commands:
    logger.warning("No commands parsed from LLM output")
    result.commands = [CannotHandleCommand(reason="parse_failed")]
```

### 初始化

`CommandParser` 在 `LLMCommandGenerator.__init__()` 中创建：

```python
# llm_generator.py:107
self.command_parser = command_parser or CommandParser()
```

如果外部没有传入，则使用默认实例。

## 五、便捷函数

模块还提供了两个顶层便捷函数，无需手动创建 `CommandParser` 实例：

```python
# 使用默认解析器实例
default_parser = CommandParser()

def parse_commands(text: str) -> List[Command]:
    """解析文本中的所有命令"""
    result = default_parser.parse(text)
    return result.commands

def parse_single_command(text: str) -> Optional[Command]:
    """解析单个命令"""
    return default_parser.parse_single(text)
```

## 六、完整数据流示意

```
LLM 输出示例:
┌────────────────────────────────────────┐
│ ```                                    │
│ 1. start flow order_status             │
│ 2. set slot order_id "ORD12345"        │
│ ```                                    │
└────────────────────────────────────────┘
                │
                ▼  _clean_text()
┌────────────────────────────────────────┐
│ start flow order_status                │
│ set slot order_id "ORD12345"           │
└────────────────────────────────────────┘
                │
                ▼  _split_lines()
┌────────────────────────────────────────┐
│ ["start flow order_status",            │
│  "set slot order_id \"ORD12345\""]     │
└────────────────────────────────────────┘
                │
                ▼  _parse_line() × 2
┌────────────────────────────────────────┐
│ commands:                              │
│   [StartFlowCommand(flow="order_status"),│
│    SetSlotCommand(name="order_id",      │
│                   value="ORD12345")]    │
│ errors: []                             │
└────────────────────────────────────────┘
                │
                ▼
后续由 CommandProcessor 执行这些 Command
```
