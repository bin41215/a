# 错误修复：DialogueStack属性名错误

## 🔴 错误信息

```
[understand_node] 生成了 1 个命令: ["StartFlowCommand(flow='query_order_detail')"]
Failed to execute start_flow: 'DialogueStack' object has no attribute '_frames'
```

## 🎯 问题原因

在日志增强时，错误地使用了 `dialogue_stack._frames`，但 `DialogueStack` 类的实际属性名是 `frames`（没有下划线）。

### 错误代码位置

**文件**：`hll_ai/core/tracker.py`

**错误的代码**：
```python
logger.info(
    f"[Tracker] 启动Flow: {flow_name} | "
    f"起始步骤: {step_id} | "
    f"栈深度: {len(self.dialogue_stack._frames)}"  # ❌ 错误：_frames
)
```

**正确的代码**：
```python
logger.info(
    f"[Tracker] 启动Flow: {flow_name} | "
    f"起始步骤: {step_id} | "
    f"栈深度: {len(self.dialogue_stack.frames)}"  # ✅ 正确：frames
)
```

---

## ✅ 已修复

### 修复内容

1. **start_flow() 方法** - 第287行
   - `_frames` → `frames`

2. **end_flow() 方法** - 第319行
   - `_frames` → `frames`

---

## 🚀 验证修复

### 步骤1：重启服务

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
export DASHSCOPE_API_KEY=sk-71f21a92755c473a9b7f551790b10716

# 清除Python缓存
find .. -type d -name __pycache__ -exec rm -rf {} + 2>/dev/null
find .. -type f -name "*.pyc" -delete 2>/dev/null

# 重启
hll --debug inspect
```

### 步骤2：测试对话

```
You: 查询订单
```

**预期看到正常日志**：
```
INFO:[Tracker] 启动Flow: query_order_detail | 起始步骤: START | 栈深度: 1
```

**而不是错误**：
```
Failed to execute start_flow: 'DialogueStack' object has no attribute '_frames'
```

---

## 📊 DialogueStack 类属性说明

**正确的属性名**：

```python
@dataclass
class DialogueStack:
    frames: List[StackFrame] = field(default_factory=list)  # ✅ 公开属性
```

**访问方式**：
```python
# ✅ 正确
len(dialogue_stack.frames)
dialogue_stack.frames[0]

# ❌ 错误
len(dialogue_stack._frames)  # AttributeError
```

**相关方法**：
```python
dialogue_stack.size()        # 获取栈大小
len(dialogue_stack)          # 也可以用len()
dialogue_stack.is_empty()    # 检查是否为空
```

---

## 🔍 如何避免类似错误

### 技巧1：使用公开API

```python
# ❌ 不要直接访问私有属性
len(obj._internal_list)

# ✅ 使用公开方法或属性
len(obj.items)
obj.size()
```

### 技巧2：查看类定义

```python
# 查看类的属性
from hll_ai.dialogue_understanding.stack.dialogue_stack import DialogueStack
print(DialogueStack.__annotations__)
# 输出: {'frames': List[StackFrame]}
```

### 技巧3：使用IDE自动补全

如果使用VSCode或PyCharm，输入 `dialogue_stack.` 会自动提示可用的属性和方法。

---

## 🎯 完整的修复验证

运行这个测试脚本：

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo

python3 << 'EOF'
import sys
sys.path.insert(0, '..')

from hll_ai.dialogue_understanding.stack.dialogue_stack import DialogueStack

# 测试DialogueStack属性
stack = DialogueStack()

# ✅ 正确的访问方式
print(f"frames属性存在: {hasattr(stack, 'frames')}")
print(f"栈大小: {len(stack.frames)}")
print(f"栈是否为空: {stack.is_empty()}")

# ❌ 错误的访问方式会报错
try:
    print(len(stack._frames))
except AttributeError as e:
    print(f"错误（预期）: {e}")

print("\n✅ 修复验证通过！")
EOF
```

**预期输出**：
```
frames属性存在: True
栈大小: 0
栈是否为空: True
错误（预期）: 'DialogueStack' object has no attribute '_frames'

✅ 修复验证通过！
```

---

## 📝 相关代码位置

### 修复的文件
- `hll_ai/core/tracker.py`
  - 第287行：`start_flow()` 方法
  - 第319行：`end_flow()` 方法

### DialogueStack定义
- `hll_ai/dialogue_understanding/stack/dialogue_stack.py`
  - 第36行：`frames` 属性定义

---

## ✅ 修复状态

- ✅ start_flow() 中的 `_frames` 已改为 `frames`
- ✅ end_flow() 中的 `_frames` 已改为 `frames`
- ✅ 代码已保存
- ⚠️ 需要重启服务才能生效

---

**现在重启服务，问题已解决！🎉**
