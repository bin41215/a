# API Key 加载失败问题修复

## 🔴 错误信息

```
ErrorCommand(error_type='generation_error', message="Did not find dashscope_api_key, 
please add an environment variable `DASHSCOPE_API_KEY`...")
```

## 🎯 问题原因

环境变量 `DASHSCOPE_API_KEY` 没有被正确加载，尽管 `.env` 文件中已配置。

### 可能的原因

1. **启动目录不对** - 不在 `ecs_demo` 目录下启动
2. **.env文件路径问题** - 系统找不到 `.env` 文件
3. **环境变量未导出** - `.env` 文件未被加载到环境中

---

## ✅ 解决方案

### 方案1：确保在正确目录启动（推荐）

```bash
# 1. 进入ecs_demo目录
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo

# 2. 确认.env文件存在
ls -la .env

# 3. 在当前目录启动
hll shell
```

**重要**：必须在 `ecs_demo` 目录内启动，因为系统会自动加载当前目录的 `.env` 文件。

---

### 方案2：手动导出环境变量

```bash
# 导出环境变量到当前shell
export DASHSCOPE_API_KEY=sk-71f21a92755c473a9b7f551790b10716

# 验证是否设置成功
echo $DASHSCOPE_API_KEY

# 启动
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
hll shell
```

---

### 方案3：使用绝对路径的.env文件

```bash
# 创建一个启动脚本
cat > /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo/start.sh << 'EOF'
#!/bin/bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
export DASHSCOPE_API_KEY=sk-71f21a92755c473a9b7f551790b10716
hll shell
EOF

# 添加执行权限
chmod +x /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo/start.sh

# 使用脚本启动
/Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo/start.sh
```

---

### 方案4：修改endpoints.yml，直接写入API Key（不推荐，但最简单）

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
nano endpoints.yml
```

修改第9行：

**原来**：
```yaml
api_key: ${DASHSCOPE_API_KEY}
```

**改为**（直接写入Key，不使用环境变量）：
```yaml
api_key: sk-71f21a92755c473a9b7f551790b10716
```

⚠️ **注意**：这种方式不安全，API Key会明文保存在配置文件中。仅用于测试。

---

## 🔍 诊断步骤

### 步骤1：确认当前目录

```bash
pwd
# 应该输出: /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
```

### 步骤2：确认.env文件存在

```bash
ls -la .env
# 应该显示: -rwx------ 1 bin staff xxx Jun xx xx:xx .env
```

### 步骤3：测试环境变量加载

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo

python3 << 'EOF'
from pathlib import Path
import dotenv
import os

# 加载.env
env_file = Path('.env')
print(f"1. .env文件存在: {env_file.exists()}")

dotenv.load_dotenv(env_file)
api_key = os.getenv('DASHSCOPE_API_KEY')

print(f"2. API Key长度: {len(api_key) if api_key else 0}")
print(f"3. API Key前缀: {api_key[:8] if api_key else 'None'}...")
print(f"4. 加载成功: {api_key is not None and len(api_key) > 0}")
EOF
```

**预期输出**：
```
1. .env文件存在: True
2. API Key长度: 40
3. API Key前缀: sk-71f21...
4. 加载成功: True
```

### 步骤4：测试LLM客户端

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo

python3 << 'EOF'
import os
from pathlib import Path
import dotenv
import sys
import asyncio

# 加载环境变量
dotenv.load_dotenv('.env')
sys.path.insert(0, '/Users/bin/Documents/my_project/ai/llm_customer_service')

from hll_ai.shared.llm import create_llm_client

async def test():
    api_key = os.getenv('DASHSCOPE_API_KEY')
    print(f"API Key: {api_key[:10]}..." if api_key else "API Key: None")
    
    try:
        client = create_llm_client(
            type="qwen",
            model="qwen-plus",
            api_key=api_key,
            temperature=0.5
        )
        print("✅ LLM客户端创建成功")
        
        # 测试调用
        messages = [{"role": "user", "content": "你好"}]
        response = await client.complete(messages)
        print(f"✅ LLM响应: {response.content[:50]}")
    except Exception as e:
        print(f"❌ 错误: {e}")

asyncio.run(test())
EOF
```

---

## 🚀 立即执行的完整流程

### 一键修复脚本

```bash
#!/bin/bash
set -e

echo "🔧 开始修复API Key加载问题..."

# 1. 进入正确目录
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
echo "✅ 当前目录: $(pwd)"

# 2. 检查.env文件
if [ -f .env ]; then
    echo "✅ .env文件存在"
else
    echo "❌ .env文件不存在"
    exit 1
fi

# 3. 导出环境变量
export DASHSCOPE_API_KEY=$(grep DASHSCOPE_API_KEY .env | cut -d '=' -f 2)
echo "✅ 已导出环境变量: DASHSCOPE_API_KEY=${DASHSCOPE_API_KEY:0:10}..."

# 4. 验证环境变量
if [ -z "$DASHSCOPE_API_KEY" ]; then
    echo "❌ 环境变量为空"
    exit 1
fi

echo "✅ 环境变量验证成功"
echo ""
echo "🚀 启动hll shell..."
echo ""

# 5. 启动
hll shell
```

保存为 `fix_and_run.sh` 并执行：

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
chmod +x fix_and_run.sh
./fix_and_run.sh
```

---

## 📝 推荐的标准启动流程

### 创建启动别名（推荐）

编辑你的 `~/.zshrc` 或 `~/.bashrc`：

```bash
echo 'alias hll-demo="cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo && export DASHSCOPE_API_KEY=sk-71f21a92755c473a9b7f551790b10716 && hll shell"' >> ~/.zshrc

# 重新加载配置
source ~/.zshrc
```

之后只需要运行：
```bash
hll-demo
```

---

## ⚠️ 常见错误

### 错误1：在错误的目录启动

```bash
# ❌ 错误
cd /Users/bin/Documents/my_project/ai/llm_customer_service
hll shell --model ecs_demo  # .env不会被加载

# ✅ 正确
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
hll shell
```

### 错误2：.env文件格式问题

确保.env文件中没有多余的空格：

```bash
# ❌ 错误
DASHSCOPE_API_KEY = sk-xxx  # 等号两边有空格

# ✅ 正确
DASHSCOPE_API_KEY=sk-xxx    # 等号两边无空格
```

### 错误3：API Key包含特殊字符

```bash
# ❌ 错误
DASHSCOPE_API_KEY="sk-xxx"  # 有引号

# ✅ 正确
DASHSCOPE_API_KEY=sk-xxx    # 无引号
```

---

## 🔧 终极解决方案（100%有效）

如果以上方法都不行，直接在代码中硬编码（仅用于测试）：

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
nano endpoints.yml
```

修改为：
```yaml
models:
  default:
    type: qwen
    model: qwen-plus
    api_key: sk-71f21a92755c473a9b7f551790b10716  # 直接写死
    temperature: 0.5
```

然后：
```bash
hll shell
```

这样肯定能工作！

---

## 📊 验证修复成功

修复后，你应该看到：

```
You: 你好
[understand_node] 调用LLM...
[understand_node] 生成了 1 个命令: ['ChitchatCommand()']
Bot: 你好！我是智能客服助手...
```

而不是：
```
[understand_node] 生成了 1 个命令: ['ErrorCommand(error_type='generation_error'...)']
```

---

## 🎯 最简单的启动方式（立即执行）

```bash
cd /Users/bin/Documents/my_project/ai/llm_customer_service/ecs_demo
export DASHSCOPE_API_KEY=sk-71f21a92755c473a9b7f551790b10716
hll shell
```

这三行命令，逐行执行，保证能工作！

---

**现在立即执行上面的命令吧！🚀**
