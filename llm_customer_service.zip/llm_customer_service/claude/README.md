# LLM客服对话系统 - 技术文档

## 📚 文档导航

本文档集为编程初学者详细讲解了基于LLM的智能客服对话系统的架构、模块、调用链和开发方法。

---

## 文档列表

### 1. [项目整体架构.md](./项目整体架构.md)
**适合人群**：所有人，第一次阅读必看

**内容概览**：
- 项目概述和特点
- 目录结构详解
- 核心概念（Domain、Flow、Action、Tracker、Policy）
- 系统运行流程
- 完整对话流程示例
- 关键技术点
- 数据流图
- 配置文件说明

**学习目标**：理解整个系统是如何工作的，各个模块的作用和关系

---

### 2. [核心模块详解.md](./核心模块详解.md)
**适合人群**：已理解整体架构，想深入了解各模块实现

**内容概览**：
- **hll_ai.agent 模块**：Agent类、Actions、Graph（LangGraph图式编排）
- **hll_ai.core 模块**：Tracker、Domain、Slots、Stores
- **hll_ai.dialogue_understanding 模块**：Generator、Processor、Flow、Stack
- **hll_ai.policies 模块**：FlowPolicy、EnterpriseSearchPolicy、PolicyEnsemble
- 核心调用链总结
- 数据流转图

**学习目标**：掌握每个模块的职责、核心方法和使用方式

---

### 3. [完整调用链追踪.md](./完整调用链追踪.md)
**适合人群**：想看到真实执行过程，调试排错

**内容概览**：
- 实例追踪：订单查询完整流程（2轮对话）
- 每一步的详细代码执行过程
- 关键时刻的Tracker状态快照
- 代码执行路径图
- 性能关键点分析
- 调试技巧

**学习目标**：
- 看懂系统内部是如何一步步处理用户消息的
- 学会如何调试和排查问题
- 理解数据在各模块间的流转

---

### 4. [实战示例-开发新功能.md](./实战示例-开发新功能.md)
**适合人群**：准备动手开发，实现自己的业务功能

**内容概览**：
- 完整案例：从零开发"商品评价"功能
- 数据库表设计
- Domain配置编写
- Flow流程设计
- Action代码实现
- 测试验证
- 扩展功能示例
- 常见问题和最佳实践

**学习目标**：
- 掌握完整的开发流程
- 学会设计和实现新的业务功能
- 了解开发规范和最佳实践

---

## 推荐学习路径

### 🌟 初学者路径

```
第1天：阅读《项目整体架构》
    └─ 理解核心概念和整体流程
    └─ 运行ecs_demo体验系统

第2天：阅读《核心模块详解》
    └─ 深入了解各模块实现
    └─ 查看对应源代码

第3天：阅读《完整调用链追踪》
    └─ 跟踪真实执行过程
    └─ 使用调试工具观察

第4天：阅读《实战示例》并动手实践
    └─ 跟着示例开发评价功能
    └─ 尝试修改和扩展

第5天：实现自己的业务功能
    └─ 设计Flow和Action
    └─ 测试调试
```

### 🚀 有经验开发者路径

```
1小时：快速浏览《项目整体架构》
    └─ 了解核心概念和技术栈

30分钟：浏览《核心模块详解》
    └─ 重点关注感兴趣的模块

1小时：参考《实战示例》
    └─ 直接开始开发自己的功能
```

---

## 核心概念速查

### Domain（领域定义）
定义对话系统的"词汇表"：槽位、响应、动作

**文件位置**：`ecs_demo/domain/*.yml`

### Flow（对话流程）
定义完整业务流程的"流程图"

**文件位置**：`ecs_demo/data/flows/*.yml`

### Action（动作）
处理具体业务逻辑的Python代码

**文件位置**：`ecs_demo/actions/*.py`

### Tracker（状态追踪器）
记录对话过程中的所有信息

**核心属性**：槽位、对话历史、活跃Flow、对话栈

### Policy（策略）
决定机器人下一步做什么

**核心策略**：FlowPolicy（执行Flow）、EnterpriseSearchPolicy（知识库问答）

---

## 快速查找

### 我想了解...

| 需求 | 推荐文档 | 章节 |
|------|---------|------|
| 系统整体如何工作 | 项目整体架构 | 三、四、五 |
| Agent是什么 | 核心模块详解 | 一.1 |
| Flow如何定义 | 项目整体架构 | 三.2 |
| Flow如何执行 | 核心模块详解 | 三.3 |
| Action如何实现 | 项目整体架构 | 三.3 |
| Tracker如何使用 | 核心模块详解 | 二.1 |
| 槽位如何填充 | 项目整体架构 | 五.2 |
| 一条消息如何被处理 | 完整调用链追踪 | 二 |
| 如何开发新功能 | 实战示例 | 二 |
| 如何调试问题 | 完整调用链追踪 | 七 |
| 最佳实践 | 实战示例 | 五 |

---

## 代码示例速查

### 使用Agent处理消息
```python
from hll_ai.agent import Agent

# 加载Agent
agent = Agent.load("./ecs_demo")

# 处理消息
response = await agent.handle_message("查询订单", sender_id="user123")

# 获取响应
for msg in response.messages:
    print(msg)
```

### 定义Flow
```yaml
flows:
  my_flow:
    name: 我的流程
    steps:
      - collect: order_id
      - action: action_query_order
        next: END
```

### 实现Action
```python
from hll_ai.agent.actions import Action, ActionResult

class MyAction(Action):
    @property
    def name(self) -> str:
        return "action_my_action"
    
    async def run(self, tracker, domain, **kwargs):
        result = ActionResult()
        
        # 获取槽位
        value = tracker.get_slot("slot_name")
        
        # 处理业务逻辑
        # ...
        
        # 返回响应
        result.add_response("处理完成")
        return result
```

---

## 常见问题

### Q: LLM是如何理解用户意图的？
**A**: 通过LLMCommandGenerator将用户消息、对话历史、可用Flow列表组合成提示词，让LLM生成命令（如StartFlow、SetSlots）。详见《核心模块详解》三.1

### Q: Flow和Policy的关系是什么？
**A**: Flow定义"要做什么"，Policy决定"怎么执行"。FlowPolicy负责按照Flow定义执行步骤。详见《项目整体架构》三.5

### Q: 槽位值是如何提取的？
**A**: 根据槽位的mappings配置，可以from_llm（LLM提取）、controlled（按钮选择）、from_entity（NER提取）。详见《项目整体架构》五.2

### Q: 如何添加新的业务模块？
**A**: 按照"定义Domain → 设计Flow → 实现Action → 测试"的流程。详见《实战示例》二

### Q: 如何调试Flow执行问题？
**A**: 使用日志、Tracker状态查看、hll inspect工具。详见《完整调用链追踪》七

---

## 技术栈

### 核心框架
- **LangChain**: LLM集成和调用
- **LangGraph**: 图式编排对话流程
- **FastAPI**: API服务器
- **SQLAlchemy**: 数据库ORM

### LLM支持
- OpenAI (GPT-4, GPT-3.5)
- Anthropic (Claude)
- 通义千问 (DashScope)

### 数据库支持
- MySQL (Tracker存储)
- Neo4j (知识图谱)
- JSON文件 (开发测试)

---

## 相关资源

### 源代码
- 核心框架：`hll_ai/`
- 示例项目：`ecs_demo/`

### 配置文件
- Domain定义：`ecs_demo/domain/*.yml`
- Flow定义：`ecs_demo/data/flows/*.yml`
- 框架配置：`ecs_demo/config.yml`
- 端点配置：`ecs_demo/endpoints.yml`

### 工具命令
```bash
# 初始化项目
hll init my_project

# 启动交互式测试
hll inspect ./ecs_demo

# 启动控制台
hll shell ./ecs_demo

# 启动API服务
hll run --port 5000 ./ecs_demo

# 训练模型（如需要）
hll train ./ecs_demo
```

---

## 贡献和反馈

### 文档更新
如发现文档错误或需要补充，请提交Issue或PR

### 示例代码
欢迎贡献更多业务场景的示例代码

### 问题讨论
遇到问题可以通过Issue讨论

---

## 版本信息

- **文档版本**: v1.0
- **框架版本**: hll_ai 0.1.0
- **更新日期**: 2024-01-15
- **适用人群**: 编程初学者、对话系统开发者

---

## 附录

### A. 术语表

| 术语 | 英文 | 解释 |
|------|------|------|
| 槽位 | Slot | 对话中需要收集的信息 |
| 流程 | Flow | 完整的业务对话流程 |
| 动作 | Action | 执行具体业务逻辑的代码 |
| 追踪器 | Tracker | 记录对话状态的数据结构 |
| 策略 | Policy | 决定下一步动作的决策器 |
| 领域 | Domain | 定义对话系统词汇表的配置 |
| 命令 | Command | LLM生成的操作指令 |

### B. 文件结构速查

```
llm_customer_service/
├── hll_ai/                    # 核心框架
│   ├── agent/                 # Agent核心
│   ├── core/                  # 核心数据结构
│   ├── dialogue_understanding/# 对话理解
│   ├── policies/              # 策略
│   └── ...
├── ecs_demo/                  # 示例项目
│   ├── domain/                # Domain定义
│   ├── data/flows/            # Flow定义
│   ├── actions/               # Action实现
│   ├── config.yml             # 配置
│   └── endpoints.yml          # 端点配置
└── claude/                    # 本文档目录
    ├── README.md              # 本文件
    ├── 项目整体架构.md
    ├── 核心模块详解.md
    ├── 完整调用链追踪.md
    └── 实战示例-开发新功能.md
```

---

## 开始学习

现在就开始阅读 [项目整体架构.md](./项目整体架构.md) 吧！

**祝学习愉快！🎉**
